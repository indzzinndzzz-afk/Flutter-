import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'user_prefs.dart';
import 'app_service.dart';

// ── Background message handler (harus top-level function) ───────────────────
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Background: tidak bisa play audio, cukup receive saja
  debugPrint('[FCM BG] ${message.notification?.title}: ${message.notification?.body}');
}

class NotificationService {
  static final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  static final AudioPlayer _player = AudioPlayer();
  static bool _initialized = false;

  // ── Init sekali di main() ──────────────────────────────────────────────────
  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    // Set background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // Minta permission notif
    final settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    debugPrint('[FCM] Auth status: ${settings.authorizationStatus}');

    // Foreground: show snackbar + play audio
    FirebaseMessaging.onMessage.listen((RemoteMessage msg) {
      debugPrint('[FCM FG] ${msg.notification?.title}');
      playNotifSound();
      // Tampilkan via overlay global jika ada navigatorKey
      _showOverlayNotif(msg.notification?.title, msg.notification?.body);
    });

    // App opened from background via notif tap
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage msg) {
      debugPrint('[FCM OPEN] ${msg.data}');
    });
  }

  // ── Simpan FCM token ke backend setelah login ──────────────────────────────
  static Future<void> saveFcmToken(String authToken) async {
    try {
      final fcmToken = await _fcm.getToken();
      if (fcmToken == null || fcmToken.isEmpty) return;
      await UserPrefs.saveFcmToken(fcmToken);
      await AppService.updateFcmToken(authToken: authToken, fcmToken: fcmToken);
      debugPrint('[FCM] Token saved: ${fcmToken.substring(0, 20)}...');
    } catch (e) {
      debugPrint('[FCM] Save token error: $e');
    }
  }

  // ── Play audio notifikasi dari assets ─────────────────────────────────────
  // File: assets/audio/notif.mp3 (taruh file mp3 kamu di sana)
  static Future<void> playNotifSound() async {
    try {
      await _player.stop();
      await _player.play(AssetSource('audio/notif.mp3'));
    } catch (e) {
      debugPrint('[Audio] Play error: $e');
    }
  }

  // ── Overlay notif sederhana (gunakan navigatorKey global) ─────────────────
  static GlobalKey<NavigatorState>? navigatorKey;

  static void _showOverlayNotif(String? title, String? body) {
    final ctx = navigatorKey?.currentContext;
    if (ctx == null || title == null) return;
    ScaffoldMessenger.of(ctx).showSnackBar(
      SnackBar(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            if (body != null && body.isNotEmpty)
              Text(body,
                  style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
        backgroundColor: const Color(0xFF1E1B4B),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 5),
      ),
    );
  }
}
