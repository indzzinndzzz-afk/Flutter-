import 'package:flutter/material.dart';
import '../services/fr3_service.dart';
import '../theme/app_theme.dart';

/// Riwayat transaksi milik user sendiri — auto-load, tanpa input TrxId manual.
/// Mirip halaman riwayat transaksi di DANA: list topup, withdraw, dan order
/// terbaru, tap untuk lihat detail.
class TransactionHistoryScreen extends StatefulWidget {
  const TransactionHistoryScreen({super.key});
  @override
  State<TransactionHistoryScreen> createState() => _TransactionHistoryScreenState();
}

class _TransactionHistoryScreenState extends State<TransactionHistoryScreen> {
  bool _loading = true;
  String? _err;
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final res = await Fr3Service.myTransactions();
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res['success'] == true) {
        _items = List<Map<String, dynamic>>.from(res['data'] ?? []);
      } else {
        _err = res['message'] ?? 'Gagal ambil riwayat transaksi';
      }
    });
  }

  Color _statusColor(String s) {
    switch (s.toLowerCase()) {
      case 'success':
      case 'approved':
      case 'completed':
        return AppTheme.green;
      case 'pending':
      case 'processing':
        return AppTheme.yellow;
      case 'failed':
      case 'cancelled':
      case 'rejected':
        return AppTheme.red;
      default:
        return AppTheme.textSecondary;
    }
  }

  IconData _typeIcon(String type) {
    switch (type) {
      case 'topup':
        return Icons.add_card_rounded;
      case 'withdraw':
        return Icons.send_to_mobile_rounded;
      case 'order':
        return Icons.shopping_bag_rounded;
      default:
        return Icons.receipt_long_rounded;
    }
  }

  String _fmtNum(dynamic n) {
    final num = int.tryParse(n.toString()) ?? 0;
    final s = num.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp${buf.toString()}';
  }

  String _fmtDate(String iso) {
    try {
      final d = DateTime.parse(iso).toLocal();
      const bulan = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
      final hh = d.hour.toString().padLeft(2, '0');
      final mm = d.minute.toString().padLeft(2, '0');
      return '${d.day} ${bulan[d.month]} ${d.year} • $hh:$mm';
    } catch (_) {
      return iso;
    }
  }

  void _showDetail(Map<String, dynamic> item) {
    final status = (item['status'] ?? '-').toString();
    final color = _statusColor(status);
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
              child: Icon(_typeIcon(item['type'] ?? ''), color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item['title'] ?? '-', style: AppTheme.display(size: 14, weight: FontWeight.bold)),
              const SizedBox(height: 2),
              Text(_fmtDate(item['created_at'] ?? ''), style: AppTheme.body(size: 11, color: AppTheme.textSecondary)),
            ])),
          ]),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          _detailRow('ID Transaksi', item['id']?.toString() ?? '-'),
          _detailRow('Nominal', _fmtNum(item['amount'] ?? 0)),
          _detailRow('Status', status.toUpperCase(), valueColor: color),
          if (item['detail'] is Map)
            ...(item['detail'] as Map).entries
                .where((e) => e.value != null && e.value.toString().isNotEmpty)
                .map((e) => _detailRow(_labelKey(e.key.toString()), e.value.toString())),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  String _labelKey(String k) {
    const map = {
      'ewallet': 'E-Wallet', 'nomor': 'Nomor Tujuan', 'message': 'Pesan',
      'markup': 'Markup', 'amount': 'Nominal Asli', 'country_name': 'Negara',
      'product_code': 'Kode Produk', 'bukti_url': 'Bukti Transfer',
    };
    return map[k] ?? k;
  }

  Widget _detailRow(String label, String value, {Color? valueColor}) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Text(label, style: AppTheme.body(size: 12, color: AppTheme.textSecondary))),
      Expanded(
        flex: 2,
        child: Text(value, textAlign: TextAlign.right,
            style: AppTheme.body(size: 12, color: valueColor ?? AppTheme.textPrimary, weight: FontWeight.w600)),
      ),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          color: AppTheme.accentLight,
          child: CustomScrollView(
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                sliver: SliverToBoxAdapter(
                  child: Row(children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppTheme.cursedGradient,
                        boxShadow: [BoxShadow(color: AppTheme.accent.withValues(alpha: 0.35), blurRadius: 12)],
                      ),
                      child: const Icon(Icons.receipt_long_rounded, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Text('RIWAYAT TRANSAKSI',
                        style: AppTheme.display(size: 14, weight: FontWeight.w700, letterSpacing: 0.5)),
                  ]),
                ),
              ),

              if (_loading)
                const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator(color: AppTheme.accentLight)),
                )
              else if (_err != null)
                SliverFillRemaining(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.wifi_off_rounded, color: AppTheme.textSecondary, size: 40),
                        const SizedBox(height: 12),
                        Text(_err!, textAlign: TextAlign.center,
                            style: AppTheme.body(size: 13, color: AppTheme.textSecondary)),
                        const SizedBox(height: 16),
                        TextButton(onPressed: _load, child: const Text('Coba Lagi')),
                      ]),
                    ),
                  ),
                )
              else if (_items.isEmpty)
                SliverFillRemaining(
                  child: Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.inbox_rounded, color: AppTheme.textSecondary, size: 40),
                      const SizedBox(height: 12),
                      Text('Belum ada transaksi', style: AppTheme.body(size: 13, color: AppTheme.textSecondary)),
                    ]),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _buildTile(_items[i]),
                      childCount: _items.length,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTile(Map<String, dynamic> item) {
    final status = (item['status'] ?? '-').toString();
    final color = _statusColor(status);
    return GestureDetector(
      onTap: () => _showDetail(item),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
            child: Icon(_typeIcon(item['type'] ?? ''), color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item['title'] ?? '-', style: AppTheme.body(size: 13, weight: FontWeight.w600),
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(_fmtDate(item['created_at'] ?? ''), style: AppTheme.body(size: 11, color: AppTheme.textSecondary)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(_fmtNum(item['amount'] ?? 0),
                style: AppTheme.body(size: 13, weight: FontWeight.bold, color: AppTheme.accentLight)),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(8)),
              child: Text(status.toUpperCase(),
                  style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold)),
            ),
          ]),
        ]),
      ),
    );
  }
}
