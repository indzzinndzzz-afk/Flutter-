import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/app_service.dart';

class MaintenanceScreen extends StatefulWidget {
  final String message;
  const MaintenanceScreen({super.key, required this.message});

  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;
  bool _checking = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _retry() async {
    setState(() => _checking = true);
    await Future.delayed(const Duration(milliseconds: 500));
    try {
      final res = await AppService.checkMaintenance();
      if (!mounted) return;
      if (res['maintenance'] != true) {
        // Maintenance udah off — balik ke splash
        Navigator.pushReplacementNamed(context, '/splash');
      } else {
        setState(() => _checking = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Masih maintenance nih. Tunggu dulu ya!'),
          backgroundColor: AppTheme.yellow,
        ));
      }
    } catch (_) {
      setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Animated icon
                ScaleTransition(
                  scale: _pulse,
                  child: Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.yellow.withValues(alpha: 0.12),
                      border: Border.all(color: AppTheme.yellow.withValues(alpha: 0.4), width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.yellow.withValues(alpha: 0.25),
                          blurRadius: 30,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.construction_rounded,
                        color: AppTheme.yellow, size: 52),
                  ),
                ),

                const SizedBox(height: 32),

                ShaderMask(
                  shaderCallback: (b) => const LinearGradient(
                    colors: [AppTheme.yellow, Color(0xFFFF9500)],
                  ).createShader(b),
                  child: const Text(
                    'MAINTENANCE',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                      color: Colors.white,
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.yellow.withValues(alpha: 0.2)),
                  ),
                  child: Text(
                    widget.message.isNotEmpty
                        ? widget.message
                        : '🔧 Server sedang maintenance.\nTunggu bentar ya!',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 14,
                      height: 1.6,
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                const Text(
                  'Coba lagi beberapa saat lagi',
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),

                const SizedBox(height: 32),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [AppTheme.yellow, const Color(0xFFFF9500)]),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                            color: AppTheme.yellow.withValues(alpha: 0.3),
                            blurRadius: 16,
                            offset: const Offset(0, 4)),
                      ],
                    ),
                    child: TextButton(
                      onPressed: _checking ? null : _retry,
                      child: _checking
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.refresh_rounded, color: Colors.white),
                                SizedBox(width: 8),
                                Text('CEK ULANG',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2)),
                              ],
                            ),
                    ),
                  ),
                ),

                const SizedBox(height: 16),
                const Text('v1.1.0 • MIWA PAY',
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 11, letterSpacing: 1)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
