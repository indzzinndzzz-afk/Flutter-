import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/fr3_service.dart';
import '../services/user_prefs.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';
import 'deposit_screen.dart';
import 'withdraw_screen.dart';

class HomeScreen extends StatefulWidget {
  final String userId;
  const HomeScreen({super.key, required this.userId});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int  _saldo   = 0;
  bool _loading = true;
  bool _obscure = false;

  // Harga remote dari Telegram bot
  List<Map<String, dynamic>>? _gojoPrices;
  List<Map<String, dynamic>>? _panelPrices;

  int _bannerIdx = 0;
  final PageController _bannerCtrl = PageController();

  static const List<_BannerData> _banners = [
    _BannerData(
      title: 'Miwa Pay', subtitle: 'Solusi Pembayaran Digital Terpercaya',
      tag: 'FAST • AMAN • MUDAH', color1: Color(0xFF6C2BD9), color2: Color(0xFF3F3CBB),
      icon: Icons.bolt_rounded,
      imagePath: 'assets/icons/banner_miwapay.png',
    ),
    _BannerData(
      title: 'Panel Petropoldy — Mulai 1.500', subtitle: 'Internet 1GB s/d Unlimited, harga terjangkau',
      tag: 'INTERNET MURAH', color1: Color(0xFF0891B2), color2: Color(0xFF0E7490),
      icon: Icons.signal_wifi_4_bar_rounded,
    ),
    _BannerData(
      title: 'Tarik Saldo Instan', subtitle: 'DANA • GoPay • OVO • ShopeePay • LinkAja',
      tag: 'WITHDRAW CEPAT', color1: Color(0xFF16A34A), color2: Color(0xFF15803D),
      icon: Icons.send_to_mobile_rounded,
    ),
    _BannerData(
      title: 'Akun Gojo Crasher', subtitle: 'Mulai 5.000/hari — Order via CS',
      tag: 'HOT 🔥', color1: Color(0xFFDC2626), color2: Color(0xFF991B1B),
      icon: Icons.sports_esports_rounded,
    ),
  ];

  // ── Kontak CS — GANTI SESUAI NOMORMU ──────────────────────────────────
  static const String _waNumber  = '6283175593052';   // ← nomor WA tanpa +
  static const String _tgLink    = 'https://t.me/Miwachan76'; // ← username tele

  @override
  void initState() { super.initState(); _load(); }

  @override
  void dispose() { _bannerCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await Fr3Service.checkSaldo();
    // Load remote config (harga gojo + panel)
    final cfg = await Fr3Service.getWithdrawConfig();
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res['success'] == true) _saldo = res['data']['saldo'] ?? 0;
      if (cfg['success'] == true || cfg['gojo_prices'] != null) {
        final gp = cfg['gojo_prices'];
        final pp = cfg['panel_prices'];
        if (gp is List) _gojoPrices = List<Map<String, dynamic>>.from(gp);
        if (pp is List) _panelPrices = List<Map<String, dynamic>>.from(pp);
      }
    });
  }

  void _logout() async {
    await UserPrefs.clear();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), backgroundColor: AppTheme.accent));

  void _openWa()   => _snack('Buka WA: $_waNumber');
  void _openTele() => _snack('Buka Telegram: $_tgLink');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          color: AppTheme.accentLight,
          backgroundColor: AppTheme.card,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                // ── Header ─────────────────────────────────────────────
                Row(children: [
                  // Logo Miwa Pay (gunakan icon app jika asset tersedia)
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, gradient: AppTheme.cursedGradient,
                      boxShadow: [BoxShadow(color: AppTheme.accent.withValues(alpha: 0.35), blurRadius: 12)],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/icons/icon_512.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.bolt_rounded, color: Colors.white, size: 22),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('MIWA PAY', style: AppTheme.display(size: 15, weight: FontWeight.w700, letterSpacing: 1)),
                    Text('Miwa Pay', style: AppTheme.body(size: 11, color: AppTheme.textMuted)),
                  ]),
                  const Spacer(),
                  IconButton(onPressed: _logout, icon: const Icon(Icons.logout_rounded, color: AppTheme.textSecondary)),
                ]),

                const SizedBox(height: 20),

                // ── Banner Miwa Pay ─────────────────────────────────────
                // Banner utama pakai gambar banner_miwapay.png jika ada,
                // fallback ke card gradient
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.asset(
                    'assets/icons/splash_banner.png',
                    width: double.infinity,
                    height: 140,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => SizedBox(
                      height: 140,
                      child: PageView.builder(
                        controller: _bannerCtrl,
                        onPageChanged: (i) => setState(() => _bannerIdx = i),
                        itemCount: _banners.length,
                        itemBuilder: (_, i) => _BannerCard(data: _banners[i]),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_banners.length, (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: _bannerIdx == i ? 18 : 6, height: 6,
                    decoration: BoxDecoration(
                      color: _bannerIdx == i ? AppTheme.accentLight : AppTheme.border,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  )),
                ),

                const SizedBox(height: 20),

                // ── Saldo Card ──────────────────────────────────────────
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      AppTheme.accent.withValues(alpha: 0.2), AppTheme.cyan.withValues(alpha: 0.1),
                    ]),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppTheme.accent.withValues(alpha: 0.3)),
                    boxShadow: [BoxShadow(color: AppTheme.accent.withValues(alpha: 0.15), blurRadius: 30, offset: const Offset(0, 8))],
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Text('SALDO MIWA PAY', style: AppTheme.eyebrow(color: AppTheme.accentLight)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => setState(() => _obscure = !_obscure),
                        child: Icon(_obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                            color: AppTheme.textSecondary, size: 18)),
                      const SizedBox(width: 8),
                      GestureDetector(onTap: _load,
                          child: const Icon(Icons.refresh_rounded, color: AppTheme.textSecondary, size: 18)),
                    ]),
                    const SizedBox(height: 10),
                    if (_loading)
                      const SizedBox(height: 40, child: Center(child: CircularProgressIndicator(
                          strokeWidth: 2, valueColor: AlwaysStoppedAnimation(AppTheme.accentLight))))
                    else
                      Text(_obscure ? 'Rp ••••••' : 'Rp ${_fmt(_saldo)}',
                          style: AppTheme.display(size: 32, weight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text('Tap refresh untuk update', style: AppTheme.body(size: 11, color: AppTheme.textMuted)),
                  ]),
                ),

                const SizedBox(height: 22),

                // ── Menu Utama ──────────────────────────────────────────
                Text('MENU UTAMA', style: AppTheme.eyebrow()),
                const SizedBox(height: 12),
                Row(children: [
                  _MenuIcon(icon: Icons.qr_code_scanner_rounded, label: 'Topup', color: AppTheme.cyan,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DepositScreen(userId: widget.userId)))),
                  const SizedBox(width: 10),
                  _MenuIcon(icon: Icons.send_to_mobile_rounded, label: 'Withdraw', color: AppTheme.green,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WithdrawScreen(userId: widget.userId)))),
                  const SizedBox(width: 10),
                  // Widget Icon Petropoldy — pakai gambar karakter petropoldy
                  _MenuIconImage(
                    imagePath: 'assets/icons/petropoldy.png',
                    fallbackIcon: Icons.dns_rounded,
                    label: 'Petropoldy', color: AppTheme.yellow,
                    onTap: () => _showPetroDialog(),
                  ),
                  const SizedBox(width: 10),
                  // Widget Icon Gojo Crasher — pakai gambar anime
                  _MenuIconImage(
                    imagePath: 'assets/icons/gojo_crasher.png',
                    fallbackIcon: Icons.sports_esports_rounded,
                    label: 'Gojo\nCrasher', color: AppTheme.red,
                    onTap: () => _showGojoDialog(),
                  ),
                ]),

                const SizedBox(height: 22),

                // ── Tombol CS ───────────────────────────────────────────
                Text('HUBUNGI CS', style: AppTheme.eyebrow()),
                const SizedBox(height: 12),
                Row(children: [
                  // WhatsApp — logo asli
                  Expanded(
                    child: GestureDetector(
                      onTap: _openWa,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF25D366).withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFF25D366).withValues(alpha: 0.4)),
                        ),
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          // Logo WA asli dari asset
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              'assets/icons/wa_logo.png',
                              width: 32, height: 32, fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 32, height: 32,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF25D366),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.chat_rounded, color: Colors.white, size: 18),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('WhatsApp', style: AppTheme.body(size: 13, weight: FontWeight.bold,
                                color: const Color(0xFF25D366))),
                            Text('CS Online', style: AppTheme.body(size: 10, color: AppTheme.textSecondary)),
                          ]),
                        ]),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Telegram — logo asli
                  Expanded(
                    child: GestureDetector(
                      onTap: _openTele,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2AABEE).withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFF2AABEE).withValues(alpha: 0.4)),
                        ),
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              'assets/icons/tele_logo.png',
                              width: 32, height: 32, fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 32, height: 32,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF2AABEE),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('Telegram', style: AppTheme.body(size: 13, weight: FontWeight.bold,
                                color: const Color(0xFF2AABEE))),
                            Text('CS & Order', style: AppTheme.body(size: 10, color: AppTheme.textSecondary)),
                          ]),
                        ]),
                      ),
                    ),
                  ),
                ]),

                const SizedBox(height: 20),

                // ── User ID ─────────────────────────────────────────────
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: Row(children: [
                    const Icon(Icons.person_rounded, color: AppTheme.accentLight, size: 18),
                    const SizedBox(width: 10),
                    Expanded(child: Text(widget.userId,
                        style: AppTheme.mono(size: 12, color: AppTheme.textPrimary),
                        overflow: TextOverflow.ellipsis)),
                    GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: widget.userId));
                        _snack('User ID disalin!');
                      },
                      child: const Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 16)),
                  ]),
                ),

                const SizedBox(height: 14),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppTheme.cyan.withValues(alpha: 0.2)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.info_outline_rounded, color: AppTheme.cyan, size: 16),
                    const SizedBox(width: 10),
                    Expanded(child: Text(
                      'Topup via QRIS • Tarik ke DANA/GoPay/OVO/ShopeePay\nPull down untuk refresh saldo.',
                      style: AppTheme.body(size: 11, color: AppTheme.textSecondary))),
                  ]),
                ),
                const SizedBox(height: 20),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  // ── Dialog Petropoldy ────────────────────────────────────────────────────
  void _showPetroDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.card,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _PetroSheet(onWa: _openWa, onTele: _openTele, remotePrices: _panelPrices),
    );
  }

  // ── Dialog Gojo Crasher ──────────────────────────────────────────────────
  void _showGojoDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.card,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _GojoSheet(onWa: _openWa, onTele: _openTele, remotePrices: _gojoPrices),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Bottom sheet Petropoldy
// ─────────────────────────────────────────────────────────────────────────────
class _PetroSheet extends StatelessWidget {
  final VoidCallback onWa, onTele;
  final List<Map<String, dynamic>>? remotePrices;
  const _PetroSheet({required this.onWa, required this.onTele, this.remotePrices});

  // Default — override dari Telegram bot via /setpanel
  static const List<Map<String, dynamic>> _defaultPaket = [
    {'label': '5 GB',      'harga': 7000,  'note': 'Panel Cepat'},
    {'label': '10 GB',     'harga': 12000, 'note': 'Panel Cepat'},
    {'label': 'Unlimited', 'harga': 19000, 'note': 'Panel Cepat — Best Value'},
  ];

  List<Map<String, dynamic>> get _paket =>
      (remotePrices != null && remotePrices!.isNotEmpty) ? remotePrices! : _defaultPaket;

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp ${buf.toString()}';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(
            color: AppTheme.border, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 16),
        Row(children: [
          // Icon Petropoldy — gambar karakter
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: AppTheme.yellow.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                'assets/icons/petropoldy.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.dns_rounded, color: AppTheme.yellow, size: 26),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Beli Panel Petropoldy', style: AppTheme.body(size: 15, weight: FontWeight.bold)),
            Text('Pilih paket & order via CS Miwa Pay', style: AppTheme.body(size: 11, color: AppTheme.textSecondary)),
          ]),
        ]),
        const SizedBox(height: 16),
        ..._paket.map((p) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: AppTheme.cardAlt, borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p['label'], style: AppTheme.body(size: 13, weight: FontWeight.w600)),
              Text(p['note'], style: AppTheme.body(size: 11, color: AppTheme.textSecondary)),
            ])),
            Text(_fmt(p['harga']), style: TextStyle(
                color: AppTheme.accentLight, fontSize: 13, fontWeight: FontWeight.bold)),
          ]),
        )),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _csBtn('WA', const Color(0xFF25D366), 'assets/icons/wa_logo.png', Icons.chat_rounded, onWa)),
          const SizedBox(width: 10),
          Expanded(child: _csBtn('Telegram', const Color(0xFF2AABEE), 'assets/icons/tele_logo.png', Icons.send_rounded, onTele)),
        ]),
        const SizedBox(height: 8),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Bottom sheet Gojo Crasher
// ─────────────────────────────────────────────────────────────────────────────
class _GojoSheet extends StatelessWidget {
  final VoidCallback onWa, onTele;
  final List<Map<String, dynamic>>? remotePrices;
  const _GojoSheet({required this.onWa, required this.onTele, this.remotePrices});

  static const List<Map<String, dynamic>> _defaultPaket = [
    {'label': '1 Hari',  'harga': 1000},
    {'label': '2 Hari',  'harga': 2000},
    {'label': '3 Hari',  'harga': 3000},
    {'label': '4 Hari',  'harga': 4000},
    {'label': '5 Hari',  'harga': 5000},
    {'label': '7 Hari',  'harga': 7000},
    {'label': '14 Hari', 'harga': 12000},
    {'label': '30 Hari', 'harga': 25000},
  ];

  List<Map<String, dynamic>> get _paket =>
      (remotePrices != null && remotePrices!.isNotEmpty) ? remotePrices! : _defaultPaket;

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp ${buf.toString()}';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(
            color: AppTheme.border, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 16),
        Row(children: [
          // Icon Gojo Crasher — pakai gambar anime
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: AppTheme.red.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                'assets/icons/gojo_crasher.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.sports_esports_rounded, color: AppTheme.red, size: 26),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('Beli Akses Akun Gojo Crasher', style: AppTheme.body(size: 15, weight: FontWeight.bold)),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppTheme.red.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.red.withValues(alpha: 0.4)),
                ),
                child: Text('HOT 🔥', style: TextStyle(color: AppTheme.red, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
            ]),
            Text('Order via CS Miwa Pay', style: AppTheme.body(size: 11, color: AppTheme.textSecondary)),
          ]),
        ]),
        const SizedBox(height: 16),
        ..._paket.map((p) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: AppTheme.cardAlt, borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border)),
          child: Row(children: [
            const Icon(Icons.gamepad_rounded, color: AppTheme.red, size: 16),
            const SizedBox(width: 10),
            Expanded(child: Text('Gojo Crasher ${p["label"]}', style: AppTheme.body(size: 13, weight: FontWeight.w600))),
            Text(_fmt(p['harga']), style: TextStyle(
                color: AppTheme.accentLight, fontSize: 13, fontWeight: FontWeight.bold)),
          ]),
        )),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _csBtn('WA', const Color(0xFF25D366), 'assets/icons/wa_logo.png', Icons.chat_rounded, onWa)),
          const SizedBox(width: 10),
          Expanded(child: _csBtn('Telegram', const Color(0xFF2AABEE), 'assets/icons/tele_logo.png', Icons.send_rounded, onTele)),
        ]),
        const SizedBox(height: 8),
      ]),
    );
  }
}

// ── Helper CS button dengan logo asli ──────────────────────────────────────
Widget _csBtn(String label, Color color, String imagePath, IconData fallback, VoidCallback onTap) =>
  GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        // Logo gambar WA / Telegram
        Image.asset(
          imagePath,
          width: 20, height: 20,
          errorBuilder: (_, __, ___) => Icon(fallback, color: color, size: 18),
        ),
        const SizedBox(width: 8),
        Text('Order $label', style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.bold)),
      ]),
    ),
  );

// ─────────────────────────────────────────────────────────────────────────────
// Data class & widgets
// ─────────────────────────────────────────────────────────────────────────────
class _BannerData {
  final String title, subtitle, tag;
  final Color color1, color2;
  final IconData icon;
  final String? imagePath;
  const _BannerData({required this.title, required this.subtitle, required this.tag,
      required this.color1, required this.color2, required this.icon, this.imagePath});
}

class _BannerCard extends StatelessWidget {
  final _BannerData data;
  const _BannerCard({required this.data});
  @override
  Widget build(BuildContext context) {
    final hasImage = data.imagePath != null;
    return Container(
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        gradient: hasImage ? null : LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [data.color1, data.color2]),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: data.color1.withValues(alpha: 0.4), blurRadius: 20, offset: const Offset(0, 6))],
        image: hasImage
            ? DecorationImage(image: AssetImage(data.imagePath!), fit: BoxFit.cover)
            : null,
      ),
      clipBehavior: Clip.antiAlias,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: hasImage
            ? BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft, end: Alignment.centerRight,
                  colors: [Colors.black.withValues(alpha: 0.45), Colors.black.withValues(alpha: 0.05)],
                ),
              )
            : null,
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(6)),
              child: Text(data.tag, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
            ),
            const SizedBox(height: 8),
            Text(data.title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, height: 1.2)),
            const SizedBox(height: 4),
            Text(data.subtitle, style: TextStyle(color: Colors.white.withValues(alpha: 0.8), fontSize: 11)),
          ])),
          if (!hasImage) Icon(data.icon, color: Colors.white.withValues(alpha: 0.25), size: 64),
        ]),
      ),
    );
  }
}

class _MenuIcon extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _MenuIcon({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: 0.35)),
          ),
          child: Icon(icon, color: color, size: 26),
        ),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(color: AppTheme.textSecondary, fontSize: 10, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center),
      ]),
    ),
  );
}

// Menu icon yang support image asset, fallback ke icon Material
class _MenuIconImage extends StatelessWidget {
  final String imagePath;
  final IconData fallbackIcon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _MenuIconImage({required this.imagePath, required this.fallbackIcon,
      required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: 0.35)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.asset(imagePath, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Icon(fallbackIcon, color: color, size: 26)),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(color: AppTheme.textSecondary, fontSize: 10, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center),
      ]),
    ),
  );
}
