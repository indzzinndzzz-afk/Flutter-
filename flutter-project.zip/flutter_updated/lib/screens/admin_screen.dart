import 'package:flutter/material.dart';
import '../services/app_service.dart';
import '../services/user_prefs.dart';
import '../theme/app_theme.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        title: const Text('ADMIN PANEL'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.accentLight,
          labelColor: AppTheme.accentLight,
          unselectedLabelColor: AppTheme.textSecondary,
          labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 0.8),
          tabs: const [
            Tab(icon: Icon(Icons.people_rounded, size: 18), text: 'USERS'),
            Tab(icon: Icon(Icons.upload_rounded, size: 18), text: 'DEPOSIT'),
            Tab(icon: Icon(Icons.download_rounded, size: 18), text: 'WITHDRAW'),
            Tab(icon: Icon(Icons.star_rounded, size: 18), text: 'RATING'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _UsersTab(),
          _DepositTab(),
          _WithdrawTab(),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
// TAB 1 — USERS
// ══════════════════════════════════════════════════════════
class _UsersTab extends StatefulWidget {
  const _UsersTab();

  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  bool _loading = true;
  String? _err;
  List<dynamic> _users = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final token = await UserPrefs.getToken();
    if (token == null) {
      setState(() { _loading = false; _err = 'Token tidak ditemukan'; });
      return;
    }
    final res = await AppService.fetchRegisteredUsers(token);
    if (!mounted) return;
    if (res['success'] == true) {
      setState(() { _users = res['users'] ?? []; _loading = false; });
    } else {
      setState(() { _err = res['message'] ?? 'Gagal memuat data user'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppTheme.accentLight));
    if (_err != null) return Center(child: Text(_err!, style: const TextStyle(color: AppTheme.red)));
    return RefreshIndicator(
      onRefresh: _load,
      color: AppTheme.accentLight,
      child: _users.isEmpty
          ? const Center(child: Text('Belum ada user', style: TextStyle(color: AppTheme.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _users.length,
              itemBuilder: (_, i) {
                final u = _users[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.person_rounded, size: 18, color: AppTheme.accentLight),
                      const SizedBox(width: 6),
                      Text(u['username'] ?? '-',
                          style: const TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      _statusBadge(u['active'] == true ? 'AKTIF' : 'NONAKTIF',
                          u['active'] == true ? AppTheme.green : AppTheme.red),
                    ]),
                    const SizedBox(height: 6),
                    Text('Gmail: ${u['gmail'] ?? '-'}',
                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                    Text('Telp: ${u['phone'] ?? '-'}',
                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                    Text('Daftar: ${u['created_at'] ?? '-'}',
                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
                    Text('Login terakhir: ${u['last_seen'] ?? '-'}',
                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
                  ]),
                );
              },
            ),
    );
  }
}

// ══════════════════════════════════════════════════════════
// TAB 2 — DEPOSIT PENDING
// ══════════════════════════════════════════════════════════
class _DepositTab extends StatefulWidget {
  const _DepositTab();

  @override
  State<_DepositTab> createState() => _DepositTabState();
}

class _DepositTabState extends State<_DepositTab> {
  bool _loading = true;
  String? _err;
  List<dynamic> _items = [];
  final Set<String> _processing = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final token = await UserPrefs.getToken();
    if (token == null) {
      setState(() { _loading = false; _err = 'Token tidak ditemukan'; });
      return;
    }
    final res = await AppService.adminGetPendingDeposits(token);
    if (!mounted) return;
    if (res['success'] == true) {
      setState(() { _items = res['data'] ?? []; _loading = false; });
    } else {
      setState(() { _err = res['message'] ?? 'Gagal memuat deposit'; _loading = false; });
    }
  }

  Future<void> _approve(String invoiceId) async {
    setState(() => _processing.add(invoiceId));
    final token = await UserPrefs.getToken();
    final res = await AppService.adminApproveDeposit(token!, invoiceId);
    if (!mounted) return;
    _snack(res['message'] ?? 'Done', res['success'] == true ? AppTheme.green : AppTheme.red);
    setState(() => _processing.remove(invoiceId));
    if (res['success'] == true) _load();
  }

  Future<void> _reject(String invoiceId) async {
    final confirm = await _confirmDialog('Tolak deposit ini?');
    if (!confirm) return;
    setState(() => _processing.add(invoiceId));
    final token = await UserPrefs.getToken();
    final res = await AppService.adminRejectDeposit(token!, invoiceId);
    if (!mounted) return;
    _snack(res['message'] ?? 'Done', res['success'] == true ? AppTheme.yellow : AppTheme.red);
    setState(() => _processing.remove(invoiceId));
    if (res['success'] == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppTheme.accentLight));
    if (_err != null) return Center(child: Text(_err!, style: const TextStyle(color: AppTheme.red)));
    return RefreshIndicator(
      onRefresh: _load,
      color: AppTheme.accentLight,
      child: _items.isEmpty
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 48),
              SizedBox(height: 12),
              Text('Tidak ada deposit pending', style: TextStyle(color: AppTheme.textSecondary)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final d = _items[i];
                final id = d['invoice_id'] as String? ?? '';
                final isProcessing = _processing.contains(id);
                final fmtRp = (num n) => 'Rp${n.toStringAsFixed(0).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.')}';
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.yellow.withValues(alpha: 0.4)),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.upload_rounded, size: 16, color: AppTheme.yellow),
                      const SizedBox(width: 6),
                      Expanded(child: Text(id,
                          style: const TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.bold, fontSize: 13))),
                      _statusBadge('PENDING', AppTheme.yellow),
                    ]),
                    const SizedBox(height: 8),
                    _infoRow(Icons.person_rounded, 'User', d['user_id'] ?? '-'),
                    _infoRow(Icons.payments_rounded, 'Nominal', fmtRp(d['amount'] ?? 0)),
                    _infoRow(Icons.access_time_rounded, 'Waktu', _fmtTime(d['created_at'])),
                    if (d['bukti_url'] != null) ...[
                      const SizedBox(height: 8),
                      GestureDetector(
                        onTap: () => _showBukti(context, d['bukti_url']),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppTheme.accent.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: AppTheme.accent.withValues(alpha: 0.3)),
                          ),
                          child: const Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.image_rounded, color: AppTheme.accentLight, size: 14),
                            SizedBox(width: 6),
                            Text('Lihat Bukti', style: TextStyle(color: AppTheme.accentLight, fontSize: 12)),
                          ]),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(
                        child: _actionBtn(
                          label: 'TOLAK',
                          icon: Icons.cancel_rounded,
                          color: AppTheme.red,
                          loading: isProcessing,
                          onTap: () => _reject(id),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _actionBtn(
                          label: 'APPROVE',
                          icon: Icons.check_circle_rounded,
                          color: AppTheme.green,
                          loading: isProcessing,
                          onTap: () => _approve(id),
                        ),
                      ),
                    ]),
                  ]),
                );
              },
            ),
    );
  }

  void _showBukti(BuildContext ctx, String url) {
    final fullUrl = '${AppService.baseUrl}$url';
    showDialog(
      context: ctx,
      builder: (_) => Dialog(
        backgroundColor: AppTheme.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 12),
          const Text('Bukti Transfer', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
            child: Image.network(fullUrl, fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('Gagal load gambar', style: TextStyle(color: AppTheme.red)),
                )),
          ),
        ]),
      ),
    );
  }

  Future<bool> _confirmDialog(String msg) async {
    return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: AppTheme.card,
            title: const Text('Konfirmasi', style: TextStyle(color: AppTheme.textPrimary)),
            content: Text(msg, style: const TextStyle(color: AppTheme.textSecondary)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false),
                  child: const Text('Batal', style: TextStyle(color: AppTheme.textSecondary))),
              TextButton(onPressed: () => Navigator.pop(context, true),
                  child: const Text('Ya', style: TextStyle(color: AppTheme.red))),
            ],
          ),
        ) ??
        false;
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: color));
  }
}

// ══════════════════════════════════════════════════════════
// TAB 3 — WITHDRAW PENDING
// ══════════════════════════════════════════════════════════
class _WithdrawTab extends StatefulWidget {
  const _WithdrawTab();

  @override
  State<_WithdrawTab> createState() => _WithdrawTabState();
}

class _WithdrawTabState extends State<_WithdrawTab> {
  bool _loading = true;
  String? _err;
  List<dynamic> _items = [];
  final Set<String> _processing = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final token = await UserPrefs.getToken();
    if (token == null) {
      setState(() { _loading = false; _err = 'Token tidak ditemukan'; });
      return;
    }
    final res = await AppService.adminGetPendingWithdrawals(token);
    if (!mounted) return;
    if (res['success'] == true) {
      setState(() { _items = res['data'] ?? []; _loading = false; });
    } else {
      setState(() { _err = res['message'] ?? 'Gagal memuat withdraw'; _loading = false; });
    }
  }

  Future<void> _approve(String trxId) async {
    setState(() => _processing.add(trxId));
    final token = await UserPrefs.getToken();
    final res = await AppService.adminApproveWithdrawal(token!, trxId);
    if (!mounted) return;
    _snack(res['message'] ?? 'Done', res['success'] == true ? AppTheme.green : AppTheme.red);
    setState(() => _processing.remove(trxId));
    if (res['success'] == true) _load();
  }

  Future<void> _reject(String trxId) async {
    final confirm = await _confirmDialog('Tolak withdraw ini? Saldo akan di-refund ke user.');
    if (!confirm) return;
    setState(() => _processing.add(trxId));
    final token = await UserPrefs.getToken();
    final res = await AppService.adminRejectWithdrawal(token!, trxId);
    if (!mounted) return;
    _snack(res['message'] ?? 'Done', res['success'] == true ? AppTheme.yellow : AppTheme.red);
    setState(() => _processing.remove(trxId));
    if (res['success'] == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppTheme.accentLight));
    if (_err != null) return Center(child: Text(_err!, style: const TextStyle(color: AppTheme.red)));
    return RefreshIndicator(
      onRefresh: _load,
      color: AppTheme.accentLight,
      child: _items.isEmpty
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 48),
              SizedBox(height: 12),
              Text('Tidak ada withdraw pending', style: TextStyle(color: AppTheme.textSecondary)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final w = _items[i];
                final id = w['trx_id'] as String? ?? '';
                final isProcessing = _processing.contains(id);
                final fmtRp = (num n) => 'Rp${n.toStringAsFixed(0).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.')}';
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.cyan.withValues(alpha: 0.4)),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.download_rounded, size: 16, color: AppTheme.cyan),
                      const SizedBox(width: 6),
                      Expanded(child: Text(id,
                          style: const TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.bold, fontSize: 13))),
                      _statusBadge('PENDING', AppTheme.yellow),
                    ]),
                    const SizedBox(height: 8),
                    _infoRow(Icons.person_rounded, 'User', w['username'] ?? w['user_id'] ?? '-'),
                    _infoRow(Icons.account_balance_wallet_rounded, 'E-Wallet',
                        '${(w['ewallet'] as String? ?? '-').toUpperCase()} • ${w['nomor'] ?? '-'}'),
                    _infoRow(Icons.badge_rounded, 'Nama Akun', w['nama_akun'] ?? '-'),
                    _infoRow(Icons.payments_rounded, 'Nominal', fmtRp(w['nominal'] ?? 0)),
                    _infoRow(Icons.remove_circle_rounded, 'Total Dipotong', fmtRp(w['total_potong'] ?? 0)),
                    _infoRow(Icons.access_time_rounded, 'Waktu', _fmtTime(w['created_at'])),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(
                        child: _actionBtn(
                          label: 'TOLAK',
                          icon: Icons.cancel_rounded,
                          color: AppTheme.red,
                          loading: isProcessing,
                          onTap: () => _reject(id),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _actionBtn(
                          label: 'SELESAI',
                          icon: Icons.check_circle_rounded,
                          color: AppTheme.green,
                          loading: isProcessing,
                          onTap: () => _approve(id),
                        ),
                      ),
                    ]),
                  ]),
                );
              },
            ),
    );
  }

  Future<bool> _confirmDialog(String msg) async {
    return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: AppTheme.card,
            title: const Text('Konfirmasi', style: TextStyle(color: AppTheme.textPrimary)),
            content: Text(msg, style: const TextStyle(color: AppTheme.textSecondary)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false),
                  child: const Text('Batal', style: TextStyle(color: AppTheme.textSecondary))),
              TextButton(onPressed: () => Navigator.pop(context, true),
                  child: const Text('Ya', style: TextStyle(color: AppTheme.red))),
            ],
          ),
        ) ??
        false;
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: color));
  }
}

// ══════════════════════════════════════════════════════════
// SHARED HELPERS
// ══════════════════════════════════════════════════════════

Widget _statusBadge(String label, Color color) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.bold)),
    );

Widget _infoRow(IconData icon, String label, String value) => Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(children: [
        Icon(icon, size: 13, color: AppTheme.textSecondary),
        const SizedBox(width: 6),
        Text('$label: ', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
        Expanded(child: Text(value,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 12),
            overflow: TextOverflow.ellipsis)),
      ]),
    );

Widget _actionBtn({
  required String label,
  required IconData icon,
  required Color color,
  required bool loading,
  required VoidCallback onTap,
}) =>
    GestureDetector(
      onTap: loading ? null : onTap,
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.5)),
        ),
        child: loading
            ? Center(child: SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: color)))
            : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icon, color: color, size: 16),
                const SizedBox(width: 6),
                Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold)),
              ]),
      ),
    );

String _fmtTime(String? iso) {
  if (iso == null) return '-';
  try {
    final dt = DateTime.parse(iso).toLocal();
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year} '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  } catch (_) {
    return iso;
  }
}

// ══════════════════════════════════════════════════════════
// TAB 4 — RATING (ADMIN)
// ══════════════════════════════════════════════════════════
class _RatingAdminTab extends StatefulWidget {
  const _RatingAdminTab();

  @override
  State<_RatingAdminTab> createState() => _RatingAdminTabState();
}

class _RatingAdminTabState extends State<_RatingAdminTab> {
  bool _loading = true;
  String? _err;
  List<dynamic> _items = [];
  final Set<String> _deleting = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final token = await UserPrefs.getToken();
    if (token == null) {
      setState(() { _loading = false; _err = 'Token tidak ditemukan'; });
      return;
    }
    final res = await AppService.adminGetAllRatings(token);
    if (!mounted) return;
    if (res['success'] == true) {
      setState(() { _items = res['data'] ?? []; _loading = false; });
    } else {
      setState(() { _err = res['message'] ?? 'Gagal memuat rating'; _loading = false; });
    }
  }

  Future<void> _delete(String userId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.card,
        title: const Text('Hapus Rating?', style: TextStyle(color: AppTheme.textPrimary)),
        content: Text('Rating dari $userId akan dihapus.',
            style: const TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('Batal', style: TextStyle(color: AppTheme.textSecondary))),
          TextButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Hapus', style: TextStyle(color: AppTheme.red))),
        ],
      ),
    ) ?? false;
    if (!ok) return;

    setState(() => _deleting.add(userId));
    final token = await UserPrefs.getToken();
    final res = await AppService.adminDeleteRating(token!, userId);
    if (!mounted) return;
    _snack(res['message'] ?? 'Done',
        res['success'] == true ? AppTheme.green : AppTheme.red);
    setState(() => _deleting.remove(userId));
    if (res['success'] == true) _load();
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: color));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppTheme.accentLight));
    if (_err != null) return Center(child: Text(_err!, style: const TextStyle(color: AppTheme.red)));
    return RefreshIndicator(
      onRefresh: _load,
      color: AppTheme.accentLight,
      child: _items.isEmpty
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.star_border_rounded, color: AppTheme.textSecondary, size: 48),
              SizedBox(height: 12),
              Text('Belum ada rating', style: TextStyle(color: AppTheme.textSecondary)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final r = _items[i];
                final uid = r['user_id'] as String? ?? '';
                final star = (r['star'] as num?)?.toInt() ?? 0;
                final comment = r['comment'] as String? ?? '';
                final isDeleting = _deleting.contains(uid);

                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    CircleAvatar(
                      backgroundColor: AppTheme.accent.withValues(alpha: 0.2),
                      radius: 20,
                      child: Text(
                        uid.isEmpty ? '?' : uid[0].toUpperCase(),
                        style: const TextStyle(
                            color: AppTheme.accentLight, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(uid, style: const TextStyle(
                          color: AppTheme.textPrimary, fontWeight: FontWeight.bold, fontSize: 13)),
                      const SizedBox(height: 4),
                      Row(children: List.generate(5, (s) => Icon(
                          s < star ? Icons.star_rounded : Icons.star_border_rounded,
                          color: AppTheme.yellow, size: 14))),
                      if (comment.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(comment, style: const TextStyle(
                            color: AppTheme.textSecondary, fontSize: 12)),
                      ],
                      const SizedBox(height: 4),
                      Text(_fmtTime(r['created_at']),
                          style: const TextStyle(color: AppTheme.textMuted, fontSize: 11)),
                    ])),
                    isDeleting
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.red))
                        : GestureDetector(
                            onTap: () => _delete(uid),
                            child: const Icon(Icons.delete_rounded,
                                color: AppTheme.red, size: 20),
                          ),
                  ]),
                );
              },
            ),
    );
  }
}
