import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  // Init Firebase
  await Firebase.initializeApp();
  // Init FCM + audio
  await NotificationService.init();
  runApp(const MiwaChanOTPApp());
}

class MiwaChanOTPApp extends StatelessWidget {
  const MiwaChanOTPApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Simpan navigatorKey supaya NotificationService bisa show snackbar
    final navKey = GlobalKey<NavigatorState>();
    NotificationService.navigatorKey = navKey;
    return MaterialApp(
      title: 'MiwaChan OTP',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      navigatorKey: navKey,
      home: const SplashScreen(),
    );
  }
}
