package com.miwachan.otp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
