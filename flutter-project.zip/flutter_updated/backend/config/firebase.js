const admin = require('firebase-admin');

let app;

function initFirebase() {
  if (app) return app;

  // Opsi A (REKOMENDASI buat VPS/Pterodactyl/Railway): isi seluruh JSON
  // service account ke ENV var FIREBASE_SERVICE_ACCOUNT (base64 atau raw JSON).
  // Opsi B: simpan file serviceAccountKey.json di root project (JANGAN dicommit ke git!)
  //         lalu set GOOGLE_APPLICATION_CREDENTIALS=./serviceAccountKey.json
  let credential;

  if (process.env.FIREBASE_SERVICE_ACCOUNT) {
    let raw = process.env.FIREBASE_SERVICE_ACCOUNT.trim();
    // Auto-detect base64 vs raw JSON
    if (!raw.startsWith('{')) {
      raw = Buffer.from(raw, 'base64').toString('utf8');
    }
    const serviceAccount = JSON.parse(raw);
    credential = admin.credential.cert(serviceAccount);
  } else {
    // Fallback: pakai GOOGLE_APPLICATION_CREDENTIALS atau default app credentials
    credential = admin.credential.applicationDefault();
  }

  app = admin.initializeApp({ credential });
  return app;
}

const firebaseApp = initFirebase();
const db = admin.firestore(firebaseApp);

module.exports = { admin, firebaseApp, db };
