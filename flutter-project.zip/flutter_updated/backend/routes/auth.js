const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { generateToken, authMiddleware, requireAdmin } = require('../middleware/auth');
const { readUsers, writeUsers, findUserKeyByUsername, readConfig, writeConfig,
        createPasswordReset, getPasswordReset, updatePasswordReset, deletePasswordReset } = require('../config/db');
const { sendMessage } = require('../config/telegram');

const USERNAME_RE = /^[a-zA-Z0-9_]{4,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^[0-9+][0-9\s-]{7,15}$/;

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || '';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const ADMIN_TG_ID   = process.env.TELEGRAM_ADMIN_ID || '';

function genToken6() {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

/** POST /api/auth/register */
router.post('/register', async (req, res) => {
  try {
    const { username, password, gmail, phone } = req.body || {};
    if (!username || !USERNAME_RE.test(String(username).trim()))
      return res.status(400).json({ success: false, message: 'Username harus 4-20 karakter, huruf/angka/underscore saja' });
    if (!password || String(password).length < 6)
      return res.status(400).json({ success: false, message: 'Password minimal 6 karakter' });
    if (!gmail || !EMAIL_RE.test(String(gmail).trim()))
      return res.status(400).json({ success: false, message: 'Format gmail/email tidak valid' });
    if (!phone || !PHONE_RE.test(String(phone).trim()))
      return res.status(400).json({ success: false, message: 'Format nomor telepon tidak valid' });

    const cleanUsername = String(username).trim();
    const cleanGmail    = String(gmail).trim().toLowerCase();
    const cleanPhone    = String(phone).trim();
    const users         = await readUsers();

    if (findUserKeyByUsername(users, cleanUsername))
      return res.status(409).json({ success: false, message: 'Username sudah dipakai, coba yang lain' });
    if (ADMIN_USERNAME && cleanUsername.toLowerCase() === ADMIN_USERNAME.toLowerCase())
      return res.status(409).json({ success: false, message: 'Username sudah dipakai, coba yang lain' });
    if (Object.values(users).some((u) => u.gmail === cleanGmail))
      return res.status(409).json({ success: false, message: 'Gmail ini sudah terdaftar' });

    const hashed = await bcrypt.hash(String(password), 10);
    users[cleanUsername] = {
      username: cleanUsername, password: hashed,
      gmail: cleanGmail, phone: cleanPhone,
      role: 'user', active: true,
      created_at: new Date().toISOString(),
      last_seen: new Date().toISOString(),
      login_count: 1,
    };
    await writeUsers(users);

    const token = generateToken({ userId: cleanUsername, role: 'user' });
    return res.json({ success: true, message: 'Pendaftaran berhasil', token, userId: cleanUsername, role: 'user', expiresIn: '30d' });
  } catch (err) {
    console.error('[REGISTER ERROR]', err);
    return res.status(500).json({ success: false, message: 'Gagal mendaftar, coba lagi' });
  }
});

/** POST /api/auth/login */
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password)
      return res.status(400).json({ success: false, message: 'Username dan password wajib diisi' });
    const cleanUsername = String(username).trim();

    if (ADMIN_USERNAME && ADMIN_PASSWORD && cleanUsername.toLowerCase() === ADMIN_USERNAME.toLowerCase()) {
      if (password === ADMIN_PASSWORD) {
        const token = generateToken({ userId: ADMIN_USERNAME, role: 'admin' });
        return res.json({ success: true, token, userId: ADMIN_USERNAME, role: 'admin', expiresIn: '30d' });
      }
      return res.status(401).json({ success: false, message: 'Username atau password salah' });
    }

    const users = await readUsers();
    const key   = findUserKeyByUsername(users, cleanUsername);
    if (!key) return res.status(401).json({ success: false, message: 'Username atau password salah' });

    const user  = users[key];
    const match = await bcrypt.compare(String(password), user.password);
    if (!match) return res.status(401).json({ success: false, message: 'Username atau password salah' });

    user.last_seen   = new Date().toISOString();
    user.login_count = (user.login_count || 0) + 1;
    await writeUsers(users);

    const token = generateToken({ userId: user.username, role: 'user' });
    return res.json({ success: true, token, userId: user.username, role: 'user', expiresIn: '30d' });
  } catch (err) {
    console.error('[LOGIN ERROR]', err);
    return res.status(500).json({ success: false, message: 'Gagal login, coba lagi' });
  }
});

/** POST /api/auth/verify */
router.post('/verify', (req, res) => {
  authMiddleware(req, res, () => res.json({ success: true, user: req.user }));
});

/**
 * POST /api/auth/forgot-password
 * Flow baru: user kirim email → backend cek user → buat pending reset
 *           → kirim notif ke admin Telegram dg tombol APPROVE / CANCEL
 * User menunggu, app polling /api/auth/reset-status?token=xxx
 */
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email || !EMAIL_RE.test(String(email).trim()))
      return res.status(400).json({ success: false, message: 'Format email tidak valid' });

    const cleanEmail = String(email).trim().toLowerCase();
    const users      = await readUsers();
    const userEntry  = Object.values(users).find((u) => u.gmail === cleanEmail);

    if (!userEntry)
      return res.status(404).json({ success: false, message: 'Email tidak terdaftar' });

    // Buat token unik & password baru sementara
    const resetToken  = genToken6() + genToken6(); // 12 char
    const newPassword = genToken6() + genToken6();  // 12 char — dikirim ke user setelah approve

    await createPasswordReset(resetToken, {
      username:    userEntry.username,
      email:       cleanEmail,
      newPassword,
      status:      'pending',  // pending | approved | cancelled
      createdAt:   Date.now(),
    });

    // Kirim notif ke admin Telegram
    if (ADMIN_TG_ID) {
      const tgMsg =
        `🔑 *REQUEST RESET PASSWORD*\n\n` +
        `👤 Username: \`${userEntry.username}\`\n` +
        `📧 Email: \`${cleanEmail}\`\n` +
        `🔐 Password baru: \`${newPassword}\`\n` +
        `🕐 Waktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}\n\n` +
        `_Token: ${resetToken}_\n\n` +
        `Pilih tindakan:`;

      await sendMessage(ADMIN_TG_ID, tgMsg, [
        [
          { text: '✅ APPROVE — Kirim Password Baru', callback_data: `reset_approve_${resetToken}` },
        ],
        [
          { text: '❌ CANCEL — Tolak Request', callback_data: `reset_cancel_${resetToken}` },
        ],
      ]);
    }

    return res.json({
      success: true,
      message: 'Permintaan reset sudah dikirim ke admin. Mohon tunggu konfirmasi.',
      resetToken,  // dipakai Flutter untuk polling status
    });
  } catch (err) {
    console.error('[FORGOT PASSWORD ERROR]', err);
    return res.status(500).json({ success: false, message: 'Gagal kirim request, coba lagi' });
  }
});

/**
 * GET /api/auth/reset-status?token=xxx
 * Flutter polling ini tiap beberapa detik.
 * Kalau approved → return password baru (agar user bisa login langsung)
 */
router.get('/reset-status', async (req, res) => {
  const { token } = req.query;
  if (!token) return res.status(400).json({ success: false, message: 'Token tidak valid' });

  const pending = await getPasswordReset(token);
  if (!pending) return res.status(404).json({ success: false, message: 'Token tidak ditemukan atau sudah kedaluwarsa' });

  // Hapus request lama (>24 jam)
  if (Date.now() - pending.createdAt > 86400000) {
    await deletePasswordReset(token);
    return res.status(410).json({ success: false, message: 'Request sudah kedaluwarsa, coba lagi' });
  }

  if (pending.status === 'pending') {
    return res.json({ success: true, status: 'pending', message: 'Menunggu konfirmasi admin...' });
  }

  if (pending.status === 'cancelled') {
    await deletePasswordReset(token);
    return res.json({ success: true, status: 'cancelled', message: 'Request ditolak oleh admin. Hubungi CS jika ada kendala.' });
  }

  if (pending.status === 'approved') {
    // Sudah diapprove — kembalikan password baru ke Flutter agar user bisa set sendiri
    // atau langsung login
    await deletePasswordReset(token);
    return res.json({
      success:     true,
      status:      'approved',
      message:     'Reset disetujui! Silakan set password baru kamu.',
      username:    pending.username,
      tempPassword: pending.newPassword,
    });
  }
});

/**
 * POST /api/auth/reset-password
 * Setelah user dapat tempPassword dari /reset-status approved,
 * mereka bisa set password baru via endpoint ini.
 * Body: { username, tempPassword, newPassword }
 */
router.post('/reset-password', async (req, res) => {
  try {
    const { username, tempPassword, newPassword } = req.body || {};
    if (!username || !tempPassword || !newPassword)
      return res.status(400).json({ success: false, message: 'Data tidak lengkap' });
    if (String(newPassword).length < 6)
      return res.status(400).json({ success: false, message: 'Password baru minimal 6 karakter' });

    const users = await readUsers();
    const key   = findUserKeyByUsername(users, username);
    if (!key) return res.status(404).json({ success: false, message: 'User tidak ditemukan' });

    const user = users[key];

    // Verifikasi tempPassword — kalau cocok berarti memang dari admin approve
    const match = await bcrypt.compare(tempPassword, user.password);
    // Note: tempPassword belum di-hash, sedangkan user.password sudah di-hash.
    // Jadi kita simpan tempPassword verifikasi secara langsung via field terpisah.
    if (user.temp_reset_password !== tempPassword) {
      return res.status(403).json({ success: false, message: 'Temp password tidak valid' });
    }

    const hashed = await bcrypt.hash(String(newPassword), 10);
    user.password            = hashed;
    user.temp_reset_password = null;
    user.last_seen           = new Date().toISOString();
    await writeUsers(users);

    const token = generateToken({ userId: user.username, role: 'user' });
    return res.json({ success: true, message: 'Password berhasil diperbarui!', token, userId: user.username, role: 'user' });
  } catch (err) {
    console.error('[RESET PASSWORD ERROR]', err);
    return res.status(500).json({ success: false, message: 'Gagal reset password' });
  }
});

/** GET /api/auth/users — KHUSUS ADMIN */
router.get('/users', authMiddleware, requireAdmin, async (req, res) => {
  const users = await readUsers();
  const list  = Object.values(users).map((u) => ({
    username: u.username, gmail: u.gmail, phone: u.phone,
    active: u.active, created_at: u.created_at,
    last_seen: u.last_seen, login_count: u.login_count,
  }));
  list.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ success: true, total: list.length, users: list });
});

module.exports = router;
