const express = require('express');
const router  = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { readConfig, readUsers, writeUsers, readWithdrawals, writeWithdrawals } = require('../config/db');
const { sendTelegramNotif } = require('../config/telegram');

const ADMIN_FEE = 1500; // fee admin per withdraw, flat

// ─── DEFAULT HARGA — bisa dioverride via Telegram bot ───────────────────────
const DEFAULT_GOJO_PRICES = [
  { label: '1 Hari',   harga: 1000,  jam: 24 },
  { label: '2 Hari',   harga: 2000,  jam: 48 },
  { label: '3 Hari',   harga: 3000,  jam: 72 },
  { label: '4 Hari',   harga: 4000,  jam: 96 },
  { label: '5 Hari',   harga: 5000,  jam: 120 },
  { label: '7 Hari',   harga: 7000,  jam: 168 },
  { label: '14 Hari',  harga: 12000, jam: 336 },
  { label: '30 Hari',  harga: 25000, jam: 720 },
];

const DEFAULT_PANEL_PRICES = [
  { label: '5 GB',      harga: 7000,  note: 'Panel Cepat' },
  { label: '10 GB',     harga: 12000, note: 'Panel Cepat' },
  { label: 'Unlimited', harga: 19000, note: 'Panel Cepat — Best Value' },
];

router.use(authMiddleware);

// ─── GET /api/fr3/saldo ───────────────────────────────────────────────────────
router.get('/saldo', async (req, res) => {
  try {
    const users = await readUsers();
    const user  = users[req.user.userId];
    res.json({ success: true, data: { saldo: user?.saldo || 0 } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal cek saldo' });
  }
});

// ─── POST /api/fr3/withdraw ───────────────────────────────────────────────────
// Full manual: saldo TIDAK dipotong saat submit.
// Saldo dipotong saat admin konfirmasi (confirm_wd) via Telegram.
// Kalau admin tolak, tidak perlu refund karena belum dipotong.
// Data nama_akun ewallet dan nomor dikirim ke Telegram, gmail diambil dari profil user.
router.post('/withdraw', async (req, res) => {
  const { ewallet, nomor, nominal, nama_akun } = req.body;
  const userId = req.user.userId;

  if (!ewallet || !nomor || !nominal)
    return res.status(400).json({ success: false, message: 'ewallet, nomor, nominal wajib' });

  const amount = Number(nominal);
  if (isNaN(amount) || amount < 1000)
    return res.status(400).json({ success: false, message: 'Nominal minimal Rp1.000' });

  const totalPotong = amount + ADMIN_FEE;

  const users = await readUsers();
  const user  = users[userId];
  if (!user) return res.status(404).json({ success: false, message: 'User tidak ditemukan' });

  // Cek saldo cukup saat submit (tapi belum dipotong)
  const saldoSekarang = user.saldo || 0;
  if (saldoSekarang < totalPotong) {
    return res.status(400).json({
      success: false,
      message: `Saldo tidak cukup. Butuh Rp${totalPotong.toLocaleString('id-ID')} (termasuk fee admin Rp${ADMIN_FEE.toLocaleString('id-ID')}), saldo kamu Rp${saldoSekarang.toLocaleString('id-ID')}`,
    });
  }

  // Simpan withdraw request dengan status pending — saldo BELUM dipotong
  const trxId = `WD-${Date.now()}`;
  const withdrawals = await readWithdrawals();
  withdrawals[trxId] = {
    trx_id: trxId,
    user_id: userId,
    username: user.username || userId,
    gmail_user: user.gmail || '-',
    ewallet,
    nomor,
    nama_akun: nama_akun || '-',
    nominal: amount,
    admin_fee: ADMIN_FEE,
    total_potong: totalPotong,
    status: 'pending',
    created_at: new Date().toISOString(),
  };
  await writeWithdrawals(withdrawals);

  const fmtRp = (n) => `Rp${Number(n).toLocaleString('id-ID')}`;
  const msg =
    `💸 *WITHDRAW BARU MASUK*\n\n` +
    `👤 User: \`${user.username || userId}\`\n` +
    `📧 Gmail Miwa Pay: \`${user.gmail || '-'}\`\n` +
    `🧾 Trx: \`${trxId}\`\n` +
    `📱 E-wallet: *${ewallet.toUpperCase()}*\n` +
    `👛 Nama Akun: \`${nama_akun || '-'}\`\n` +
    `☎️ Nomor: \`${nomor}\`\n` +
    `💵 Nominal: *${fmtRp(amount)}*\n` +
    `💳 Fee admin: ${fmtRp(ADMIN_FEE)}\n` +
    `📉 Total potong: *${fmtRp(totalPotong)}*\n` +
    `💰 Saldo user: *${fmtRp(saldoSekarang)}*\n` +
    `🕐 Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
    `_Transfer manual ke nomor di atas, lalu konfirmasi di bawah._`;

  const buttons = [[
    { text: '✅ Sudah Transfer', callback_data: `confirm_wd:${trxId}` },
    { text: '❌ Tolak', callback_data: `cancel_wd:${trxId}` },
  ]];

  await sendTelegramNotif(msg, buttons).catch(console.error);

  res.json({
    success: true,
    message: 'Permintaan withdraw terkirim! Tunggu konfirmasi admin ya 🙏',
    trxId,
    data: { trx_id: trxId, status: 'pending', total_potong: totalPotong },
  });
});

// ─── GET /api/fr3/withdraw-config ─────────────────────────────────────────────
router.get('/withdraw-config', async (req, res) => {
  try {
    const cfg = await readConfig();
    const nominalList = cfg.withdraw_nominals || [
      10000, 20000, 30000, 50000, 75000, 100000, 150000, 200000
    ];
    const gojoPrices  = cfg.gojo_prices  || DEFAULT_GOJO_PRICES;
    const panelPrices = cfg.panel_prices || DEFAULT_PANEL_PRICES;

    res.json({
      success: true,
      admin_fee: ADMIN_FEE,
      nominal_list: nominalList,
      gojo_prices: gojoPrices,
      panel_prices: panelPrices,
    });
  } catch (err) {
    res.status(500).json({
      success: false, admin_fee: ADMIN_FEE,
      nominal_list: [10000, 20000, 30000, 50000, 75000, 100000],
      gojo_prices: DEFAULT_GOJO_PRICES,
      panel_prices: DEFAULT_PANEL_PRICES,
    });
  }
});

// ─── GET /api/fr3/trx/status?trxId=xxx ───────────────────────────────────────
router.get('/trx/status', async (req, res) => {
  const { trxId } = req.query;
  if (!trxId) return res.status(400).json({ success: false, message: 'trxId wajib' });
  const withdrawals = await readWithdrawals();
  const trx = withdrawals[trxId];
  if (!trx) return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan' });
  res.json({ success: true, data: trx });
});

// ─── GET /api/fr3/history?page=1 ─────────────────────────────────────────────
router.get('/history', async (req, res) => {
  const userId = req.user.userId;
  const page   = Number(req.query.page) || 1;
  const limit  = 20;
  const withdrawals = await readWithdrawals();
  const myTrx = Object.values(withdrawals)
    .filter(w => w.user_id === userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const start = (page - 1) * limit;
  const pageData = myTrx.slice(start, start + limit);
  res.json({ success: true, data: pageData, hasMore: myTrx.length > start + limit });
});

module.exports = router;
