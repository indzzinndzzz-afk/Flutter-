const express = require('express');
const router  = express.Router();
const { ruangOTP }       = require('../config/ruangotp');
const { authMiddleware } = require('../middleware/auth');
const { sendTelegramNotif } = require('../config/telegram');
const { readConfig, readOrders, writeOrders, readUsers, writeUsers } = require('../config/db');

router.use(authMiddleware);

function fmtRp(n) { return `Rp${Number(n).toLocaleString('id-ID')}`; }

// POST /api/orders/buy
router.post('/buy', async (req, res) => {
  const { product_code, operator_id, expected_price, service_name, country_name } = req.body;

  if (!product_code || !operator_id || !expected_price) {
    return res.status(400).json({
      success: false,
      message: 'product_code, operator_id, expected_price wajib diisi',
    });
  }

  const cfg = await readConfig();
  if (cfg.maintenance) {
    return res.status(503).json({ success: false, maintenance: true, message: cfg.maintenance_msg });
  }

  try {
    const { data } = await ruangOTP.get('/orders/buy', {
      params: { product_code, operator_id, expected_price },
      headers: { 'x-user-id': req.user.userId },
    });

    if (data.success) {
      const invoiceId = data.data?.invoice_id || `ORD-${Date.now()}`;

      // Simpan ke orders log
      const orders = await readOrders();
      orders[invoiceId] = {
        invoice_id: invoiceId,
        user_id: req.user.userId,
        product_code,
        service_name: service_name || product_code,
        country_name: country_name || operator_id,
        price: Number(expected_price),
        status: 'pending',
        created_at: new Date().toISOString(),
      };
      await writeOrders(orders);

      // Update user stats
      const users = await readUsers();
      if (users[req.user.userId]) {
        users[req.user.userId].total_orders   = (users[req.user.userId].total_orders || 0) + 1;
        users[req.user.userId].last_activity  = new Date().toISOString();
        await writeUsers(users);
      }

      // Notif Telegram
      const msg =
        `🛒 *ORDER OTP BARU*\n\n` +
        `👤 User: \`${req.user.userId}\`\n` +
        `📱 Layanan: *${service_name || product_code}*\n` +
        `🌍 Negara: ${country_name || operator_id}\n` +
        `💵 Harga: *${fmtRp(expected_price)}*\n` +
        `🧾 Invoice: \`${invoiceId}\`\n` +
        `🕐 Waktu: ${new Date().toLocaleString('id-ID')}`;
      sendTelegramNotif(msg).catch(console.error);
    }

    res.json(data);
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.response?.data?.message || 'Gagal beli OTP',
      detail: err.response?.data || null,
    });
  }
});

// GET /api/orders/status
router.get('/status', async (req, res) => {
  const { invoice_id } = req.query;
  if (!invoice_id) return res.status(400).json({ success: false, message: 'invoice_id wajib' });

  try {
    const { data } = await ruangOTP.get('/orders/check-status', {
      params: { invoice_id },
      headers: { 'x-user-id': req.user.userId },
    });

    // Sinkronisasi status ke orders log
    if (data.success && data.data?.status) {
      const orders = await readOrders();
      if (orders[invoice_id]) {
        orders[invoice_id].status     = data.data.status;
        orders[invoice_id].updated_at = new Date().toISOString();
        if (data.data.otp_code) orders[invoice_id].otp_code = data.data.otp_code;
        await writeOrders(orders);
      }
    }

    res.json(data);
  } catch (err) {
    res.status(500).json({ success: false, message: err.response?.data?.message || 'Gagal cek status order' });
  }
});

// POST /api/orders/cancel
router.post('/cancel', async (req, res) => {
  const { invoice_id } = req.body;
  if (!invoice_id) return res.status(400).json({ success: false, message: 'invoice_id wajib' });

  try {
    const { data } = await ruangOTP.get('/orders/cancel', {
      params: { invoice_id },
      headers: { 'x-user-id': req.user.userId },
    });

    if (data.success) {
      const orders = await readOrders();
      if (orders[invoice_id]) {
        orders[invoice_id].status     = 'cancelled';
        orders[invoice_id].updated_at = new Date().toISOString();
        await writeOrders(orders);
      }
    }

    res.json(data);
  } catch (err) {
    res.status(500).json({ success: false, message: err.response?.data?.message || 'Gagal cancel order' });
  }
});

module.exports = router;
