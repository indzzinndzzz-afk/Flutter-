const { readConfig } = require('../config/db');

async function maintenanceMiddleware(req, res, next) {
  // Skip untuk endpoint status check (/api/app/status) biar Flutter bisa tau
  if (req.path === '/status' || req.path === '/api/app/status') return next();

  try {
    const cfg = await readConfig();
    if (cfg.maintenance) {
      return res.status(503).json({
        success: false,
        maintenance: true,
        message: cfg.maintenance_msg || '🔧 Server sedang maintenance. Tunggu bentar ya!',
      });
    }
    next();
  } catch (err) {
    console.error('[MAINTENANCE MIDDLEWARE ERROR]', err);
    next(err);
  }
}

module.exports = { maintenanceMiddleware };
