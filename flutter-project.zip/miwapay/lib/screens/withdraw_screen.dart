import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/fr3_service.dart';
import '../theme/app_theme.dart';

class WithdrawScreen extends StatefulWidget {
  final String userId;
  const WithdrawScreen({super.key, required this.userId});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final _namaCtrl    = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _nominalCtrl = TextEditingController();

  String _ewallet = 'dana';
  bool _loading = false;
  bool _submitted = false;
  String? _trxId;
  int _saldo = 0;
  int _adminFee = 200;
  List<int> _nominalList = [10000, 20000, 30000, 50000, 75000, 100000];

  // Polling state
  Timer? _pollTimer;
  String _pollStatus = 'pending'; // pending | completed | rejected
  bool _polling = false;
  int? _saldoSisa; // saldo setelah dipotong (dari backend saat completed)

  final List<Map<String, dynamic>> _ewallets = [
    {'id': 'dana',      'label': 'DANA',      'icon': Icons.account_balance_wallet_rounded, 'color': Color(0xFF108EE9)},
    {'id': 'gopay',     'label': 'GoPay',     'icon': Icons.g_mobiledata_rounded,           'color': Color(0xFF00AED6)},
    {'id': 'ovo',       'label': 'OVO',       'icon': Icons.account_balance_wallet_rounded,  'color': Color(0xFF4C3494)},
    {'id': 'shopeepay', 'label': 'ShopeePay', 'icon': Icons.shopping_bag_rounded,           'color': Color(0xFFEE4D2D)},
    {'id': 'linkaja',   'label': 'LinkAja',   'icon': Icons.link_rounded,                   'color': Color(0xFFE82529)},
  ];

  @override
  void initState() {
    super.initState();
    _loadConfig();
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _phoneCtrl.dispose();
    _nominalCtrl.dispose();
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadConfig() async {
    final saldoRes = await Fr3Service.checkSaldo();
    final cfgRes   = await Fr3Service.getWithdrawConfig();
    if (!mounted) return;
    setState(() {
      if (saldoRes['success'] == true) {
        _saldo = saldoRes['data']?['saldo'] ?? 0;
      }
      if (cfgRes['admin_fee'] != null) {
        _adminFee = cfgRes['admin_fee'] as int;
      }
      if (cfgRes['nominal_list'] is List) {
        _nominalList = List<int>.from(cfgRes['nominal_list']);
      }
    });
  }

  int get _nominal => int.tryParse(_nominalCtrl.text.replaceAll('.', '')) ?? 0;
  int get _totalPotong => _nominal + _adminFee;
  bool get _saldoCukup => _saldo >= _totalPotong;

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  Future<void> _submit() async {
    final nama  = _namaCtrl.text.trim();
    final phone = _phoneCtrl.text.trim();

    if (nama.isEmpty)   { _snack('Nama akun wajib diisi', AppTheme.red); return; }
    if (phone.length < 8) { _snack('Nomor HP tidak valid', AppTheme.red); return; }
    if (_nominal < 1000) { _snack('Nominal minimal Rp1.000', AppTheme.red); return; }
    if (!_saldoCukup) {
      _snack('Saldo tidak cukup! Butuh Rp${_fmt(_totalPotong)}', AppTheme.red);
      return;
    }

    setState(() => _loading = true);
    final res = await Fr3Service.withdrawManual(
      ewallet:  _ewallet,
      nomor:    phone,
      nominal:  _nominal,
      namaAkun: nama,
    );
    setState(() => _loading = false);

    if (res['success'] == true) {
      setState(() {
        _submitted   = true;
        _pollStatus  = 'pending';
        _polling     = true;
        _trxId       = res['data']?['trx_id'] ?? res['trxId'] ?? '';
      });
      _startPolling();
    } else {
      _snack(res['message'] ?? 'Gagal kirim withdraw', AppTheme.red);
    }
  }

  // ── POLLING ──────────────────────────────────────────────────────────────
  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || _trxId == null) return;
      final res = await Fr3Service.pollWithdrawStatus(_trxId!);
      if (!mounted) return;
      if (res['success'] == true) {
        final data   = res['data'] as Map<String, dynamic>?;
        final status = data?['status'] as String? ?? 'pending';
        if (status == 'completed' || status == 'rejected') {
          _pollTimer?.cancel();
          final saldoSesudah = data?['saldo_sesudah'];
          setState(() {
            _pollStatus = status;
            _polling    = false;
            if (saldoSesudah != null) {
              _saldoSisa = (saldoSesudah is int)
                  ? saldoSesudah
                  : int.tryParse(saldoSesudah.toString());
            }
          });
          if (status == 'completed') {
            _showStrukDialog();
          }
        }
      }
    });
  }

  void _showStrukDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: AppTheme.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Header struk
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppTheme.green.withOpacity(0.15), 
                    AppTheme.accent.withOpacity(0.08)
                  ]
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.green.withOpacity(0.3)),
              ),
              child: Column(children: [
                const Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 44),
                const SizedBox(height: 8),
                Text('WITHDRAW BERHASIL', style: AppTheme.display(size: 14, weight: FontWeight.bold)),
              ]),
            ),
            const SizedBox(height: 20),

            // Detail struk
            _strRow('E-Wallet', _ewallet.toUpperCase()),
            _strRow('Nominal', 'Rp${_fmt(_nominal)}'),
            _strRow('Pajak', 'Rp${_fmt(_adminFee)}'),
            _strRow('Total Dipotong', 'Rp${_fmt(_totalPotong)}', highlight: true),
            if (_saldoSisa != null)
              _strRow('Sisa Saldo', 'Rp${_fmt(_saldoSisa!)}', color: AppTheme.cyan),
            const Divider(color: Color(0x22FFFFFF), height: 20),
            if (_trxId != null)
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: _trxId!));
                  _snack('TrxID disalin!', AppTheme.accent);
                },
                child: Row(children: [
                  const Icon(Icons.receipt_long_rounded, color: AppTheme.accentLight, size: 14),
                  const SizedBox(width: 8),
                  Expanded(child: Text(
                    _trxId!,
                    style: AppTheme.mono(size: 11, color: AppTheme.textSecondary),
                  )),
                  const Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 13),
                ]),
              ),
            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              height: 46,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [AppTheme.accent, AppTheme.cyan]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _reset();
                  },
                  child: const Text('SELESAI',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _strRow(String label, String value, {bool highlight = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        Text(label, style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
        const Spacer(),
        Text(value, style: AppTheme.body(
          size: 13,
          color: color ?? (highlight ? AppTheme.green : AppTheme.textPrimary),
          weight: highlight ? FontWeight.bold : FontWeight.normal,
        )),
      ]),
    );
  }

  void _reset() {
    _pollTimer?.cancel();
    setState(() {
      _submitted  = false;
      _trxId      = null;
      _pollStatus = 'pending';
      _polling    = false;
      _saldoSisa  = null;
      _namaCtrl.clear();
      _phoneCtrl.clear();
      _nominalCtrl.clear();
      _ewallet = 'dana';
    });
    _loadConfig();
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: color),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('WITHDRAW SALDO'),
        backgroundColor: AppTheme.bg,
        actions: _submitted
            ? [
                IconButton(
                  onPressed: _reset,
                  icon: const Icon(Icons.refresh_rounded, color: AppTheme.textSecondary),
                ),
              ]
            : null,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: _submitted ? _buildWaiting() : _buildForm(),
      ),
    );
  }

  // ── WAITING (setelah submit, polling) ───────────────────────────────────

  Widget _buildWaiting() {
    final isRejected = _pollStatus == 'rejected';
    return Column(children: [
      const SizedBox(height: 32),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            (isRejected ? AppTheme.red : AppTheme.accent).withOpacity(0.10),
            AppTheme.indigo.withOpacity(0.05),
          ]),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: (isRejected ? AppTheme.red : AppTheme.accent).withOpacity(0.25)),
        ),
        child: Column(children: [
          if (_polling)
            const SizedBox(
              width: 52, height: 52,
              child: CircularProgressIndicator(strokeWidth: 3, color: AppTheme.accent),
            )
          else
            Icon(
              isRejected ? Icons.cancel_rounded : Icons.check_circle_rounded,
              color: isRejected ? AppTheme.red : AppTheme.green,
              size: 56,
            ),
          const SizedBox(height: 16),
          Text(
            _polling
                ? 'MENUNGGU KONFIRMASI ADMIN'
                : (isRejected ? 'WITHDRAW DITOLAK' : 'WITHDRAW SELESAI!'),
            style: AppTheme.display(size: 15, weight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            _polling
                ? 'Admin sedang memproses transfermu.\nHalaman ini otomatis update saat selesai.'
                : (isRejected
                    ? 'Withdraw kamu ditolak admin.\nSaldo kamu sudah di-refund otomatis.'
                    : 'Transfer berhasil! Dialog struk akan muncul.'),
            style: AppTheme.body(size: 13, color: AppTheme.textSecondary),
            textAlign: TextAlign.center,
          ),
        ]),
      ),

      if (_trxId != null && _trxId!.isNotEmpty) ...[
        const SizedBox(height: 16),
        GestureDetector(
          onTap: () {
            Clipboard.setData(ClipboardData(text: _trxId!));
            _snack('TrxID disalin!', AppTheme.accent);
          },
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border),
            ),
            child: Row(children: [
              const Icon(Icons.receipt_long_rounded, color: AppTheme.accentLight, size: 16),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Transaction ID', style: AppTheme.eyebrow()),
                const SizedBox(height: 2),
                Text(_trxId!, style: AppTheme.mono(size: 12, color: AppTheme.textPrimary)),
              ])),
              const Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 14),
            ]),
          ),
        ),
      ],

      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.yellow.withOpacity(0.07),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.yellow.withOpacity(0.25)),
        ),
        child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.warning_amber_rounded, color: AppTheme.yellow, size: 16),
          SizedBox(width: 8),
          Expanded(child: Text(
            'Simpan Transaction ID di atas sebagai bukti. Jika dalam 30 menit belum diproses, hubungi admin.',
            style: TextStyle(color: AppTheme.yellow, fontSize: 11, height: 1.5),
          )),
        ]),
      ),

      if (isRejected) ...[
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 48,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppTheme.accent, AppTheme.cyan]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: _reset,
              child: const Text('COBA LAGI',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            ),
          ),
        ),
      ],
    ]);
  }

  // ── FORM ──────────────────────────────────────────────────────────────────

  Widget _buildForm() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      // Saldo Card
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            AppTheme.accent.withOpacity(0.18),
            AppTheme.indigo.withOpacity(0.10),
          ]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.accent.withOpacity(0.25)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('SALDO TERSEDIA', style: AppTheme.eyebrow(color: AppTheme.accentLight)),
          const SizedBox(height: 6),
          Text('Rp${_fmt(_saldo)}',
              style: AppTheme.display(size: 26, weight: FontWeight.bold)),
          if (_nominal > 0) ...[
            const SizedBox(height: 8),
            const Divider(color: Color(0x336C2BD9), height: 1),
            const SizedBox(height: 8),
            Row(children: [
              Text('Nominal:', style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
              const Spacer(),
              Text('Rp${_fmt(_nominal)}', style: AppTheme.body(size: 12, color: AppTheme.textPrimary)),
            ]),
            const SizedBox(height: 2),
            Row(children: [
              Text('Pajak:', style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
              const Spacer(),
              Text('Rp${_fmt(_adminFee)}', style: AppTheme.body(size: 12, color: AppTheme.yellow)),
            ]),
            const SizedBox(height: 2),
            Row(children: [
              Text('Total potong:', style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
              const Spacer(),
              Text('Rp${_fmt(_totalPotong)}',
                  style: AppTheme.body(
                      size: 13,
                      color: _saldoCukup ? AppTheme.green : AppTheme.red,
                      weight: FontWeight.bold)),
            ]),
          ],
        ]),
      ),

      const SizedBox(height: 24),

      // Pilih E-Wallet
      Text('E-WALLET TUJUAN', style: AppTheme.eyebrow()),
      const SizedBox(height: 10),
      SizedBox(
        height: 56,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: _ewallets.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final ew = _ewallets[i];
            final isSelected = _ewallet == ew['id'];
            return GestureDetector(
              onTap: () => setState(() => _ewallet = ew['id'] as String),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: isSelected
                      ? (ew['color'] as Color).withOpacity(0.15)
                      : AppTheme.card,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? (ew['color'] as Color) : AppTheme.border,
                    width: isSelected ? 1.5 : 1,
                  ),
                ),
                child: Row(children: [
                  Icon(ew['icon'] as IconData,
                      color: isSelected ? (ew['color'] as Color) : AppTheme.textSecondary,
                      size: 18),
                  const SizedBox(width: 6),
                  Text(ew['label'] as String,
                      style: TextStyle(
                          color: isSelected ? (ew['color'] as Color) : AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal)),
                ]),
              ),
            );
          },
        ),
      ),

      const SizedBox(height: 20),

      // Nama Akun
      Text('NAMA AKUN ${_ewallet.toUpperCase()}', style: AppTheme.eyebrow()),
      const SizedBox(height: 8),
      _buildTextField(
        controller: _namaCtrl,
        hint: 'Nama sesuai akun e-wallet',
        icon: Icons.person_rounded,
        textCapitalization: TextCapitalization.words,
      ),

      const SizedBox(height: 16),

      // Nomor HP
      Text('NOMOR HP / NOMOR E-WALLET', style: AppTheme.eyebrow()),
      const SizedBox(height: 8),
      _buildTextField(
        controller: _phoneCtrl,
        hint: '08xxxxxxxxxx',
        icon: Icons.phone_rounded,
        keyboard: TextInputType.phone,
      ),

      const SizedBox(height: 20),

      // Nominal
      Text('NOMINAL WITHDRAW', style: AppTheme.eyebrow()),
      const SizedBox(height: 10),
      Container(
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: _nominal > 0 && !_saldoCukup
                  ? AppTheme.red.withOpacity(0.5)
                  : AppTheme.border),
        ),
        child: Row(children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text('Rp',
                style: TextStyle(color: AppTheme.accentLight, fontWeight: FontWeight.bold, fontSize: 18)),
          ),
          Expanded(
            child: TextField(
              controller: _nominalCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 22, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                hintText: '0',
                hintStyle: TextStyle(color: AppTheme.textSecondary),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 16),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
        ]),
      ),

      const SizedBox(height: 10),
      Wrap(
        spacing: 8, runSpacing: 8,
        children: _nominalList.map((a) => GestureDetector(
          onTap: () => setState(() => _nominalCtrl.text = a.toString()),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _nominal == a ? AppTheme.green : AppTheme.border),
            ),
            child: Text('Rp${_fmt(a)}',
                style: TextStyle(
                    color: _nominal == a ? AppTheme.green : AppTheme.textSecondary,
                    fontSize: 12)),
          ),
        )).toList(),
      ),

      if (_nominal > 0 && !_saldoCukup) ...[
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: AppTheme.red.withOpacity(0.08),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppTheme.red.withOpacity(0.3)),
          ),
          child: Row(children: [
            const Icon(Icons.error_outline_rounded, color: AppTheme.red, size: 14),
            const SizedBox(width: 6),
            Text('Saldo tidak cukup. Butuh Rp${_fmt(_totalPotong)} (termasuk pajak Rp${_fmt(_adminFee)})',
                style: const TextStyle(color: AppTheme.red, fontSize: 11)),
          ]),
        ),
      ],

      const SizedBox(height: 28),

      // Tombol submit
      SizedBox(
        width: double.infinity,
        height: 54,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: _saldoCukup && _nominal >= 1000
                  ? [const Color(0xFF16A34A), const Color(0xFF15803D)]
                  : [AppTheme.border, AppTheme.border],
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: _saldoCukup && _nominal >= 1000
                ? [BoxShadow(color: const Color(0xFF16A34A).withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))]
                : [],
          ),
          child: TextButton(
            onPressed: _loading
                ? null
                : (_saldoCukup && _nominal >= 1000 ? _submit : null),
            child: _loading
                ? const SizedBox(width: 22, height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.send_to_mobile_rounded, color: Colors.white, size: 20),
                    SizedBox(width: 8),
                    Text('AJUKAN WITHDRAW',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 14)),
                  ]),
          ),
        ),
      ),

      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.border),
        ),
        child: const Row(children: [
          Icon(Icons.info_outline_rounded, color: AppTheme.cyan, size: 16),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Saldo langsung dipotong saat kamu submit. Jika ditolak admin, saldo otomatis di-refund.',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 11, height: 1.5),
            ),
          ),
        ]),
      ),

      const SizedBox(height: 24),
    ]);
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboard = TextInputType.text,
    TextCapitalization textCapitalization = TextCapitalization.none,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Icon(icon, color: AppTheme.textSecondary, size: 18),
        ),
        Expanded(
          child: TextField(
            controller: controller,
            keyboardType: keyboard,
            textCapitalization: textCapitalization,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: AppTheme.textSecondary),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ]),
    );
  }
}