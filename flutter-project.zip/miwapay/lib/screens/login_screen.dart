import 'package:flutter/material.dart';
import '../services/user_prefs.dart';
import '../services/app_service.dart';
import '../services/notification_service.dart';
import '../theme/app_theme.dart';
import 'main_nav.dart';
import 'intro_video_screen.dart';
import 'register_screen.dart';
import 'maintenance_screen.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _idCtrl   = TextEditingController();
  final _passCtrl = TextEditingController();
  bool  _loading  = false;
  bool  _obscure  = true;
  String? _err;

  Future<void> _login() async {
    final username = _idCtrl.text.trim();
    final password = _passCtrl.text.trim();
    if (username.isEmpty) { setState(() => _err = 'Masukkan username kamu'); return; }
    if (password.isEmpty) { setState(() => _err = 'Masukkan password kamu'); return; }
    setState(() { _loading = true; _err = null; });

    try {
      final status = await AppService.checkMaintenance();
      if (!mounted) return;
      if (status['maintenance'] == true) {
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => MaintenanceScreen(message: status['maintenance_msg'] ?? ''),
        ));
        return;
      }

      final data = await AppService.login(username: username, password: password);
      if (!mounted) return;

      if (data['success'] == true) {
        await UserPrefs.saveUserId(data['userId']);
        await UserPrefs.saveToken(data['token']);
        await UserPrefs.saveRole(data['role'] ?? 'user');
        // Simpan FCM token ke backend setelah login
        NotificationService.saveFcmToken(data['token']);
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => IntroVideoScreen(
            destination: MainNav(userId: data['userId'], role: data['role'] ?? 'user'),
          ),
        ));
      } else {
        setState(() { _err = data['message'] ?? 'Login gagal'; _loading = false; });
      }
    } catch (e) {
      setState(() { _err = 'Tidak bisa connect ke server'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Stack(
        children: [
          // Ambient glow
          Positioned(
            top: -120, right: -90,
            child: Container(
              width: 280, height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [AppTheme.accent.withOpacity(0.18), Colors.transparent],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Center(
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Logo
                            Center(
                              child: Container(
                                width: 80, height: 80,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [BoxShadow(
                                    color: AppTheme.accent.withOpacity(0.4),
                                    blurRadius: 24, spreadRadius: 3,
                                  )],
                                ),
                                child: ClipOval(
                                  child: Image.asset('assets/icons/icon_192.png',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle, gradient: AppTheme.cursedGradient),
                                      child: const Icon(Icons.bolt_rounded, size: 40, color: Colors.white),
                                    )),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),

                            Center(
                              child: ShaderMask(
                                shaderCallback: (b) => AppTheme.glowGradient.createShader(b),
                                child: Text('MIWA PAY',
                                  textAlign: TextAlign.center,
                                  style: AppTheme.display(
                                    size: 38, weight: FontWeight.w800,
                                    color: Colors.white, letterSpacing: 1,
                                  ).copyWith(height: 1.1)),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Center(
                              child: Text('Login dengan username & password kamu',
                                textAlign: TextAlign.center,
                                style: AppTheme.body(size: 14, color: AppTheme.textSecondary)),
                            ),

                            const SizedBox(height: 36),

                            // Username
                            Text('USERNAME', style: AppTheme.eyebrow()),
                            const SizedBox(height: 8),
                            Container(
                              decoration: BoxDecoration(
                                color: AppTheme.card,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: AppTheme.border),
                              ),
                              child: TextField(
                                controller: _idCtrl,
                                style: AppTheme.body(color: AppTheme.textPrimary),
                                decoration: InputDecoration(
                                  hintText: 'Username kamu',
                                  hintStyle: AppTheme.body(size: 12, color: AppTheme.textSecondary),
                                  prefixIcon: const Icon(Icons.person_rounded, color: AppTheme.textSecondary),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                ),
                                onChanged: (_) => setState(() => _err = null),
                              ),
                            ),

                            const SizedBox(height: 14),

                            // Password
                            Text('PASSWORD', style: AppTheme.eyebrow()),
                            const SizedBox(height: 8),
                            Container(
                              decoration: BoxDecoration(
                                color: AppTheme.card,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: AppTheme.border),
                              ),
                              child: TextField(
                                controller: _passCtrl,
                                obscureText: _obscure,
                                style: AppTheme.body(color: AppTheme.textPrimary),
                                decoration: InputDecoration(
                                  hintText: 'Password',
                                  hintStyle: AppTheme.body(color: AppTheme.textSecondary),
                                  prefixIcon: const Icon(Icons.lock_rounded, color: AppTheme.textSecondary),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                                      color: AppTheme.textSecondary, size: 20),
                                    onPressed: () => setState(() => _obscure = !_obscure),
                                  ),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                ),
                                onChanged: (_) => setState(() => _err = null),
                                onSubmitted: (_) => _login(),
                              ),
                            ),

                            // Lupa Password link
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                onPressed: _loading ? null : () {
                                  Navigator.push(context, MaterialPageRoute(
                                    builder: (_) => const ForgotPasswordScreen()));
                                },
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.only(top: 4),
                                  minimumSize: Size.zero,
                                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                ),
                                child: Text('Lupa Password?',
                                  style: AppTheme.body(size: 12, color: AppTheme.accentLight)),
                              ),
                            ),

                            if (_err != null) ...[
                              const SizedBox(height: 6),
                              Text(_err!, style: AppTheme.body(size: 13, color: AppTheme.red)),
                            ],

                            const SizedBox(height: 20),

                            SizedBox(
                              width: double.infinity, height: 52,
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: AppTheme.cursedGradient,
                                  borderRadius: BorderRadius.circular(14),
                                  boxShadow: [BoxShadow(
                                    color: AppTheme.accent.withOpacity(0.4),
                                    blurRadius: 20, offset: const Offset(0, 6))],
                                ),
                                child: TextButton(
                                  onPressed: _loading ? null : _login,
                                  child: _loading
                                      ? const SizedBox(width: 22, height: 22,
                                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                      : Text('MASUK',
                                          style: AppTheme.display(
                                            size: 16, weight: FontWeight.w700,
                                            color: Colors.white, letterSpacing: 2)),
                                ),
                              ),
                            ),

                            const SizedBox(height: 14),
                            Center(
                              child: TextButton(
                                onPressed: _loading ? null : () {
                                  Navigator.push(context, MaterialPageRoute(
                                    builder: (_) => const RegisterScreen()));
                                },
                                child: Text('Belum punya akun? Daftar di sini',
                                  style: AppTheme.body(size: 13, color: AppTheme.textSecondary)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Footer
                  Center(
                    child: Text('v1.2.0 • MIWA PAY',
                        style: AppTheme.eyebrow(color: AppTheme.textMuted)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
