import 'package:flutter/material.dart';
import '../services/app_service.dart';
import '../services/user_prefs.dart';
import '../theme/app_theme.dart';

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  bool _loading = true;
  bool _hasRated = false;
  Map<String, dynamic>? _myRating;
  List<dynamic> _reviews = [];
  int _total = 0;
  double _avg = 0;
  Map<String, dynamic> _dist = {'1': 0, '2': 0, '3': 0, '4': 0, '5': 0};

  // Form state
  int _selectedStar = 0;
  final _commentCtrl = TextEditingController();
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    // Pastikan domain/baseUrl sudah terload sebelum request
    if (AppService.baseUrl.isEmpty) {
      await AppService.loadDomain();
    }
    final token = await UserPrefs.getToken();

    final results = await Future.wait([
      AppService.getRatingAll(),
      if (token != null) AppService.getRatingMy(token),
    ]);

    if (!mounted) return;

    final allRes = results[0];
    final myRes  = token != null ? results[1] : null;

    setState(() {
      if (allRes['success'] == true) {
        _reviews = allRes['data'] ?? [];
        _total   = allRes['total'] ?? 0;
        _avg     = (allRes['avg'] as num?)?.toDouble() ?? 0;
        final d  = allRes['dist'] as Map<String, dynamic>? ?? {};
        _dist    = d;
      }
      if (myRes != null && myRes['success'] == true) {
        _hasRated = myRes['hasRated'] == true;
        _myRating = myRes['data'];
      }
      _loading = false;
    });
  }

  Future<void> _submit() async {
    if (_selectedStar == 0) {
      _snack('Pilih dulu bintangnya!', AppTheme.red);
      return;
    }
    final token = await UserPrefs.getToken();
    if (token == null) { _snack('Login dulu!', AppTheme.red); return; }

    setState(() => _submitting = true);
    final res = await AppService.submitRating(
      token: token,
      star: _selectedStar,
      comment: _commentCtrl.text.trim(),
    );
    if (!mounted) return;
    setState(() => _submitting = false);

    if (res['success'] == true) {
      _snack(res['message'] ?? 'Rating terkirim!', AppTheme.green);
      _load();
    } else {
      _snack(res['message'] ?? 'Gagal submit', AppTheme.red);
    }
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: color));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.accentLight))
          : SafeArea(
              child: RefreshIndicator(
                onRefresh: _load,
                color: AppTheme.accentLight,
                child: CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                        child: Column(children: [
                          // Header
                          Row(children: [
                            Container(
                              width: 42, height: 42,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: AppTheme.cursedGradient,
                                boxShadow: [BoxShadow(
                                    color: AppTheme.accent.withOpacity(0.35), blurRadius: 12)],
                              ),
                              child: const Icon(Icons.star_rounded, color: Colors.white, size: 22),
                            ),
                            const SizedBox(width: 12),
                            Text('RATING & ULASAN',
                                style: AppTheme.display(size: 15, weight: FontWeight.w700, letterSpacing: 1)),
                          ]),

                          const SizedBox(height: 24),

                          // Overview card
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(22),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                AppTheme.accent.withOpacity(0.2),
                                AppTheme.cyan.withOpacity(0.1),
                              ]),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: AppTheme.accent.withOpacity(0.3)),
                            ),
                            child: Row(children: [
                              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(_avg.toStringAsFixed(1),
                                    style: AppTheme.display(size: 56, weight: FontWeight.bold,
                                        color: AppTheme.accentLight)),
                                Row(children: List.generate(5, (i) => Icon(
                                    i < _avg.round() ? Icons.star_rounded : Icons.star_border_rounded,
                                    color: AppTheme.yellow, size: 20))),
                                const SizedBox(height: 4),
                                Text('$_total ulasan',
                                    style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
                              ]),
                              const Spacer(),
                              Column(crossAxisAlignment: CrossAxisAlignment.end,
                                children: [5, 4, 3, 2, 1].map((s) {
                                  final cnt = (_dist[s.toString()] as num?)?.toInt() ?? 0;
                                  return _ratingBar(s, cnt);
                                }).toList(),
                              ),
                            ]),
                          ),

                          const SizedBox(height: 16),

                          // Form rating / already rated
                          _hasRated ? _buildAlreadyRated() : _buildForm(),

                          const SizedBox(height: 20),
                          if (_reviews.isNotEmpty)
                            Align(alignment: Alignment.centerLeft,
                                child: Text('ULASAN PENGGUNA', style: AppTheme.eyebrow())),
                          const SizedBox(height: 12),
                        ]),
                      ),
                    ),

                    // List reviews
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (ctx, i) {
                          final r = _reviews[i];
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: AppTheme.card,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: AppTheme.border),
                              ),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(children: [
                                  CircleAvatar(
                                    backgroundColor: AppTheme.accent.withOpacity(0.2),
                                    radius: 18,
                                    child: Text(
                                      ((r['user_id'] as String?) ?? '?')[0].toUpperCase(),
                                      style: const TextStyle(
                                          color: AppTheme.accentLight, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text(r['user_id'] ?? '-',
                                        style: AppTheme.body(size: 13, weight: FontWeight.bold)),
                                    Text(_fmtTime(r['created_at']),
                                        style: AppTheme.body(size: 11, color: AppTheme.textMuted)),
                                  ])),
                                  Row(children: List.generate(5, (s) => Icon(
                                      s < (r['star'] as num? ?? 0)
                                          ? Icons.star_rounded
                                          : Icons.star_border_rounded,
                                      color: AppTheme.yellow, size: 14))),
                                ]),
                                if ((r['comment'] as String? ?? '').isNotEmpty) ...[
                                  const SizedBox(height: 10),
                                  Text(r['comment'],
                                      style: AppTheme.body(size: 12, color: AppTheme.textSecondary,
                                          letterSpacing: 0.2)),
                                ],
                              ]),
                            ),
                          );
                        },
                        childCount: _reviews.length,
                      ),
                    ),

                    const SliverToBoxAdapter(child: SizedBox(height: 20)),
                  ],
                ),
              ),
            ),
    );
  }

  // ── Form submit rating ─────────────────────────────────────────────────────
  Widget _buildForm() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.accent.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('KASIH RATING DONG!', style: AppTheme.eyebrow(color: AppTheme.accentLight)),
        const SizedBox(height: 14),

        // Bintang pilihan
        Row(mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(5, (i) {
            final star = i + 1;
            return GestureDetector(
              onTap: () => setState(() => _selectedStar = star),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Icon(
                  star <= _selectedStar ? Icons.star_rounded : Icons.star_border_rounded,
                  color: AppTheme.yellow,
                  size: 42,
                ),
              ),
            );
          }),
        ),

        if (_selectedStar > 0) ...[
          const SizedBox(height: 6),
          Center(child: Text(
            ['', 'Sangat Buruk 😞', 'Buruk 😕', 'Cukup 😐', 'Bagus 😊', 'Luar Biasa! 🤩'][_selectedStar],
            style: TextStyle(
              color: [AppTheme.red, AppTheme.red, AppTheme.yellow,
                AppTheme.green, AppTheme.green][_selectedStar - 1],
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          )),
        ],

        const SizedBox(height: 14),

        // Komentar
        Container(
          decoration: BoxDecoration(
            color: AppTheme.bg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
          ),
          child: TextField(
            controller: _commentCtrl,
            maxLines: 3,
            maxLength: 300,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
            decoration: const InputDecoration(
              hintText: 'Tulis ulasanmu di sini (opsional)...',
              hintStyle: TextStyle(color: AppTheme.textSecondary),
              border: InputBorder.none,
              contentPadding: EdgeInsets.all(12),
              counterStyle: TextStyle(color: AppTheme.textMuted, fontSize: 10),
            ),
          ),
        ),

        const SizedBox(height: 14),

        SizedBox(
          width: double.infinity,
          height: 46,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: _selectedStar > 0
                  ? const LinearGradient(colors: [AppTheme.accent, AppTheme.cyan])
                  : const LinearGradient(colors: [AppTheme.border, AppTheme.border]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: _submitting || _selectedStar == 0 ? null : _submit,
              child: _submitting
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('KIRIM RATING',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,
                          letterSpacing: 1.5, fontSize: 13)),
            ),
          ),
        ),
      ]),
    );
  }

  // ── Sudah pernah rating ────────────────────────────────────────────────────
  Widget _buildAlreadyRated() {
    final star    = (_myRating?['star'] as num?)?.toInt() ?? 0;
    final comment = _myRating?['comment'] as String? ?? '';
    final time    = _fmtTime(_myRating?['created_at']);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.green.withOpacity(0.07),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.green.withOpacity(0.35)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 18),
          const SizedBox(width: 8),
          Text('RATING KAMU', style: AppTheme.eyebrow(color: AppTheme.green)),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Row(children: List.generate(5, (i) => Icon(
              i < star ? Icons.star_rounded : Icons.star_border_rounded,
              color: AppTheme.yellow, size: 22))),
          const SizedBox(width: 10),
          Text('$star/5', style: AppTheme.body(size: 13, weight: FontWeight.bold)),
        ]),
        if (comment.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(comment, style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
        ],
        const SizedBox(height: 6),
        Text('Dikirim: $time', style: AppTheme.body(size: 11, color: AppTheme.textMuted)),
        const SizedBox(height: 8),
        const Text('Rating tidak bisa diubah setelah dikirim.',
            style: TextStyle(color: AppTheme.textMuted, fontSize: 11, fontStyle: FontStyle.italic)),
      ]),
    );
  }

  Widget _ratingBar(int star, int count) {
    final pct = _total > 0 ? count / _total : 0.0;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(children: [
        Text('$star', style: AppTheme.body(size: 11, color: AppTheme.textSecondary)),
        const SizedBox(width: 4),
        const Icon(Icons.star_rounded, color: AppTheme.yellow, size: 11),
        const SizedBox(width: 6),
        SizedBox(
          width: 80, height: 6,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: pct,
              backgroundColor: AppTheme.border,
              valueColor: const AlwaysStoppedAnimation(AppTheme.yellow),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text('$count', style: AppTheme.body(size: 10, color: AppTheme.textMuted)),
      ]),
    );
  }

  String _fmtTime(String? iso) {
    if (iso == null) return '-';
    try {
      final dt = DateTime.parse(iso).toLocal();
      final now = DateTime.now();
      final diff = now.difference(dt);
      if (diff.inMinutes < 60) return '${diff.inMinutes} menit lalu';
      if (diff.inHours < 24) return '${diff.inHours} jam lalu';
      if (diff.inDays < 7) return '${diff.inDays} hari lalu';
      return '${dt.day}/${dt.month}/${dt.year}';
    } catch (_) { return iso; }
  }
}
