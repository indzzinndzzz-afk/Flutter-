import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/app_service.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  // ── State machine ──────────────────────────────────────────────────────────
  // step: email → waiting → setPassword → done
  String _step = 'email';

  final _emailCtrl    = TextEditingController();
  final _passCtrl     = TextEditingController();
  final _pass2Ctrl    = TextEditingController();
  bool _loading       = false;
  bool _obscurePass   = true;
  bool _obscurePass2  = true;
  String? _err;
  String? _resetToken;
  String? _username;
  String? _tempPassword;

  Timer? _pollTimer;
  int    _pollCount = 0;

  @override
  void dispose() {
    _pollTimer?.cancel();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _pass2Ctrl.dispose();
    super.dispose();
  }

  // ── Step 1: kirim email ke backend ────────────────────────────────────────
  Future<void> _kirimEmail() async {
    final email = _emailCtrl.text.trim();
    if (email.isEmpty) { setState(() => _err = 'Masukkan email kamu'); return; }
    if (!email.contains('@') || !email.contains('.')) {
      setState(() => _err = 'Format email tidak valid'); return;
    }
    setState(() { _loading = true; _err = null; });
    final res = await AppService.forgotPassword(email: email);
    if (!mounted) return;
    setState(() { _loading = false; });
    if (res['success'] == true) {
      _resetToken = res['resetToken'];
      setState(() => _step = 'waiting');
      _startPolling();
    } else {
      setState(() => _err = res['message'] ?? 'Email tidak terdaftar');
    }
  }

  // ── Polling setiap 5 detik untuk cek status dari admin ───────────────────
  void _startPolling() {
    _pollCount = 0;
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      _pollCount++;
      // Max 5 menit polling
      if (_pollCount > 60) {
        _pollTimer?.cancel();
        if (mounted) setState(() { _step = 'email'; _err = 'Waktu habis. Coba lagi.'; });
        return;
      }
      final res = await AppService.checkResetStatus(_resetToken!);
      if (!mounted) return;
      if (res['status'] == 'approved') {
        _pollTimer?.cancel();
        _username    = res['username'];
        _tempPassword = res['tempPassword'];
        setState(() => _step = 'setPassword');
      } else if (res['status'] == 'cancelled') {
        _pollTimer?.cancel();
        setState(() { _step = 'email'; _err = 'Request ditolak admin. Hubungi CS.'; });
      }
      // kalau masih 'pending' lanjut polling
    });
  }

  // ── Step 3: user set password baru ───────────────────────────────────────
  Future<void> _setPasswordBaru() async {
    final newPass  = _passCtrl.text.trim();
    final newPass2 = _pass2Ctrl.text.trim();
    if (newPass.length < 6) { setState(() => _err = 'Password minimal 6 karakter'); return; }
    if (newPass != newPass2) { setState(() => _err = 'Password tidak cocok'); return; }
    setState(() { _loading = true; _err = null; });
    final res = await AppService.resetPassword(
      username: _username!,
      tempPassword: _tempPassword!,
      newPassword: newPass,
    );
    if (!mounted) return;
    setState(() { _loading = false; });
    if (res['success'] == true) {
      setState(() => _step = 'done');
    } else {
      setState(() => _err = res['message'] ?? 'Gagal set password baru');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        title: const Text('LUPA PASSWORD'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () {
            _pollTimer?.cancel();
            Navigator.pop(context);
          },
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Header icon
            Center(
              child: Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppTheme.cursedGradient,
                  boxShadow: [BoxShadow(color: AppTheme.accent.withOpacity(0.4), blurRadius: 24, spreadRadius: 3)],
                ),
                child: Icon(
                  _step == 'waiting'     ? Icons.hourglass_top_rounded
                  : _step == 'setPassword' ? Icons.lock_reset_rounded
                  : _step == 'done'        ? Icons.check_circle_rounded
                  : Icons.lock_open_rounded,
                  color: Colors.white, size: 38,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Center(child: Text(
              _step == 'waiting'      ? 'Menunggu Konfirmasi Admin'
              : _step == 'setPassword'  ? 'Set Password Baru'
              : _step == 'done'         ? 'Password Berhasil Direset!'
              : 'Lupa Password?',
              style: AppTheme.display(size: 22, weight: FontWeight.bold),
              textAlign: TextAlign.center,
            )),
            const SizedBox(height: 8),
            Center(child: Text(
              _step == 'waiting'
                ? 'Permintaan sudah dikirim ke admin. Harap tunggu konfirmasi...'
                : _step == 'setPassword'
                  ? 'Admin sudah approve. Silakan buat password baru kamu.'
                  : _step == 'done'
                    ? 'Hubungi admin untuk mendapatkan password barumu.'
                    : 'Masukkan email yang terdaftar untuk reset password.',
              textAlign: TextAlign.center,
              style: AppTheme.body(size: 13, color: AppTheme.textSecondary),
            )),
            const SizedBox(height: 32),

            // ── STEP: email ─────────────────────────────────────────────
            if (_step == 'email') ...[
              Text('EMAIL TERDAFTAR', style: AppTheme.eyebrow()),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _err != null ? AppTheme.red : AppTheme.border),
                ),
                child: TextField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  style: AppTheme.body(color: AppTheme.textPrimary),
                  decoration: InputDecoration(
                    hintText: 'email@kamu.com',
                    hintStyle: AppTheme.body(size: 12, color: AppTheme.textSecondary),
                    prefixIcon: const Icon(Icons.email_rounded, color: AppTheme.textSecondary),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                  onChanged: (_) => setState(() => _err = null),
                  onSubmitted: (_) => _kirimEmail(),
                ),
              ),
              if (_err != null) ...[
                const SizedBox(height: 8),
                Text(_err!, style: AppTheme.body(size: 12, color: AppTheme.red)),
              ],
              const SizedBox(height: 24),
              _PrimaryButton(
                label: 'KIRIM REQUEST',
                loading: _loading,
                onTap: _kirimEmail,
              ),
              const SizedBox(height: 14),
              Center(child: Text('Reset akan dikonfirmasi oleh admin terlebih dahulu.',
                  style: AppTheme.body(size: 12, color: AppTheme.textMuted))),
            ],

            // ── STEP: waiting ───────────────────────────────────────────
            if (_step == 'waiting') ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppTheme.yellow.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.yellow.withOpacity(0.3)),
                ),
                child: Column(children: [
                  const SizedBox(
                    width: 40, height: 40,
                    child: CircularProgressIndicator(strokeWidth: 3, color: AppTheme.yellow),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Request sudah dikirim ke admin.\nMohon tunggu konfirmasi via bot Telegram.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppTheme.yellow, fontSize: 13, height: 1.5),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Halaman ini akan otomatis update\nketika admin sudah konfirmasi.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 11, height: 1.5),
                  ),
                ]),
              ),
              const SizedBox(height: 20),
              _PrimaryButton(
                label: 'BATALKAN',
                onTap: () {
                  _pollTimer?.cancel();
                  setState(() { _step = 'email'; _err = null; });
                },
                gradient: const LinearGradient(colors: [Color(0xFF374151), Color(0xFF1F2937)]),
              ),
            ],

            // ── STEP: setPassword ───────────────────────────────────────
            if (_step == 'setPassword') ...[
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: AppTheme.green.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.green.withOpacity(0.3)),
                ),
                child: const Row(children: [
                  Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 18),
                  SizedBox(width: 8),
                  Expanded(child: Text('Admin sudah approve! Buat password baru kamu.',
                      style: TextStyle(color: AppTheme.green, fontSize: 12))),
                ]),
              ),
              Text('PASSWORD BARU', style: AppTheme.eyebrow()),
              const SizedBox(height: 8),
              _PasswordField(ctrl: _passCtrl, hint: 'Min. 6 karakter', obscure: _obscurePass,
                onToggle: () => setState(() => _obscurePass = !_obscurePass),
                err: _err,
                onChanged: (_) => setState(() => _err = null),
              ),
              const SizedBox(height: 14),
              Text('KONFIRMASI PASSWORD', style: AppTheme.eyebrow()),
              const SizedBox(height: 8),
              _PasswordField(ctrl: _pass2Ctrl, hint: 'Ulangi password baru', obscure: _obscurePass2,
                onToggle: () => setState(() => _obscurePass2 = !_obscurePass2),
                onChanged: (_) => setState(() => _err = null),
              ),
              if (_err != null) ...[
                const SizedBox(height: 8),
                Text(_err!, style: AppTheme.body(size: 12, color: AppTheme.red)),
              ],
              const SizedBox(height: 24),
              _PrimaryButton(label: 'SIMPAN PASSWORD', loading: _loading, onTap: _setPasswordBaru),
            ],

            // ── STEP: done ──────────────────────────────────────────────
            if (_step == 'done') ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppTheme.green.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.green.withOpacity(0.3)),
                ),
                child: Column(children: [
                  const Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 48),
                  const SizedBox(height: 12),
                  const Text('Password berhasil direset oleh admin!',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.green, fontSize: 14,
                        fontWeight: FontWeight.bold, height: 1.5)),
                ]),
              ),
              const SizedBox(height: 20),
              // Info: hubungi admin untuk minta password
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppTheme.yellow.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.yellow.withOpacity(0.35)),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Row(children: [
                    Icon(Icons.info_rounded, color: AppTheme.yellow, size: 18),
                    SizedBox(width: 8),
                    Text('LANGKAH SELANJUTNYA',
                        style: TextStyle(color: AppTheme.yellow, fontWeight: FontWeight.bold,
                            fontSize: 12, letterSpacing: 1)),
                  ]),
                  const SizedBox(height: 12),
                  const Text(
                    'Password kamu sudah direset. Hubungi admin/CS untuk mendapatkan password barumu, lalu segera ganti setelah login.',
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 13, height: 1.6),
                  ),
                  const SizedBox(height: 16),
                  const Text('HUBUNGI CS VIA:', style: TextStyle(
                      color: AppTheme.textMuted, fontSize: 11, letterSpacing: 1)),
                  const SizedBox(height: 10),
                  // Tombol WhatsApp
                  GestureDetector(
                    onTap: () async {
                      final uri = Uri.parse('https://wa.me/6283175593052?text=Halo+admin%2C+saya+minta+password+baru+setelah+reset+password+di+app+MiwaChan+OTP');
                      // ignore: deprecated_member_use
                      if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF25D366).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.4)),
                      ),
                      child: Row(children: [
                        Image.asset('assets/icons/wa_logo.png', width: 22, height: 22,
                            errorBuilder: (_, __, ___) => const Icon(Icons.chat_rounded,
                                color: Color(0xFF25D366), size: 22)),
                        const SizedBox(width: 10),
                        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('WhatsApp CS', style: TextStyle(
                              color: Color(0xFF25D366), fontWeight: FontWeight.bold, fontSize: 13)),
                          Text('+62 831-7559-3052', style: TextStyle(
                              color: AppTheme.textMuted, fontSize: 11)),
                        ])),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFF25D366), size: 14),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Tombol Telegram
                  GestureDetector(
                    onTap: () async {
                      final uri = Uri.parse('https://t.me/Miwachan76');
                      // ignore: deprecated_member_use
                      if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0088CC).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFF0088CC).withOpacity(0.4)),
                      ),
                      child: Row(children: [
                        Image.asset('assets/icons/tele_logo.png', width: 22, height: 22,
                            errorBuilder: (_, __, ___) => const Icon(Icons.send_rounded,
                                color: Color(0xFF0088CC), size: 22)),
                        const SizedBox(width: 10),
                        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Telegram CS', style: TextStyle(
                              color: Color(0xFF0088CC), fontWeight: FontWeight.bold, fontSize: 13)),
                          Text('@Miwachan76', style: TextStyle(
                              color: AppTheme.textMuted, fontSize: 11)),
                        ])),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFF0088CC), size: 14),
                      ]),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 20),
              _PrimaryButton(
                label: 'KEMBALI KE LOGIN',
                onTap: () => Navigator.pushAndRemoveUntil(context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false),
              ),
            ],
          ]),
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool loading;
  final Gradient? gradient;
  const _PrimaryButton({required this.label, this.onTap, this.loading = false, this.gradient});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity, height: 52,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: gradient ?? AppTheme.cursedGradient,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: AppTheme.accent.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
        ),
        child: TextButton(
          onPressed: loading ? null : onTap,
          child: loading
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 14)),
        ),
      ),
    );
  }
}

class _PasswordField extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  final bool obscure;
  final VoidCallback onToggle;
  final String? err;
  final ValueChanged<String>? onChanged;
  const _PasswordField({required this.ctrl, required this.hint, required this.obscure, required this.onToggle, this.err, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: err != null ? AppTheme.red : AppTheme.border),
      ),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        style: const TextStyle(color: AppTheme.textPrimary),
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
          prefixIcon: const Icon(Icons.lock_rounded, color: AppTheme.textSecondary),
          suffixIcon: IconButton(
            icon: Icon(obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                color: AppTheme.textSecondary, size: 20),
            onPressed: onToggle,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }
}
