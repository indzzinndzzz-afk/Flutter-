// team_page.dart
import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'theme_provider.dart';

class TeamPage extends StatelessWidget {
  const TeamPage({super.key});

  static const List<Map<String, dynamic>> _members = [
    // === TIM INTI (1 DEVELOPER) ===
    {
      'name': '⏤͟͞𝐎𝐌 𝐎𝐙𝐢𝐥𝐥𝐱𝐲𝐕𝐨𝐫𝐞𝐯𝐞𝐫 | 𝐗𝐓',
      'username': '@alwaysZilllxy',
      'role': 'DEVELOPER',
      'photo': 'team1.jpg',
      'telegram': 'https://t.me/alwaysZilllxy',
      'isCore': true,
    },
    // === FRENDS (3 ORANG) ===
    {
      'name': '𝗤𝗤𝗦 제 𝐌𝐈𝐖𝐀 𝐂𝐇𝐀𝐍 [ON TIME]',
      'username': '@gacha_789bot',
      'role': 'MY FRENDS',
      'photo': 'team2.jpg',
      'telegram': 'https://t.me/gacha_789bot',
      'isCore': false,
    },
    {
      'name': '㉿ᖮ 𝒐𝒎 𝒂𝒏𝒈𝒌𝒂𝒔𝒂 - 𝑴𝑫 𝐓𝟓',
      'username': '@angkasanyabobo',
      'role': 'MY FRENDS',
      'photo': 'team4.jpg',
      'telegram': 'https://t.me/angkasanyabobo',
      'isCore': false,
    },
    {
      'name': '𝙇𝙚𝙭𝙯𝙮𝙈𝙤𝙙𝙨𝙨 - 𝙀𝙭𝙚𝙘𝙪𝙩𝙚𝙙 (¢)',
      'username': '@LexzyMods',
      'role': 'MY ANAK ZILLXY',
      'photo': 'team3.jpg',
      'telegram': 'https://t.me/LexzyMods',
      'isCore': false,
    },
    {
      'name': '⋆.˚🦋༘ 𝙌𝙌𝙎 제 𝙊𝙢𝙝𝙘𝙎𝙞𝙡𝙚𝙣𝙘𝙚',
      'username': '@RriztXflow',
      'role': 'MY BAPAK',
      'photo': 'team5.jpg',
      'telegram': 'https://t.me/RriztXflow',
      'isCore': false,
    },
    {
      'name': 'EVOX TEDYSCARY',
      'username': '@',
      'role': 'MY FRENDS',
      'photo': 'team6.jpg',
      'telegram': 'https://t.me/',
      'isCore': false,
    },
    {
      'name': './ÃlwàysÇîkãlBâçk..🎖',
      'username': '@alwaysCikal',
      'role': 'MY ANAK ZILLXY',
      'photo': 'team7.jpg',
      'telegram': 'https://t.me/alwaysCikal',
      'isCore': false,
    },                
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    final accent = theme.primaryColor;

    final coreMembers = _members.where((m) => m['isCore'] == true).toList();
    final friendsMembers = _members.where((m) => m['isCore'] == false).toList();

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildAppBar(context, accent),
          const SliverToBoxAdapter(child: SizedBox(height: 8)),
          SliverToBoxAdapter(child: _buildThankYouCard(accent)),
          SliverToBoxAdapter(
            child: _buildSectionHeader('Tim Inti (1 Developer)', Icons.code_rounded, accent),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => _MemberCard(member: coreMembers[i], accent: accent),
                childCount: coreMembers.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.68,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: _buildSectionHeader('FRENDS (3)', Icons.people_rounded, accent),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => _MemberCard(member: friendsMembers[i], accent: accent),
                childCount: friendsMembers.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.68,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 40)),
        ],
      ),
    );
  }

  Widget _buildAppBar(BuildContext context, Color accent) {
    return SliverAppBar(
      expandedHeight: 0,
      floating: true,
      snap: true,
      backgroundColor: const Color(0xFF060B14),
      elevation: 0,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: accent.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: accent.withOpacity(0.25)),
          ),
          child: Icon(Icons.arrow_back_ios_new_rounded, color: accent, size: 16),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Our Team',
            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900),
          ),
          Row(children: [
            Icon(Icons.favorite_rounded, color: accent, size: 11),
            const SizedBox(width: 4),
            Text('1 Developer • 3 FRENDS', style: TextStyle(color: accent, fontSize: 11)),
          ]),
        ],
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 14, top: 10, bottom: 10),
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: accent.withOpacity(0.15),
            border: Border.all(color: accent.withOpacity(0.3)),
          ),
          child: Icon(Icons.groups_rounded, color: accent, size: 22),
        ),
      ],
    );
  }

  Widget _buildThankYouCard(Color accent) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: accent.withOpacity(0.12),
        border: Border.all(color: accent.withOpacity(0.25)),
      ),
      child: Row(children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: accent.withOpacity(0.2),
            border: Border.all(color: accent.withOpacity(0.4)),
          ),
          child: Icon(Icons.favorite_rounded, color: accent, size: 28),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Terima kasih atas support kalian!',
                style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                'Tanpa kalian semua ini gak ada artinya. Dari lubuk hati yang paling dalam, makasih udah ada',
                style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 11, height: 1.5),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, Color accent) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
      child: Row(children: [
        Container(
          width: 4,
          height: 20,
          decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(2)),
        ),
        const SizedBox(width: 10),
        Icon(icon, color: accent, size: 18),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800),
        ),
      ]),
    );
  }
}

// ==================== MEMBER CARD DENGAN SCROLL HORIZONTAL ====================
class _MemberCard extends StatelessWidget {
  final Map<String, dynamic> member;
  final Color accent;
  const _MemberCard({required this.member, required this.accent});

  Future<void> _openUrl(String url) async {
    if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withOpacity(0.04),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Foto
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(18),
              topRight: Radius.circular(18),
            ),
            child: AssetService.image(
              member['photo'] as String,
              height: 100,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 100,
                width: double.infinity,
                color: accent.withOpacity(0.08),
                child: Icon(Icons.person_rounded, color: accent.withOpacity(0.3), size: 36),
              ),
            ),
          ),

          // Info
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Badge role
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: accent.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        member['isCore'] == true ? Icons.code_rounded : Icons.star_rounded,
                        color: accent,
                        size: 9,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        member['role'] as String,
                        style: TextStyle(
                          color: accent,
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // NAMA dengan Scroll Horizontal (geser kiri-kanan)
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children: [
                      Text(
                        member['name'] as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),

                // USERNAME dengan Scroll Horizontal (geser kiri-kanan)
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children: [
                      Icon(Icons.alternate_email_rounded, color: accent.withOpacity(0.7), size: 10),
                      const SizedBox(width: 4),
                      Text(
                        member['username'] as String,
                        style: TextStyle(
                          color: accent.withOpacity(0.85),
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // Tombol Hubungi
                GestureDetector(
                  onTap: () => _openUrl(member['telegram'] as String),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: accent.withOpacity(0.12),
                      border: Border.all(color: accent.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.send_rounded, color: accent, size: 12),
                        const SizedBox(width: 5),
                        Text(
                          'Hubungi',
                          style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}