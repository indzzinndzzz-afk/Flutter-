import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'config_service.dart';
import 'theme_provider.dart';

// ─────────────────────────────────────────────
// WIDGET AVATAR FOTO PROFIL (bisa dipakai di mana saja)
// ─────────────────────────────────────────────
class ProfileAvatar extends StatelessWidget {
  final String username;
  final String? photoUrl;
  final double radius;
  final bool editable;
  final String? sessionKey;
  final Function(String newUrl)? onUploaded;

  const ProfileAvatar({
    super.key,
    required this.username,
    this.photoUrl,
    this.radius = 40,
    this.editable = false,
    this.sessionKey,
    this.onUploaded,
  });

  @override
  Widget build(BuildContext context) {
    final tp = Provider.of<ThemeProvider>(context, listen: false);
    final primary = tp.primaryColor;

    return Stack(
      children: [
        GestureDetector(
          onTap: photoUrl != null
              ? () => _viewPhoto(context, photoUrl!)
              : null,
          child: CircleAvatar(
            radius: radius,
            backgroundColor: primary.withAlpha(40),
            backgroundImage: photoUrl != null ? NetworkImage(photoUrl!) : null,
            child: photoUrl == null
                ? Text(
                    username.isNotEmpty ? username[0].toUpperCase() : '?',
                    style: TextStyle(
                      color: primary,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      fontSize: radius * 0.55,
                    ),
                  )
                : null,
          ),
        ),
        if (editable)
          Positioned(
            right: 0,
            bottom: 0,
            child: GestureDetector(
              onTap: () => _showEditOptions(context),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: primary,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    width: 2,
                  ),
                ),
                child: Icon(
                  Icons.camera_alt_rounded,
                  color: Colors.white,
                  size: radius * 0.35,
                ),
              ),
            ),
          ),
      ],
    );
  }

  void _viewPhoto(BuildContext context, String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _PhotoViewer(url: url, username: username),
      ),
    );
  }

  void _showEditOptions(BuildContext context) {
    final tp = Provider.of<ThemeProvider>(context, listen: false);
    final primary = tp.primaryColor;
    final isDark = tp.isDarkMode;
    final bg = isDark ? const Color(0xFF0D1B2A) : Colors.white;
    final textColor = isDark ? Colors.white : const Color(0xFF0D1B2A);

    showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.withAlpha(100),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Foto Profil',
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            _optionTile(
              context, Icons.camera_alt_rounded, 'Kamera', textColor,
              () => _uploadPhoto(context, ImageSource.camera),
            ),
            _optionTile(
              context, Icons.photo_library_rounded, 'Galeri', textColor,
              () => _uploadPhoto(context, ImageSource.gallery),
            ),
            if (photoUrl != null)
              _optionTile(
                context, Icons.delete_outline_rounded, 'Hapus Foto', Colors.redAccent,
                () => _deletePhoto(context),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _optionTile(BuildContext ctx, IconData icon, String label, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(label, style: TextStyle(color: color)),
      onTap: () {
        Navigator.pop(ctx);
        onTap();
      },
    );
  }

  Future<void> _uploadPhoto(BuildContext context, ImageSource source) async {
    if (sessionKey == null) return;

    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 80, maxWidth: 800);
    if (file == null) return;

    // Loading snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Row(
          children: [
            SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
            SizedBox(width: 12),
            Text('Mengupload foto...'),
          ],
        ),
        duration: Duration(seconds: 10),
        behavior: SnackBarBehavior.floating,
      ),
    );

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('${ConfigService.baseUrl}/uploadProfile'),
      );
      request.headers['x-session-key'] = sessionKey!;
      request.files.add(await http.MultipartFile.fromPath(
        'photo',
        file.path,
        contentType: MediaType('image', 'jpeg'),
      ));

      final res = await request.send().timeout(const Duration(seconds: 30));
      final body = await res.stream.bytesToString();
      final data = jsonDecode(body);

      ScaffoldMessenger.of(context).clearSnackBars();

      if (data['valid'] == true) {
        onUploaded?.call(data['photoUrl']);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Foto profil berhasil diperbarui!'),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    } catch (_) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Gagal upload foto'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  Future<void> _deletePhoto(BuildContext context) async {
    if (sessionKey == null) return;
    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/deleteProfile'),
        headers: {'x-session-key': sessionKey!},
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        onUploaded?.call('');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Foto profil dihapus'),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    } catch (_) {}
  }
}

// ─────────────────────────────────────────────
// FULLSCREEN PHOTO VIEWER
// ─────────────────────────────────────────────
class _PhotoViewer extends StatelessWidget {
  final String url;
  final String username;

  const _PhotoViewer({required this.url, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          username,
          style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron'),
        ),
      ),
      body: Center(
        child: InteractiveViewer(
          child: Image.network(
            url,
            fit: BoxFit.contain,
            loadingBuilder: (_, child, progress) {
              if (progress == null) return child;
              return const Center(child: CircularProgressIndicator(color: Colors.white));
            },
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// HALAMAN PROFIL USER
// ─────────────────────────────────────────────
class UserProfilePage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String targetUsername;
  final String role;

  const UserProfilePage({
    super.key,
    required this.sessionKey,
    required this.myUsername,
    required this.targetUsername,
    required this.role,
  });

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  String? _photoUrl;
  String _userRole = '';
  String _expiredDate = '';
  String _displayName = '';
  String _bio = '';
  bool _loading = true;

  bool get _isOwn => widget.myUsername == widget.targetUsername;

  @override
  void initState() {
    super.initState();
    _fetchProfile();
  }

  Future<void> _fetchProfile() async {
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/getProfile?username=${widget.targetUsername}'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _photoUrl = data['photoUrl'];
          _userRole = data['role'] ?? '';
          _expiredDate = data['expiredDate'] ?? '';
          _displayName = data['displayName'] ?? '';
          _bio = data['bio'] ?? '';
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Color _roleColor(String role) {
    switch (role) {
      case 'owner': return Colors.amber;
      case 'admin': return Colors.redAccent;
      case 'developer': return Colors.purpleAccent;
      case 'vip': return Colors.cyanAccent;
      case 'reseller': return Colors.greenAccent;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tp = Provider.of<ThemeProvider>(context, listen: false);
    final primary = tp.primaryColor;
    final isDark = tp.isDarkMode;
    final bg = isDark ? const Color(0xFF060D18) : const Color(0xFFEEF2F7);
    final card = isDark ? const Color(0xFF0D1B2A) : Colors.white;
    final textColor = isDark ? Colors.white : const Color(0xFF0D1B2A);
    final textSub = isDark ? Colors.white.withAlpha(102) : Colors.black.withAlpha(102);

    return Scaffold(
      backgroundColor: bg,
      body: _loading
          ? Center(child: CircularProgressIndicator(color: primary))
          : CustomScrollView(
              slivers: [
                SliverAppBar(
                  expandedHeight: 200,
                  backgroundColor: card,
                  leading: IconButton(
                    icon: Icon(Icons.arrow_back_ios_new, color: primary),
                    onPressed: () => Navigator.pop(context),
                  ),
                  flexibleSpace: FlexibleSpaceBar(
                    background: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [primary.withAlpha(80), card],
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(height: 40),
                          ProfileAvatar(
                            username: widget.targetUsername,
                            photoUrl: _photoUrl,
                            radius: 45,
                            editable: _isOwn,
                            sessionKey: _isOwn ? widget.sessionKey : null,
                            onUploaded: (url) => setState(() => _photoUrl = url.isEmpty ? null : url),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            _displayName.isNotEmpty ? _displayName : widget.targetUsername,
                            style: TextStyle(
                              color: textColor,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          if (_displayName.isNotEmpty)
                            Text(
                              '@${widget.targetUsername}',
                              style: TextStyle(color: textSub, fontSize: 11),
                            ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                            margin: const EdgeInsets.only(top: 4),
                            decoration: BoxDecoration(
                              color: _roleColor(_userRole).withAlpha(30),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: _roleColor(_userRole).withAlpha(100)),
                            ),
                            child: Text(
                              _userRole.toUpperCase(),
                              style: TextStyle(
                                color: _roleColor(_userRole),
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        if (_expiredDate.isNotEmpty)
                          _infoCard(
                            Icons.access_time_rounded,
                            'Expired',
                            _expiredDate,
                            card, textColor, textSub, primary,
                          ),
                        const SizedBox(height: 8),
                        _infoCard(
                          Icons.person_rounded,
                          'Username',
                          widget.targetUsername,
                          card, textColor, textSub, primary,
                        ),
                        if (_bio.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          _infoCard(
                            Icons.info_outline_rounded,
                            'Bio',
                            _bio,
                            card, textColor, textSub, primary,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value, Color card, Color textColor, Color textSub, Color primary) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: primary.withAlpha(40)),
      ),
      child: Row(
        children: [
          Icon(icon, color: primary, size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(color: textSub, fontSize: 11)),
              Text(value, style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 14)),
            ],
          ),
        ],
      ),
    );
  }
}
