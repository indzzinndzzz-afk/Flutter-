// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Ditambahkan untuk fitur Copy Clipboard & Full Screen System UI
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'device_cache.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'dart:ui';

import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'admin_page.dart';
import 'gojo_wa.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'ddos_panel.dart';
import 'config_service.dart';
import 'asset_service.dart';
import 'device_dashboard.dart';
import 'owner_page.dart';
import 'developer_page.dart';
import 'home_page.dart';
import 'tools_gateway.dart';
import 'adzan_page.dart';
import 'stats_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'info_page.dart';
import 'settings_page.dart';
import 'slot_machine_page.dart';
import 'ular_tangga_online.dart';
import 'tebak_gambar_page.dart';
import 'leaderboard_page.dart';
import 'music_page.dart';
import 'pou_memory_page.dart';
import 'kisah_nabi_page.dart';
import 'shop_module.dart';
import 'bacaan_shalat_page.dart';
import 'pinterest_page.dart';
import 'manga_search_page.dart';
import 'donasi.dart';
import 'Remini.dart';
import 'novel_home_page.dart';
import 'otp_store_page.dart';
import 'remi_poker_page.dart';
import 'jadi_hitam_page.dart';
import 'chess_page.dart';
import 'snake_page.dart';
import 'iqc_page.dart';
import 'dashboard_page.dart';
import 'team_page.dart';

class LoaderDashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const LoaderDashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<LoaderDashboardPage> createState() => _LoaderDashboardPageState();
}

class _LoaderDashboardPageState extends State<LoaderDashboardPage> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- NEW: Controller untuk Video Background ---
  VideoPlayerController? _videoController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";

  // Theme colors — diupdate dari ThemeProvider di build()
  Color _accent  = const Color(0xFF25D366);
  Color _primary = const Color(0xFF25D366);

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  // Global key untuk mendapatkan posisi tombol Bug
  final GlobalKey _bugButtonKey = GlobalKey();
  // Global key untuk Scaffold agar bisa membuka drawer tanpa AppBar standar
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Controller for news page view
  final PageController _pageController = PageController(viewportFraction: 0.92);
  int _currentNewsIndex = 0;

  // Activity log state
  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  // --- Posisi & State Assistive Touch ---
  Offset _assistiveTouchPosition = const Offset(20, 150);
  bool _isAssistiveMenuOpen = false;
  
  String _activePage = 'home'; // Default page aktif

  // --- State untuk Floating Navigation Menu ---
  bool _isNavMenuOpen = false;
  OverlayEntry? _overlayEntry;

  // --- Anime auto-scroll ---
  final PageController _animePageController = PageController(viewportFraction: 0.38);
  int _currentAnimeIndex = 0;
  Timer? _animeScrollTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    // --- FITUR BARU: Membuat Aplikasi Full Screen Menutupi Status Bar ---
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 350),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();

    // Fetch activity logs when the page is first loaded
    _fetchActivityLogs();

    // --- NEW: Inisialisasi Video Background ---
    // Ditunda sampai frame pertama selesai render, biar gak numpuk
    // bareng kerjaan initState lain dan bikin dashboard kerasa lag pas baru dibuka.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initVideoBackground();
    });

    // --- Anime auto-scroll ---
    _startAnimeAutoScroll();
  }

  Future<void> _initVideoBackground() async {
    try {
      final path = await AssetService.videoPath('splash.mp4');
      final videoFile = File(path);
      if (!videoFile.existsSync()) {
        debugPrint('⚠️ splash.mp4 belum ada di: $path');
        return;
      }
      _videoController = VideoPlayerController.file(
        videoFile,
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
      );
      await _videoController!.initialize();
      _videoController!.setLooping(true);
      _videoController!.setVolume(0.0); // Mute background video
      await _videoController!.play();
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("Exception saat memuat video: $e");
    }
  }

  void _startAnimeAutoScroll() {
    _animeScrollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (!mounted) return;
      final next = (_currentAnimeIndex + 1) % _animeList.length;
      _animePageController.animateToPage(
        next,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
      setState(() => _currentAnimeIndex = next);
    });
  }

  Future<void> _initAndroidIdAndConnect() async {
    // Pakai cache (SharedPreferences + memory) biar gak panggil native
    // platform-channel device info berulang tiap loader page dibuka.
    final id = await DeviceCache.getAndroidId();
    // SetState dipanggil agar UI (seperti Account Stats Card) langsung menampilkan Device ID
    if(mounted) {
      setState(() {
        androidId = id;
      });
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse(ConfigService.baseUrl));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    });
  }

  // Fetch activity logs from API
  Future<void> _fetchActivityLogs() async {
    if(!mounted) return;
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/user/getActivityLogs?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          if(mounted) {
             setState(() {
              _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
              _isLoadingActivityLogs = false;
            });
          }
        } else {
          if(mounted) {
             setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
          }
        }
      } else {
         if(mounted) {
            setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
         }
      }
    } catch (e) {
      print('Error fetching activity logs: $e');
      if(mounted) {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _accent.withOpacity(0.3), width: 1), // Gray
        ),
        title: Text("⚠️ Session Expired", style: TextStyle(color: Colors.white, fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: _accent)), // Gray
          ),
        ],
      ),
    );
  }

  void _selectFromDrawer(String page) {
    // Video tetap jalan di semua halaman
    // --- FITUR BARU: Buka Account Menu dari Assistive Touch ---
    if (page == 'account') {
      setState(() {
        _isAssistiveMenuOpen = false; // Tutup menu melayang
      });
      _showAccountMenu(); // Panggil fungsi modal tanpa merubah halaman yang aktif
      return;
    }

    // === MODIFIKASI BARU: PERSISTENT SHELL UNTUK SEMUA HALAMAN ===
    if (page == 'rat') {
      // Daftar role yang diizinkan akses Device Dashboard
      List<String> allowedRoles = ['dev', 'high admin', 'admin', 'high owner', 'owner', 'vip', 'high vip', 'reseller', 'member_permanen'];
      
      if (allowedRoles.contains(role.toLowerCase())) {
        setState(() {
          _isAssistiveMenuOpen = false;
          _activePage = 'rat';
          _selectedPage = DeviceDashboardPage(
            username: username,
            role: role,
            sessionKey: sessionKey,
          );
        });
        _controller.reset();
        _controller.forward();
        return; 
      } else {
        setState(() { _isAssistiveMenuOpen = false; });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Akses ditolak: Role "$role" tidak bisa membuka Device Dashboard'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
        return;
      }
    }

    setState(() {
      _isAssistiveMenuOpen = false; // Tutup floating menu
      _activePage = page; // Set active page untuk styling navigasi bar
    });

    Widget nextWidget = _buildNewsPage(); // Default fallback
    
    // Switch halaman tujuan berdasarkan 'page' ke dalam '_selectedPage'
    if (page == 'home') {
      _selectedIndex = 0;
      nextWidget = _buildNewsPage();
    } else if (page == 'telegram') {
      nextWidget = HomePage(
        username: username,
        password: password,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'ddos') {
      nextWidget = AttackPanel(sessionKey: sessionKey, listDoos: listDoos);
    } else if (page == 'reseller') {
      nextWidget = SellerPage(keyToken: sessionKey, userRole: role, username: username);
    } else if (page == 'admin') {
      nextWidget = AdminPage(sessionKey: sessionKey, userRole: role, username: username);
    } else if (page == 'owner') {
      nextWidget = OwnerPage(sessionKey: sessionKey, username: username);
    } else if (page == 'developer') {
      nextWidget = DeveloperPage(sessionKey: sessionKey, username: username);
    } else if (page == 'profile') {
      nextWidget = ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
    } else if (page == 'settings') {
      nextWidget = SettingsPage();
    } else if (page == 'info') {
      nextWidget = InfoPage(sessionKey: sessionKey);
    } else if (page == 'tools') {
      nextWidget = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
    } else if (page == 'stats') {
      nextWidget = StatsPage(sessionKey: sessionKey, username: username, role: role);
    } else if (page == 'contact') {
      nextWidget = ContactPage();
    } else if (page == 'change_password') {
      nextWidget = ChangePasswordPage(username: username, sessionKey: sessionKey);
    } else if (page == 'bug_sender') {
      nextWidget = BugSenderPage(sessionKey: sessionKey, username: username, role: role);
    } else if (page == 'music') {
      nextWidget = const MusicPage();
    } else if (page == 'adzan') {
      nextWidget = const AdzanPage();
    } else if (page == 'otp_store') {
      nextWidget = const OtpStorePage();
    } else if (page == 'manga') {
      nextWidget = const MangaSearchPage();
    } else if (page == 'novel') {
      nextWidget = const NovelHomePage();
    } else if (page == 'shop') {
      context.read<ShopProvider>().setSessionKey(sessionKey);
      nextWidget = const ShopPage();
    } else if (page == 'kisah_nabi') {
      nextWidget = const KisahNabiPage();
    } else if (page == 'bacaan_shalat') {
      nextWidget = BacaanShalatPage(sessionKey: sessionKey);
    } else if (page == 'iqc') {
      nextWidget = const IqcPage();
    } else if (page == 'chess') {
      nextWidget = ChessPage(username: username, sessionKey: sessionKey);
    } else if (page == 'snake') {
      nextWidget = const SnakePage();
    } else if (page == 'remi_poker') {
      nextWidget = const RemiPokerPage();
    } else if (page == 'slot') {
      nextWidget = SlotMachinePage(username: username, sessionKey: sessionKey, role: role);
    } else if (page == 'ludo') {
      nextWidget = UlarTanggaOnlinePage(username: username, userRole: role, sessionKey: sessionKey);
    } else if (page == 'tebak_gambar') {
      nextWidget = TebakGambarPage(username: username, sessionKey: sessionKey, role: role);
    } else if (page == 'leaderboard') {
      nextWidget = LeaderboardPage(username: username, userRole: role);
    } else if (page == 'pou_memory') {
      nextWidget = const PouMemoryPage();
    } else if (page == 'remini') {
      nextWidget = ReminiPage();
    } else if (page == 'jadi_hitam') {
      nextWidget = const JadiHitamPage();
    } else if (page == 'pinterest') {
      nextWidget = PinterestSearchPage(sessionKey: sessionKey);
    } else if (page == 'TRICKSTER_wa') {
      nextWidget = TRICKSTERWaPage(sessionKey: sessionKey, username: username, role: role);
    } else if (page == 'group_chat') {
      nextWidget = ChatListPage(sessionKey: sessionKey, myUsername: username, role: role);
    } else if (page == 'donasi') {
      nextWidget = const DonasiPage();
    } else if (page == 'team') {
      nextWidget = const TeamPage();
    } else if (page == 'dashboard') {
      _openDashboard();
      return;
    }

    // Eksekusi pergantian konten dengan animasi FadeTransition
    setState(() {
      _selectedPage = nextWidget;
      _controller.reset();
      _controller.forward();
    });

    /* --- KODE NAVIGASI LAMA DIBIKIN COMMENT AGAR TIDAK DIHAPUS ---
    if (page == 'home') {
      setState(() {
        _selectedIndex = 0;
        _selectedPage = _buildNewsPage();
        _controller.reset();
        _controller.forward();
      });
    } else if (page == 'bug') {
      Navigator.push(context, MaterialPageRoute(builder: (context) => AttackPage( ... )));
    } ...
    */
  }

  // --- Fungsi untuk menampilkan menu navigasi floating seperti di foto ---
  void _toggleNavMenu() {
    if (_isNavMenuOpen) {
      _removeNavMenu();
    } else {
      _showNavMenu();
    }
  }

  void _showNavMenu() {
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
    setState(() {
      _isNavMenuOpen = true;
    });
  }

  void _removeNavMenu() {
    _overlayEntry?.remove();
    _overlayEntry = null;
    setState(() {
      _isNavMenuOpen = false;
    });
  }

  OverlayEntry _createOverlayEntry() {
    return OverlayEntry(
      builder: (context) => Positioned(
        bottom: 100,
        right: 20,
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: 200,
            decoration: BoxDecoration(
              color: const Color(0xFF0A0D0B).withOpacity(0.95),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _accent.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header Menu - Sama persis seperti di foto
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.white.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.menu, color: _accent, size: 18),
                      SizedBox(width: 8),
                      Text(
                        "NAVIGATION",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Menu Items - Sama persis urutannya seperti di foto
                _buildNavMenuItem(
                  icon: Icons.home,
                  label: "Home",
                  page: 'home',
                ),
                
                _buildNavMenuItem(
                  icon: FontAwesomeIcons.telegram,
                  label: "Spam",
                  page: 'telegram',
                ),
                
                _buildNavMenuItem(
                  icon: Icons.phone_android,
                  label: "RAT",
                  page: 'rat',
                ),
                
                _buildNavMenuItem(
                  icon: Icons.more_horiz,
                  label: "More",
                  page: 'more',
                  onTap: () {
                    _removeNavMenu();
                    // More tidak melakukan apa-apa
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavMenuItem({
    required IconData icon,
    required String label,
    required String page,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap ?? () {
        _removeNavMenu();
        _selectFromDrawer(page);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: Colors.white.withOpacity(0.05),
              width: 1,
            ),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white70, size: 18),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- HEADER BARU SEPERTI DI FOTO (PPL V2.0) ---
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      // SafeArea digunakan agar padding atas sesuai dengan status bar device
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12, 
        bottom: 12, 
        left: 16, 
        right: 16
      ),
      decoration: BoxDecoration(
        color: Colors.transparent, // --- MODIFIKASI: Dibuat Transparan ---
        border: Border(
          bottom: BorderSide(
            color: _accent.withOpacity(0.3),
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Logo di kiri (assets/images/logo.png)
          GestureDetector(
            onTap: () {
              // Navigasi ke home jika logo diklik
              _selectFromDrawer('home');
            },
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: _accent.withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: ClipOval(
                child: AssetService.image(
                  'logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: Colors.grey[900],
                      child: Icon(
                        Icons.bug_report,
                        color: _accent,
                        size: 20,
                      ),
                    );
                  },
                ),
              ),
            ),
          ),

          // Text "TRICKSTER CRAHSER VIP " dan username
          Row(
            children: [
              Text(
                "TRICKSTER X AREA VIP ",
                style: TextStyle(
                  color: _accent,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _accent.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  username, // Menggunakan username user
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontFamily: "ShareTechMono",
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),

          // Icon profile dan titik tiga
          Row(
            children: [
              // Icon Profile (membuka account menu)
              GestureDetector(
                onTap: _showAccountMenu,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _accent.withOpacity(0.5),
                      width: 1.5,
                    ),
                  ),
                  child: ClipOval(
                    child: Container(
                      color: Colors.grey[900],
                      child: Icon(
                        Icons.person,
                        color: _accent,
                        size: 20,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              
              // Titik tiga (tidak melakukan apa-apa)
              GestureDetector(
                onTap: () {
                  // Tidak melakukan apa-apa
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Menu coming soon', style: TextStyle(fontFamily: "ShareTechMono")),
                      backgroundColor: _accent,
                      duration: Duration(seconds: 1),
                    ),
                  );
                },
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _accent.withOpacity(0.5),
                      width: 1.5,
                    ),
                  ),
                  child: Icon(
                    Icons.more_vert,
                    color: _accent,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- WIDGETS TAMPILAN ---

  /* --- ORIGINAL ACCOUNT STATS CARD DIBIKIN COMMENT AGAR TIDAK DIHAPUS ---
  Widget _buildAccountStatsCardOriginal() {
    return Container(
      ... // Tampilan lama dengan background gelap dan device id
    );
  }
  */

  // --- ACCOUNT STATS CARD (Sesuai Screenshot PPL Project) ---
  Widget _buildAccountStatsCard() {
    final greenColor = _accent;

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.25),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // === BARIS 1: Icon person + Username + Copy ID ===
                Row(
                  children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: greenColor.withOpacity(0.15),
                        shape: BoxShape.circle,
                        border: Border.all(color: greenColor.withOpacity(0.4), width: 1),
                      ),
                      child: Icon(Icons.person, color: greenColor, size: 20),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            username.toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                              letterSpacing: 1.5,
                            ),
                          ),
                          Text(
                            "ID: ${androidId.length > 14 ? '${androidId.substring(0, 14)}...' : androidId}",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.45),
                              fontSize: 11,
                              fontFamily: "ShareTechMono",
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Copy ID button
                    GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: androidId));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("ID copied!"), duration: Duration(seconds: 1)),
                        );
                      },
                      child: Icon(Icons.copy, color: Colors.white.withOpacity(0.4), size: 18),
                    ),
                  ],
                ),

                const SizedBox(height: 14),
                Divider(color: Colors.white.withOpacity(0.08), height: 1),
                const SizedBox(height: 14),

                // === BARIS 2: Avatar kotak + Info role/exp/battery ===
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Avatar kotak
                    Container(
                      width: 90, height: 90,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: greenColor.withOpacity(0.5), width: 1.5),
                        image: DecorationImage(
                          image: AssetService.imageProvider("reze.png"),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),

                    // Info kanan avatar
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // ROLE
                          _infoRow(
                            icon: Icons.shield_outlined,
                            iconColor: greenColor,
                            label: "ROLE",
                            value: role.toUpperCase(),
                            valueColor: greenColor,
                          ),
                          const SizedBox(height: 10),
                          // EXP DATE
                          _infoRow(
                            icon: Icons.calendar_month_outlined,
                            iconColor: Colors.white54,
                            label: "EXP DATE",
                            value: expiredDate.split(' ').first,
                            valueColor: Colors.white,
                          ),
                          const SizedBox(height: 10),
                          // BATTERY
                          _batteryRow(),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 14),
                Divider(color: Colors.white.withOpacity(0.08), height: 1),
                const SizedBox(height: 10),

                // === BARIS 3: Cuaca kiri + Role & Lokasi kanan ===
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Cuaca (dummy, bisa diintegrasikan API)
                    Row(
                      children: [
                        Icon(Icons.wb_cloudy_outlined, color: Colors.amber, size: 18),
                        const SizedBox(width: 6),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "26°C",
                              style: TextStyle(color: Colors.white, fontSize: 13, fontFamily: "ShareTechMono", fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Partly Cloudy",
                              style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 10, fontFamily: "ShareTechMono"),
                            ),
                          ],
                        ),
                      ],
                    ),
                    // Lokasi & Role kanan
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.location_on_outlined, color: Colors.white.withOpacity(0.5), size: 12),
                            const SizedBox(width: 4),
                            Text(
                              "INDONESIA, ID",
                              style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10, fontFamily: "ShareTechMono"),
                            ),
                          ],
                        ),
                        Text(
                          "ROLE: ${role.toUpperCase()}",
                          style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10, fontFamily: "ShareTechMono"),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper: info row (icon + label + value)
  Widget _infoRow({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    required Color valueColor,
  }) {
    return Row(
      children: [
        Icon(icon, color: iconColor, size: 14),
        const SizedBox(width: 6),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 9, fontFamily: "ShareTechMono", letterSpacing: 0.5)),
            Text(value, style: TextStyle(color: valueColor, fontSize: 12, fontFamily: "ShareTechMono", fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }

  // Helper: battery row dengan ikon battery
  Widget _batteryRow() {
    return Row(
      children: [
        Icon(Icons.battery_2_bar, color: Colors.redAccent, size: 14),
        const SizedBox(width: 6),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("BATTERY", style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 9, fontFamily: "ShareTechMono", letterSpacing: 0.5)),
            Text("--", style: TextStyle(color: Colors.redAccent, fontSize: 12, fontFamily: "ShareTechMono", fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }

  // --- WIDGET HALAMAN UTAMA ---
  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: _accent,
      onRefresh: () async {
        await _fetchActivityLogs();
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: SizedBox(height: MediaQuery.of(context).padding.top + 70),
          ),
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),

                // 1. ACCOUNT STATS CARD
                _buildAccountStatsCard(),

                const SizedBox(height: 20),

                // 2. FEATURED BANNER (WhatsApp Crash)
                _buildFeaturedBanner(),

                const SizedBox(height: 20),

                // 3. ANIME SECTION
                _buildAnimeSection(),

                const SizedBox(height: 20),

                // 4. NEWS & UPDATES section label
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "NEWS & UPDATES",
                        style: TextStyle(
                          color: _accent,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // 4. NEWS CAROUSEL
                _buildNewsCarousel(),

                const SizedBox(height: 20),

                // 5. RECENT ACTIVITY
                _buildRecentActivity(),

                const SizedBox(height: 120),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- ANIME SECTION (Hardcode) ---
  final List<Map<String, String>> _animeList = const [
    {
      "title": "Himekishi wa Barbaroi no Yome",
      "ep": "EP 4",
      "image": "anime1.png",
    },
    {
      "title": "The Beginning After the End S...",
      "ep": "EP 5",
      "image": "anime2.png",
    },
    {
      "title": "Nigashita Sakana wa Ookikatta ga...",
      "ep": "EP 3",
      "image": "anime3.png",
    },
    {
      "title": "Ore dake Level Up na Ken",
      "ep": "EP 12",
      "image": "anime4.png",
    },
    {
      "title": "Dandadan",
      "ep": "EP 6",
      "image": "anime5.png",
    },
  ];

  Widget _buildAnimeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label baris atas
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "ANIME",
                style: TextStyle(
                  color: _accent,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                "MORE ANIME >",
                style: TextStyle(
                  color: _accent,
                  fontSize: 11,
                  fontFamily: "ShareTechMono",
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 12),

        // Auto-scroll PageView card anime (portrait)
        SizedBox(
          height: 185,
          child: PageView.builder(
            controller: _animePageController,
            itemCount: _animeList.length,
            onPageChanged: (i) => setState(() => _currentAnimeIndex = i),
            itemBuilder: (context, index) {
              final anime = _animeList[index];
              return Container(
                width: 120,
                margin: const EdgeInsets.only(right: 10, left: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.black,
                  border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Stack(
                    children: [
                      // Gambar anime dari asset
                      Positioned.fill(
                        child: AssetService.image(
                          anime['image']!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: const Color(0xFF1A1A2E),
                            child: Icon(Icons.movie, color: Colors.white24, size: 30),
                          ),
                        ),
                      ),

                      // Gradient overlay bawah
                      Positioned.fill(
                        child: Container(
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.transparent, Colors.black87],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              stops: [0.4, 1.0],
                            ),
                          ),
                        ),
                      ),

                      // Badge EP (pojok kiri atas)
                      Positioned(
                        top: 6,
                        left: 6,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            anime['ep']!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 8,
                              fontFamily: "ShareTechMono",
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),

                      // Judul di bawah
                      Positioned(
                        bottom: 6,
                        left: 6,
                        right: 6,
                        child: Text(
                          anime['title']!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontFamily: "ShareTechMono",
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),

        // Dots indicator anime
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            _animeList.length,
            (index) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              height: 5,
              width: _currentAnimeIndex == index ? 18 : 5,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _currentAnimeIndex == index
                    ? _accent
                    : Colors.white.withOpacity(0.2),
              ),
            ),
          ),
        ),
      ],
    );
  }
  Widget _buildFeaturedBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Label FEATURED + MORE >
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "FEATURED",
                style: TextStyle(
                  color: _accent,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                  letterSpacing: 1.5,
                ),
              ),
              GestureDetector(
                onTap: () => _selectFromDrawer('tools'),
                child: Text(
                  "MORE TOOLS >",
                  style: TextStyle(
                    color: _accent,
                    fontSize: 11,
                    fontFamily: "ShareTechMono",
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Banner hijau WhatsApp Crash
          GestureDetector(
            onTap: () => _selectFromDrawer('tools'),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_accent, _accent],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: _accent.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  // Icon WA besar di kanan (dekorasi)
                  Positioned(
                    right: -10,
                    top: -10,
                    child: Icon(
                      FontAwesomeIcons.whatsapp,
                      size: 90,
                      color: Colors.white.withOpacity(0.12),
                    ),
                  ),
                  // Konten teks
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 22),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "WHATSAPP CRASH",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Orbitron",
                                letterSpacing: 1,
                              ),
                            ),
                            SizedBox(height: 6),
                            Text(
                              "Send custom payloads to crash target WhatsApp.",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: "ShareTechMono",
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'owner':
        return Colors.red;
      case 'dev':
        return Colors.red;
      case 'high owner':
        return Colors.red;
      case 'vip':
        return Colors.amber;
      case 'reseller':
        return Colors.blue;
      default:
        return _accent; // Gray
    }
  }

  // Fungsi Pembantu untuk Top Menu di dalam News Carousel (Tetap ada di original jika ingin dipakai)
  Widget _buildFeatureIcon({required IconData icon, required String title, required String subtitle}) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: _accent, size: 26), // Abu-abu menyala
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1.0,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 10,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /* --- ORIGINAL NEWS CAROUSEL DIBIKIN COMMENT AGAR TIDAK DIHAPUS (SESUAI PERMINTAAN) ---
  Widget _buildNewsCarouselOriginal() {
    if (newsList.isEmpty) { ... }
    return Container(
      ... // Tampilan lama dengan Icon Pedang, Tengkorak, dll
    );
  }
  */

  // --- NEW: NEWS CAROUSEL CARD TAMPILAN BARU SESUAI FOTO PPL ---
  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        height: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.black.withOpacity(0.3),
          border: Border.all(color: _accent.withOpacity(0.2)),
        ),
        child: Center(child: Text("No news available", style: TextStyle(color: Colors.white54))),
      );
    }

    return Column(
      children: [
        // IMAGE CAROUSEL DENGAN TAMPILAN CARD BARU
        SizedBox(
          height: 280, // Tinggi diperbesar untuk memuat teks di bawah gambar dalam satu card
          child: PageView.builder(
            controller: _pageController,
            itemCount: newsList.length,
            onPageChanged: (index) {
              setState(() {
                _currentNewsIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = newsList[index];
              return ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.1), width: 1.5),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // --- BAGIAN ATAS: GAMBAR ---
                        Expanded(
                          flex: 6,
                          child: ClipRRect(
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(14.5)),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                AssetService.image(
                                  'titit.png',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(color: Colors.black26),
                                ),
                                // Gradient overlay bawah
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.black.withOpacity(0.4),
                                        Colors.transparent,
                                      ],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.center,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        // --- BAGIAN BAWAH: ICON + JUDUL + DESKRIPSI ---
                        Expanded(
                          flex: 4,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.newspaper_outlined,
                                      color: _accent,
                                      size: 22,
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        item['title'] ?? "TRICKSTER X AREA TEAM",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: "Orbitron",
                                          letterSpacing: 1.0,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  item['desc'] ?? "Admin Bukan Pedofil Yak.",
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.7),
                                    fontSize: 13,
                                    fontFamily: "ShareTechMono",
                                    letterSpacing: 0.5,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        
        // DOTS INDICATOR
        if (newsList.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                newsList.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 6,
                  width: _currentNewsIndex == index ? 24 : 8, // Sedikit lebih memanjang jika aktif
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: _currentNewsIndex == index
                        ? _accent // Warna aktif Hijau menyesuaikan tema baru
                        : Colors.white.withOpacity(0.2),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  // --- RECENT ACTIVITY ---
  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // --- KODE BARU RECENT ACTIVITY (Menyerupai Foto) ---
          Text(
            "RECENT ACTIVITY",
            style: TextStyle(
              color: _accent, // Warna hijau neon ala WA
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: "Orbitron",
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 15),

          if (_isLoadingActivityLogs)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: _accent.withOpacity(0.2), // Gray
                  width: 1,
                ),
              ),
              child: Center(
                child: CircularProgressIndicator(color: _accent), // Gray
              ),
            )
          else if (_hasActivityLogsError)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: Colors.red.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: Center(
                child: Text(
                  "Failed to load activity logs",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          else if (_activityLogs.isEmpty)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: _accent.withOpacity(0.2), // Gray
                  width: 1,
                ),
              ),
              child: Center(
                child: Text(
                  "No activity logs available",
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          else
            ..._activityLogs.take(5).map((log) { // Mengambil 5 baris agar persis gambar
              final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);

              String activityText = log['activity'] ?? 'Unknown Activity';
              if (log['details'] != null && log['details']['target'] != null) {
                 // Opsional jika Anda punya detail tambahan di DB 
              }

              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF121413), // Warna background sangat gelap (pekat)
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.05), // Garis luar sangat transparan
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 5,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.history, // Ikon history sesuai gambar
                        color: Colors.white54,
                        size: 16,
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Text(
                          activityText,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontFamily: "ShareTechMono",
                            fontSize: 13,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        formattedTime,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontFamily: "ShareTechMono",
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  Widget _buildActivityDetails(Map<String, dynamic> details) {
    return Container(
      margin: const EdgeInsets.only(top: 8, left: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: details.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("${entry.key}:", style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12)),
                const SizedBox(width: 5),
                Expanded(child: Text(entry.value.toString(), style: const TextStyle(color: Colors.white70, fontSize: 12))),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Color _getActivityColor(String? activity) {
    if (activity == null) return Colors.grey;
    if (activity.contains('Bug') || activity.contains('Attack') || activity.contains('Delete') || activity.contains('Failed')) {
      return Colors.red;
    } else if (activity.contains('Call')) {
      return Colors.orange;
    } else if (activity.contains('Create') || activity.contains('Add')) {
      return Colors.green;
    } else if (activity.contains('Edit') || activity.contains('Change')) {
      return Colors.blue;
    } else if (activity.contains('Cooldown')) {
      return Colors.amber;
    }
    return _accent; // Gray
  }

  IconData _getActivityIcon(String? activity) {
    if (activity == null) return Icons.info;
    if (activity.contains('Bug') || activity.contains('Attack')) return Icons.bug_report;
    if (activity.contains('Call')) return Icons.phone;
    if (activity.contains('Create') || activity.contains('Add')) return Icons.person_add;
    if (activity.contains('Delete')) return Icons.delete;
    if (activity.contains('Edit') || activity.contains('Change')) return Icons.edit;
    if (activity.contains('Cooldown')) return Icons.timer;
    if (activity.contains('DDOS')) return Icons.flash_on;
    return Icons.info;
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    if (difference.inDays > 0) return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    if (difference.inHours > 0) return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    if (difference.inMinutes > 0) return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    return 'Just now';
  }

  // Glassmorphism card widget (Used by Account Menu, etc)
  Widget _glassCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.black.withOpacity(0.2), // Lebih transparan sesuai request
        border: Border.all(
          color: _accent.withOpacity(0.2), // Gray
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: _accent.withOpacity(0.05), // Gray
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5), // Blur lebih halus
          child: child,
        ),
      ),
    );
  }

  // Glassmorphism button widget
  Widget _glassButton({required Icon icon, required Text label, required VoidCallback onPressed}) {
    return ElevatedButton.icon(
      icon: icon,
      label: label,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: _accent, // Gray
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _accent.withOpacity(0.3), width: 1), // Gray
        ),
      ),
      onPressed: onPressed,
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Account Info", style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: "Orbitron")),
                const SizedBox(height: 12),
                _infoCard(Icons.person, "Username", username),
                _infoCard(Icons.date_range, "Expired", expiredDate),
                _infoCard(Icons.security, "Role", role),
                const SizedBox(height: 20),
                _glassButton(
                  icon: Icon(Icons.lock_reset),
                  label: Text("Change Password"),
                  onPressed: () {
                    Navigator.pop(context);
                    // Modifikasi agar tetap berada dalam persistent shell
                    setState(() {
                      _activePage = 'change_password';
                      _selectedPage = ChangePasswordPage(
                        username: username,
                        sessionKey: sessionKey,
                      );
                      _controller.reset();
                      _controller.forward();
                    });
                    
                    /* --- KODE LAMA DIBIKIN COMMENT ---
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: username,
                          sessionKey: sessionKey,
                        ),
                      ),
                    );
                    */
                  },
                ),
                const SizedBox(height: 10),
                _glassButton(
                  icon: Icon(Icons.logout),
                  label: Text("Logout"),
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                          (route) => false,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _accent.withOpacity(0.2), width: 1), // Gray
      ),
      child: Row(
        children: [
          Icon(icon, color: _accent), // Gray
          const SizedBox(width: 10),
          Text("$label:", style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
          const Spacer(),
          Text(value, style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono")),
        ],
      ),
    );
  }

  Widget _buildLogo({double height = 40}) {
    return Text(
      "TRICKSTER X AREA",
      style: TextStyle(
        color: _accent,
        fontSize: 18,
        fontWeight: FontWeight.bold,
        fontFamily: "Orbitron",
        letterSpacing: 2,
      ),
    );
  }

  // ─── Role Getters (same as DashboardPage) ────────────────────────────────
  bool get _isTk => role == 'tk';
  bool get _isOwner => role == 'owner';
  bool get _isVip => role == 'vip';
  bool get _isReseller => role == 'reseller';

  // ─── Logout ───────────────────────────────────────────────────────────────
  void _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  // ─── Build Menu Items (mirrored from DashboardPage) ───────────────────────
  List<Widget> _buildMenuItems(Color accent) {
    final sections = [
      {
        'title': 'NAVIGASI',
        'items': [
          {'icon': Icons.home_rounded, 'label': 'Home', 'onTap': () => _selectFromDrawer('home')},
                    {'icon': Icons.palette_rounded, 'label': 'Ganti Warna', 'onTap': () => _selectFromDrawer('settings')},
          {'icon': Icons.phonelink_rounded, 'label': 'Rant', 'onTap': () => _selectFromDrawer('rat')},
          {'icon': Icons.store_rounded, 'label': 'Shop', 'onTap': () => _selectFromDrawer('shop')},
          {'icon': FontAwesomeIcons.whatsapp, 'label': 'Menu Bug', 'onTap': () => _selectFromDrawer('telegram')},
          {'icon': Icons.bug_report_rounded, 'label': 'Sender', 'onTap': () => _selectFromDrawer('bug_sender')},
          {'icon': Icons.telegram, 'label': 'Whatsap chat TRICKSTER', 'onTap': () => _selectFromDrawer('group_chat')},
          {'icon': Icons.manage_accounts_rounded, 'label': 'Foto Profile Wa TRICKSTER', 'onTap': () => _selectFromDrawer('profile')},
          {'icon': FontAwesomeIcons.whatsapp, 'label': 'Pairing bot TRICKSTER via wa', 'onTap': () => _selectFromDrawer('TRICKSTER_wa')},
          {'icon': Icons.bar_chart_rounded, 'label': 'Stats', 'onTap': () => _selectFromDrawer('stats')},
          {'icon': Icons.info_rounded, 'label': 'Info', 'onTap': () => _selectFromDrawer('info')},
          {'icon': Icons.build_rounded, 'label': 'Tools', 'onTap': () => _selectFromDrawer('tools')},
          {'icon': Icons.sim_card_rounded, 'label': 'toko store alwaysZillxy', 'onTap': () => _selectFromDrawer('otp_store')},
        ],
      },
      {
        'title': 'HIBURAN',
        'items': [
          {'icon': Icons.gesture, 'label': 'Snake Nokia', 'onTap': () => _selectFromDrawer('snake')},
          {'icon': Icons.grid_on_rounded, 'label': 'catur', 'onTap': () => _selectFromDrawer('chess')},
          {'icon': Icons.dark_mode_rounded, 'label': 'Jadi Hitam', 'onTap': () => _selectFromDrawer('jadi_hitam')},
          {'icon': Icons.style_rounded, 'label': 'Remi Poker', 'onTap': () => _selectFromDrawer('remi_poker')},
          {'icon': Icons.casino_rounded, 'label': 'Kasino', 'onTap': () => _selectFromDrawer('slot')},
          {'icon': Icons.sports_esports_rounded, 'label': 'Ular Tangga', 'onTap': () => _selectFromDrawer('ludo')},
          {'icon': Icons.image_search_rounded, 'label': 'Tebak Gambar', 'onTap': () => _selectFromDrawer('tebak_gambar')},
          {'icon': Icons.style_rounded, 'label': 'Pou Memory', 'onTap': () => _selectFromDrawer('pou_memory')},
          {'icon': Icons.leaderboard_rounded, 'label': 'Leaderboard', 'onTap': () => _selectFromDrawer('leaderboard')},
          {'icon': Icons.music_note_rounded, 'label': 'Music', 'onTap': () => _selectFromDrawer('music')},
          {'icon': Icons.image_rounded, 'label': 'Pinterest', 'onTap': () => _selectFromDrawer('pinterest')},
          {'icon': Icons.menu_book_rounded, 'label': 'komik anime manga', 'onTap': () => _selectFromDrawer('manga')},
          {'icon': Icons.auto_fix_high_rounded, 'label': 'Remini HD', 'onTap': () => _selectFromDrawer('remini')},
          {'icon': Icons.auto_stories_rounded, 'label': 'Novel AI', 'onTap': () => _selectFromDrawer('novel')},
        ],
      },
      {
        'title': 'ISLAMI',
        'items': [
          {'icon': Icons.mosque_outlined, 'label': 'Jadwal Shalat', 'onTap': () => _selectFromDrawer('adzan')},
          {'icon': Icons.menu_book_rounded, 'label': 'Kisah Nabi', 'onTap': () => _selectFromDrawer('kisah_nabi')},
          {'icon': Icons.record_voice_over_rounded, 'label': 'Bacaan Shalat', 'onTap': () => _selectFromDrawer('bacaan_shalat')},
        ],
      },
      {
        'title': 'LAINNYA',
        'items': [
          {'icon': Icons.gamepad_rounded, 'label': 'Top Up Game', 'onTap': _openCodashop},
          {'icon': Icons.smart_toy_rounded, 'label': 'IQC IPHONE', 'onTap': () => _selectFromDrawer('iqc')},
          {'icon': Icons.lock_rounded, 'label': 'Change Password', 'onTap': () => _selectFromDrawer('change_password')},
          {'icon': Icons.headset_mic_rounded, 'label': 'Contact CS', 'onTap': () => _selectFromDrawer('contact')},
          {'icon': Icons.favorite_rounded, 'label': 'Donasi', 'onTap': () => _selectFromDrawer('donasi')},
          {'icon': Icons.dashboard_rounded, 'label': 'Ke Dashboard', 'onTap': () => _selectFromDrawer('dashboard')},
        ],
      },
    ];

    final adminItems = <Map<String, dynamic>>[];
    if (_isVip) {
      adminItems.add({'icon': Icons.admin_panel_settings_rounded, 'label': 'Admin Page', 'onTap': () => _selectFromDrawer('admin')});
    }
    if (_isReseller) {
      adminItems.add({'icon': Icons.store_rounded, 'label': 'Seller Page', 'onTap': () => _selectFromDrawer('reseller')});
    }
    if (_isOwner) {
      adminItems.add({'icon': Icons.star_rounded, 'label': 'Owner Page', 'onTap': () => _selectFromDrawer('owner')});
    }
    if (_isTk) {
      adminItems.add({'icon': Icons.developer_mode_rounded, 'label': 'Developer Page', 'onTap': () => _selectFromDrawer('developer')});
    }
    if (adminItems.isNotEmpty) {
      sections.insert(1, {'title': 'ADMIN', 'items': adminItems});
    }

    final widgets = <Widget>[];

    for (final section in sections) {
      widgets.add(Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
        child: Text(section['title'] as String,
            style: TextStyle(
                color: accent.withValues(alpha: 0.5),
                fontSize: 9,
                letterSpacing: 2.5,
                fontWeight: FontWeight.w700)),
      ));

      for (final item in section['items'] as List<Map<String, dynamic>>) {
        widgets.add(InkWell(
          onTap: () {
            _removeNavMenu();
            setState(() { _isAssistiveMenuOpen = false; });
            (item['onTap'] as VoidCallback)();
          },
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            child: Row(children: [
              Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: accent.withValues(alpha: 0.12))),
                  child: Icon(item['icon'] as IconData, color: accent, size: 16)),
              const SizedBox(width: 10),
              Text(item['label'] as String,
                  style: const TextStyle(color: Colors.white, fontSize: 13)),
            ]),
          ),
        ));
      }

      if (section != sections.last || adminItems.isNotEmpty) {
        widgets.add(Divider(
            color: Colors.white.withValues(alpha: 0.05),
            height: 1,
            indent: 12,
            endIndent: 12));
      }
    }

    widgets.add(const SizedBox(height: 4));
    widgets.add(InkWell(
      onTap: _logout,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
        child: Row(children: [
          Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.withValues(alpha: 0.2))),
              child: Icon(Icons.logout_rounded, color: Colors.redAccent, size: 16)),
          const SizedBox(width: 10),
          Text('Logout',
              style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 13,
                  fontWeight: FontWeight.w600)),
        ]),
      ),
    ));

    return widgets;
  }

  // ─── Navigation Helpers (mirrored from DashboardPage) ───────────────────

  void _loaderNavigateTo(Widget page) {
    setState(() {
      _selectedPage = page;
      _controller.reset();
      _controller.forward();
    });
  }

  void _openChess() => _loaderNavigateTo(
      ChessPage(username: username, sessionKey: sessionKey));

  void _openSnake() => _loaderNavigateTo(const SnakePage());

  void _openRemini() => _loaderNavigateTo(ReminiPage());

  void _openJadiHitam() => _loaderNavigateTo(const JadiHitamPage());

  void _openRemiPoker() => _loaderNavigateTo(const RemiPokerPage());

  void _openDeviceDashboard() => _loaderNavigateTo(DeviceDashboardPage(
      username: username,
      role: role,
      sessionKey: sessionKey,
    ));

  void _openOtpStore() => _loaderNavigateTo(const OtpStorePage());

  void _openNovelPage() => _loaderNavigateTo(const NovelHomePage());

  void _openTRICKSTERWa() => _loaderNavigateTo(
      TRICKSTERWaPage(sessionKey: sessionKey, username: username, role: role));

  void _openMangaSearch() => _loaderNavigateTo(const MangaSearchPage());

  void _openKisahNabi() => _loaderNavigateTo(const KisahNabiPage());

  void _openIqcPage() => _loaderNavigateTo(const IqcPage());

  void _openShopPage() {
    context.read<ShopProvider>().setSessionKey(sessionKey);
    _loaderNavigateTo(const ShopPage());
  }

  void _openPinterest() =>
      _loaderNavigateTo(PinterestSearchPage(sessionKey: sessionKey));

  void _openSlotMachine() => _loaderNavigateTo(
      SlotMachinePage(username: username, sessionKey: sessionKey, role: role));

  void _openBacaanShalat() =>
      _loaderNavigateTo(BacaanShalatPage(sessionKey: sessionKey));

  void _openLudo() => _loaderNavigateTo(UlarTanggaOnlinePage(
      username: username, userRole: role, sessionKey: sessionKey));

  void _openTebakGambar() => _loaderNavigateTo(TebakGambarPage(
      username: username, sessionKey: sessionKey, role: role));

  void _openLeaderboard() =>
      _loaderNavigateTo(LeaderboardPage(username: username, userRole: role));

  void _openInfoPage() =>
      _loaderNavigateTo(InfoPage(sessionKey: sessionKey));

  void _openToolsPage() => _loaderNavigateTo(
      ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos));

  void _openChangePassword() => _loaderNavigateTo(
      ChangePasswordPage(username: username, sessionKey: sessionKey));

  void _openBugSender() => _loaderNavigateTo(
      BugSenderPage(sessionKey: sessionKey, username: username, role: role));

  void _openProfile() => _loaderNavigateTo(ProfilePage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey));

  void _openStats() => _loaderNavigateTo(
      StatsPage(sessionKey: sessionKey, username: username, role: role));

  void _openContact() => _loaderNavigateTo(ContactPage());

  void _openAdzan() => _loaderNavigateTo(const AdzanPage());

  void _openMusicPage() => _loaderNavigateTo(const MusicPage());

  void _openPouMemory() => _loaderNavigateTo(const PouMemoryPage());

  void _openSellerPage() => _loaderNavigateTo(
      SellerPage(keyToken: sessionKey, userRole: role, username: username));

  void _openAdminPage() => _loaderNavigateTo(
      AdminPage(sessionKey: sessionKey, userRole: role, username: username));

  void _openOwnerPage() =>
      _loaderNavigateTo(OwnerPage(sessionKey: sessionKey, username: username));

  void _openDeveloperPage() => _loaderNavigateTo(
      DeveloperPage(sessionKey: sessionKey, username: username));

  void _openSettingsPage() => _loaderNavigateTo(SettingsPage());

  void _openGroupChat() => _loaderNavigateTo(
      ChatListPage(sessionKey: sessionKey, myUsername: username, role: role));

  void _openDonasi() => _loaderNavigateTo(const DonasiPage());

  void _openDashboard() => Navigator.pushReplacement(
      context,
      MaterialPageRoute(
          builder: (_) => DashboardPage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              listBug: listBug,
              listDoos: listDoos,
              sessionKey: sessionKey,
              news: newsList)));

  void _openTeamPage() => _loaderNavigateTo(const TeamPage());

  void _openCodashop() async {
    final Uri url = Uri.parse('https://www.momomlbb.com/id-id');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
    _resumeVideoIfNeeded();
  }

  // ─── End Navigation Helpers ──────────────────────────────────────────────

  // --- NEW: COMPACT ASSISTIVE MENU WIDGET (Sesuai Foto) ---
  Widget _buildAssistiveMenu() {
    final String currentRole = role.toLowerCase();
    
    // RBAC Permissions Logic
    final bool canAccessAdmin = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(currentRole);
    final bool canAccessSeller = ['dev', 'high admin', 'admin', 'high owner', 'owner', 'reseller'].contains(currentRole);
    
    // Daftar role yang bisa akses RAT
    final bool canAccessRat = ['dev', 'high admin', 'admin', 'high owner', 'owner'].contains(currentRole);

    return Material(
      color: Colors.transparent,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 240,
          maxHeight: MediaQuery.of(context).size.height * 0.65, // Max 65% tinggi layar
        ),
        child: Container(
          width: 240,
          decoration: BoxDecoration(
          color: const Color(0xFF0A0D0B),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _accent.withOpacity(0.2), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 15,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Scrollbar(
              thumbVisibility: true,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: _buildMenuItems(_accent),
                ),
              ),
            ),
          ),
        ),
      ),
      ), // end Material
    );
  }
  Widget _assistiveMenuItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page; // Cek apakah menu ini sedang dibuka

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), // Padding luar agar border radius pas
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          splashColor: _accent.withOpacity(0.2), // Splash efek hijau ala WA saat di-klik
          highlightColor: _accent.withOpacity(0.1),
          onTap: () => _selectFromDrawer(page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: isActive ? BoxDecoration(
              color: _accent.withOpacity(0.15), // Background hijau gelap saat aktif
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF20402E), width: 1), // Border hijau
            ) : null, // Tidak ada background/border jika tidak aktif
            child: Row(
              children: [
                Icon(icon, color: isActive ? _accent : Colors.white70, size: 18),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    title, 
                    style: TextStyle(
                      color: isActive ? Colors.white : Colors.white70, 
                      fontSize: 14, 
                      fontFamily: "ShareTechMono", 
                      fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                      letterSpacing: 1.0
                    )
                  ),
                ),
                if (isActive) // Titik bulat hijau di ujung kanan khusus menu aktif
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: _accent,
                      shape: BoxShape.circle,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- NEW: FLOATING NAVIGATION BAR BAWAH ---
  Widget _buildFloatingNavBar() {
    return Positioned(
      bottom: 30, // Mengambang tidak menempel di tepi bawah
      left: 15,
      right: 15,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0A0D0B).withOpacity(0.95), // Latar gelap
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: _accent.withOpacity(0.3), // Abu-abu border
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _accent.withOpacity(0.15), // Efek menyala (Glow abu-abu)
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildFloatingNavItem(Icons.home_filled, "Home", 'home'),
            _buildFloatingNavItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
            _buildFloatingNavItem(Icons.phone_android, "RAT", 'rat'),
            _buildFloatingNavItem(Icons.more_horiz, "More", 'more'),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingNavItem(IconData icon, String label, String page) {
    bool isActive = _activePage == page;

    return GestureDetector(
      onTap: () {
        if (page == 'more') {
          // Buka assistive menu jika ditekan more
          setState(() {
            _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
          });
        } else {
          _selectFromDrawer(page);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: isActive
            ? BoxDecoration(
                color: _accent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _accent.withOpacity(0.5), // Kotak nyala abu-abu
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _accent.withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              )
            : const BoxDecoration(), // Kosong jika tidak aktif
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? _accent : Colors.white54,
              size: 22,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: isActive ? _accent : Colors.white54,
                fontSize: 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final accent = theme.accentColor;
    final primary = theme.primaryColor;
    _accent  = accent;
    _primary = primary;
    // Menangkap ukuran layar untuk batasan Assistive Touch & Animasi Menu
    final screenSize = MediaQuery.of(context).size;
    final bool isRightSide = _assistiveTouchPosition.dx > (screenSize.width / 2);
    final bool isBottomSide = _assistiveTouchPosition.dy > (screenSize.height / 2);

    // Menggunakan PopScope / WillPopScope agar ketika memencet tombol 'Back' bawaan HP,
    // aplikasi akan kembali ke Home terlebih dahulu (menjaga UI cangkang/shell).
    return WillPopScope(
      onWillPop: () async {
        if (_activePage != 'home') {
          _selectFromDrawer('home');
          return false; // Mencegah keluar aplikasi
        }
        return true; // Keluar aplikasi jika sudah di home
      },
      child: Scaffold(
        key: _scaffoldKey, 
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        
        body: Stack(
          children: [
            // 1. Background Video (TETAP ADA)
            SizedBox.expand(
              child: _videoController != null && _videoController!.value.isInitialized
                  ? FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _videoController!.value.size.width,
                        height: _videoController!.value.size.height,
                        child: VideoPlayer(_videoController!),
                      ),
                    )
                  : Container(color: Colors.black),
            ),
            
            // 2. Layer gelap tipis agar video tetap keliatan tapi teks terbaca
            Container(color: Colors.black.withOpacity(0.35)),

            // 3. Main Content dengan SlideTransition + FadeTransition
            SafeArea(
              top: false,
              bottom: false,
              child: AnimatedBuilder(
                animation: _animation,
                builder: (context, child) => FadeTransition(
                  opacity: _animation,
                  child: Transform.translate(
                    offset: Offset(0, 18 * (1 - _animation.value)),
                    child: child,
                  ),
                ),
                child: _selectedPage,
              ),
            ),

            // 4. Header Statis 
            // Disembunyikan saat membuka halaman selain 'home' agar tidak bertabrakan dengan AppBar halaman lain
            if (_activePage == 'home')
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: _buildHeader(),
              ),

            // 5. Layer Transparan untuk menutup menu jika di-tap di luar area
            if (_isAssistiveMenuOpen)
              Positioned.fill(
                child: GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: () {
                    setState(() {
                      _isAssistiveMenuOpen = false;
                    });
                  },
                  child: Container(
                    color: Colors.transparent, // Tak terlihat tapi menangkap ketukan
                  ),
                ),
              ),

            // 6. Animasi Menu Pop-Up
            Builder(builder: (context) {
              final double menuWidth = 240;
              final double menuMaxHeight = screenSize.height * 0.65;
              final double bubbleX = _assistiveTouchPosition.dx;
              final double bubbleY = _assistiveTouchPosition.dy;

              // Hitung posisi X menu (kiri atau kanan bubble)
              double menuLeft;
              if (isRightSide) {
                menuLeft = bubbleX - menuWidth - 10;
                if (menuLeft < 8) menuLeft = 8; // Jangan sampai ke luar layar kiri
              } else {
                menuLeft = bubbleX + 70;
                if (menuLeft + menuWidth > screenSize.width - 8) {
                  menuLeft = screenSize.width - menuWidth - 8;
                }
              }

              // Hitung posisi Y menu (atas atau bawah bubble)
              double menuTop;
              if (isBottomSide) {
                menuTop = bubbleY - menuMaxHeight - 10;
                if (menuTop < 60) menuTop = 60; // Jangan sampai keluar atas
              } else {
                menuTop = bubbleY;
                if (menuTop + menuMaxHeight > screenSize.height - 100) {
                  menuTop = screenSize.height - menuMaxHeight - 100;
                }
                if (menuTop < 60) menuTop = 60;
              }

              return AnimatedPositioned(
                duration: const Duration(milliseconds: 150),
                left: menuLeft,
                top: menuTop,
                child: IgnorePointer(
                  // Kalau menu tutup, jangan tangkap tap sama sekali
                  ignoring: !_isAssistiveMenuOpen,
                  child: AnimatedScale(
                    scale: _isAssistiveMenuOpen ? 1.0 : 0.0,
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOutBack,
                    alignment: isRightSide
                        ? (isBottomSide ? Alignment.bottomRight : Alignment.topRight)
                        : (isBottomSide ? Alignment.bottomLeft : Alignment.topLeft),
                    child: _buildAssistiveMenu(),
                  ),
                ),
              );
            }),

            // 7. Assistive Touch Bubble
            Positioned(
              left: _assistiveTouchPosition.dx,
              top: _assistiveTouchPosition.dy,
              child: GestureDetector(
                onPanUpdate: (details) {
                  setState(() {
                    // Jika menu terbuka lalu di-drag, otomatis tertutup
                    if (_isAssistiveMenuOpen) {
                       _isAssistiveMenuOpen = false;
                    }

                    double newX = _assistiveTouchPosition.dx + details.delta.dx;
                    double newY = _assistiveTouchPosition.dy + details.delta.dy;
                    
                    // Mencegah bubble keluar dari batas layar
                    newX = newX.clamp(0.0, screenSize.width - 60.0);
                    newY = newY.clamp(0.0, screenSize.height - 120.0);
                    
                    _assistiveTouchPosition = Offset(newX, newY);
                  });
                },
                onTap: () {
                  setState(() {
                    _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    // Ubah warna bubble menjadi lebih hijau saat ditekan/menu terbuka
                    color: _isAssistiveMenuOpen ? _accent.withOpacity(0.15) : Colors.black.withOpacity(0.6),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _isAssistiveMenuOpen ? _accent : _accent.withOpacity(0.4),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _isAssistiveMenuOpen ? _accent.withOpacity(0.5) : Colors.black.withOpacity(0.5),
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        // Menggunakan icon dari assets
                        child: AssetService.image(
                          'logo.png', 
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // 8. --- NAVIGATION BAR MENGAMBANG BARU ---
            _buildFloatingNavBar(),
          ],
        ),
      ),
    );
  }


  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _videoController?.play();
    } else if (state == AppLifecycleState.paused) {
      _videoController?.pause();
    }
  }

  // Resume video tiap kali loader page kembali ke foreground (setelah Navigator.push page lain)
  void _resumeVideoIfNeeded() {
    if (_videoController != null && _videoController!.value.isInitialized) {
      _videoController!.play();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _overlayEntry?.remove();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    _animeScrollTimer?.cancel();
    _animePageController.dispose();
    _videoController?.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}

/// Widget Media (gambar/video dengan audio)
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(1.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return Center(
            child: CircularProgressIndicator(color: Colors.white)); // Gray
      }
    } else {
      return AssetService.image(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.black26),
      );
    }
  }
}