import 'config_service.dart';
import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'splash.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool _obscurePassword = true;

  late AnimationController _entryController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  VideoPlayerController? _videoCtrl;
  bool _isVideoReady = false;

  static const _bg       = Color(0xFF0C0C0E);
  static const _surface  = Color(0xFF141416);
  static const _surface2 = Color(0xFF1C1C1F);
  static const _border   = Color(0xFF2A2A2E);
  static const _textMain = Color(0xFFECECF0);
  static const _muted    = Color(0xFF606068);

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _entryController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic));

    Future.delayed(const Duration(milliseconds: 300), () => _initVideo());
  }

  Future<void> _initVideo() async {
    try {
      final path = await AssetService.videoPath('splash.mp4');
      final file = File(path);
      if (!file.existsSync()) return;
      _videoCtrl = VideoPlayerController.file(
        file,
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
      );
      await _videoCtrl!.initialize();
      _videoCtrl!.setLooping(true);
      _videoCtrl!.setVolume(0.0);
      await _videoCtrl!.play();
      if (mounted) setState(() => _isVideoReady = true);
    } catch (_) {}
  }

  @override
  void dispose() {
    _entryController.dispose();
    _videoCtrl?.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  Future<void> _logoutAndClearSession() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('sessionKey') ?? '';
      String androidId = await _getAndroidId();
      if (sessionKey.isNotEmpty) {
        await http.post(
          Uri.parse("${ConfigService.baseUrl}/logout"),
          body: {"key": sessionKey, "androidId": androidId},
        ).timeout(const Duration(seconds: 5));
      }
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) _showToast('Session dibersihkan. Silakan login ulang.');
  }

  Future<String> _getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) return (await deviceInfo.androidInfo).id;
      if (Platform.isIOS) return (await deviceInfo.iosInfo).identifierForVendor ?? 'ios_unknown';
    } catch (_) {}
    return 'device_unknown';
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    // Pastikan ConfigService sudah init
    await ConfigService.init();

    setState(() => isLoading = true);
    try {
      String androidId = await _getAndroidId();

      final response = await http.post(
        Uri.parse("${ConfigService.baseUrl}/validate"),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          "username": userController.text.trim(),
          "password": passController.text.trim(),
          "androidId": androidId,
        },
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(response.body);

      if (data['singleSession'] == true) {
        if (!mounted) return;
        setState(() => isLoading = false);
        _showSingleSessionDialog(message: data['message'] ?? 'Akun sedang digunakan di device lain.');
        return;
      }

      if (data['maintenance'] == true) {
        if (!mounted) return;
        setState(() => isLoading = false);
        _showMaintenanceDialog(data['message'] ?? 'Server sedang maintenance.');
        return;
      }

      if (data['valid'] == true) {
        if (!mounted) return;

        final listBug = data['listBug'] != null
            ? List<Map<String, dynamic>>.from((data['listBug'] as List).map((e) => Map<String, dynamic>.from(e)))
            : <Map<String, dynamic>>[];
        final listDoos = data['listDoos'] != null
            ? List<Map<String, dynamic>>.from((data['listDoos'] as List).map((e) => Map<String, dynamic>.from(e)))
            : <Map<String, dynamic>>[];
        final news = data['news'] != null
            ? List<Map<String, dynamic>>.from((data['news'] as List).map((e) => Map<String, dynamic>.from(e)))
            : <Map<String, dynamic>>[];
        final String role = data['role'] ?? 'member';
        final String expiredDate = data['expiredDate'] ?? '';

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', userController.text.trim());
        await prefs.setString('password', passController.text.trim());
        await prefs.setString('role', role);
        await prefs.setString('sessionKey', data['key'] ?? '');
        await prefs.setString('expiredDate', expiredDate);
        await prefs.setString('listBug', jsonEncode(data['listBug'] ?? []));
        await prefs.setString('listDoos', jsonEncode(data['listDoos'] ?? []));
        await prefs.setString('news', jsonEncode(data['news'] ?? []));
        await prefs.setBool('isLoggedIn', true);
        await prefs.setString('androidId', androidId);

        try {
          final fcmToken = await FirebaseMessaging.instance.getToken();
          if (fcmToken != null && fcmToken.isNotEmpty) {
            await http.post(
              Uri.parse("${ConfigService.baseUrl}/api/fcm/token"),
              body: {"key": data['key'] ?? '', "fcmToken": fcmToken},
            ).timeout(const Duration(seconds: 5));
          }
        } catch (_) {}

        if (role == 'member' && expiredDate.isNotEmpty && mounted) {
          final exp = DateTime.tryParse(expiredDate);
          final sisa = exp != null ? exp.difference(DateTime.now()).inDays : 0;
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            backgroundColor: sisa <= 3 ? const Color(0xFFE05252) : const Color(0xFFE09B52),
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 4),
            content: Text(
              sisa <= 0 ? 'Akun expired! Hubungi admin.' : 'Sisa $sisa hari.',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ));
        }

        if (mounted) {
          setState(() => isLoading = false);
          Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (_) => _LoginIntroOverlay(
              nextPage: SplashScreen(
                username: userController.text.trim(),
                password: passController.text.trim(),
                role: role,
                sessionKey: data['key'] ?? '',
                expiredDate: expiredDate,
                listBug: listBug,
                listDoos: listDoos,
                news: news,
              ),
            ),
          ));
        }
      } else if (data['reason'] == 'device_mismatch' || data['reason'] == 'device') {
        setState(() => isLoading = false);
        _showSingleSessionDialog(message: data['message'] ?? 'Akun ini sudah login di perangkat lain.');
      } else {
        setState(() => isLoading = false);
        _showToast('Username atau password salah.');
      }
    } on TimeoutException {
      setState(() => isLoading = false);
      _showToast('Koneksi timeout. Coba lagi.');
    } on SocketException catch (e) {
      setState(() => isLoading = false);
      _showToast('Gagal terhubung: ${e.message}');
    } catch (e) {
      setState(() => isLoading = false);
      _showToast('Error: ${e.runtimeType} - ${e.toString().length > 60 ? e.toString().substring(0, 60) : e.toString()}');
    } finally {
      if (mounted && isLoading) setState(() => isLoading = false);
    }
  }

  void _showSingleSessionDialog({required String message}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: _surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE05252).withOpacity(0.5), width: 1),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 32)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: const Color(0xFFE05252).withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE05252).withOpacity(0.3)),
              ),
              child: const Icon(Icons.warning_amber_rounded, color: Color(0xFFE05252), size: 22),
            ),
            const SizedBox(height: 16),
            const Text('Akun Sedang Aktif',
                style: TextStyle(color: _textMain, fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _muted, fontSize: 13, height: 1.6)),
            const SizedBox(height: 24),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    await _logoutAndClearSession();
                  },
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFFE05252), width: 1),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text('Logout & Reset',
                      style: TextStyle(color: Color(0xFFE05252), fontWeight: FontWeight.w600, fontSize: 13)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _textMain,
                    foregroundColor: _bg,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    elevation: 0,
                  ),
                  child: const Text('Mengerti', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _showMaintenanceDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black87,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _border, width: 1),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 32)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Icon
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                color: const Color(0xFFF87171).withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFF87171).withOpacity(0.3), width: 1.5),
              ),
              child: const Center(child: Text('🔧', style: TextStyle(fontSize: 26))),
            ),
            const SizedBox(height: 14),
            const Text('Server Maintenance',
                style: TextStyle(color: _textMain, fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text('Mohon maaf atas ketidaknyamanannya 🙏',
                textAlign: TextAlign.center,
                style: TextStyle(color: _muted, fontSize: 11)),
            const SizedBox(height: 14),
            // Alasan dari server
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFF87171).withOpacity(0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFF87171).withOpacity(0.2)),
              ),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('📋 ', style: TextStyle(fontSize: 13)),
                Expanded(
                  child: Text(message,
                      style: const TextStyle(
                          color: _textMain, fontSize: 13, height: 1.6)),
                ),
              ]),
            ),
            const SizedBox(height: 16),
            const Text('Hubungi admin untuk info lebih lanjut:',
                style: TextStyle(color: _muted, fontSize: 11)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _openUrl('https://wa.me/6283187785936'),
                  icon: Image.asset('assets/whatsapp.png', width: 16, height: 16),
                  label: const Text('WhatsApp',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                          color: Color(0xFF25D366))),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFF25D366), width: 1),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _openUrl('https://t.me/gacha_789bot'),
                  icon: Image.asset('assets/telegram.png', width: 16, height: 16),
                  label: const Text('Telegram',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                          color: Color(0xFF229ED9))),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFF229ED9), width: 1),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity, height: 42,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _textMain,
                  foregroundColor: _bg,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                ),
                child: const Text('Mengerti', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _showToast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: const Color(0xFF191010),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: const BorderSide(color: Color(0x55E05252), width: 1),
      ),
      duration: const Duration(seconds: 5),
      content: Text(
        message,
        style: const TextStyle(color: Color(0xFFE8A0A0), fontSize: 13, fontWeight: FontWeight.w500),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // Video background
          if (_isVideoReady && _videoCtrl != null)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl!.value.size.width,
                  height: _videoCtrl!.value.size.height,
                  child: VideoPlayer(_videoCtrl!),
                ),
              ),
            ),
          // Overlay gelap tipis
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(_isVideoReady ? 0.45 : 1.0),
            ),
          ),
          // Konten login
          FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildHeader(),
                      const SizedBox(height: 28),
                      _buildCard(),
                      const SizedBox(height: 20),
                      GestureDetector(
                        onTap: () {},
                        child: RichText(
                          text: const TextSpan(
                            style: TextStyle(fontSize: 12, color: _muted),
                            children: [
                              TextSpan(text: 'Butuh bantuan? '),
                              TextSpan(
                                text: 'Hubungi admin',
                                style: TextStyle(color: _textMain, fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width: 56, height: 56,
          decoration: BoxDecoration(
            color: _surface2,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _border, width: 1),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(13),
            child: AssetService.image('logo.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.shield_outlined, color: _muted, size: 26),
            ),
          ),
        ),
        const SizedBox(height: 14),
        const Text('TRICKSTER X AREA',
            textAlign: TextAlign.center,
            style: TextStyle(color: _textMain, fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: 2)),
        const SizedBox(height: 4),
        const Text('Masuk untuk melanjutkan',
            textAlign: TextAlign.center,
            style: TextStyle(color: _muted, fontSize: 13, fontWeight: FontWeight.w400)),
      ],
    );
  }

  Widget _buildCard() {
    return Container(
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border, width: 1),
      ),
      padding: const EdgeInsets.all(24),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _FieldLabel(label: 'Username'),
            const SizedBox(height: 6),
            _InputField(
              controller: userController,
              hint: 'Masukkan username',
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Username tidak boleh kosong.' : null,
            ),
            const SizedBox(height: 14),
            _FieldLabel(label: 'Password'),
            const SizedBox(height: 6),
            _InputField(
              controller: passController,
              hint: 'Masukkan password',
              obscure: _obscurePassword,
              onToggleObscure: () => setState(() => _obscurePassword = !_obscurePassword),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Password tidak boleh kosong.' : null,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Divider(color: _border, height: 1),
            ),
            _LoginButton(isLoading: isLoading, onPressed: login),
          ],
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String label;
  const _FieldLabel({required this.label});
  @override
  Widget build(BuildContext context) => Text(
        label,
        style: const TextStyle(color: Color(0xFF606068), fontSize: 12, fontWeight: FontWeight.w500, letterSpacing: 0.2),
      );
}

class _InputField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _InputField({
    required this.controller,
    required this.hint,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_InputField> createState() => _InputFieldState();
}

class _InputFieldState extends State<_InputField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      obscureText: widget.obscure,
      style: const TextStyle(color: Color(0xFFECECF0), fontSize: 14, fontWeight: FontWeight.w400),
      cursorColor: const Color(0xFF505058),
      decoration: InputDecoration(
        hintText: widget.hint,
        hintStyle: const TextStyle(color: Color(0xFF606068), fontSize: 14),
        filled: true,
        fillColor: const Color(0xFF0C0C0E),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF2A2A2E), width: 1)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF2A2A2E), width: 1)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF505058), width: 1)),
        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFE05252), width: 1)),
        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFE05252), width: 1)),
        errorStyle: const TextStyle(color: Color(0xFFE05252), fontSize: 11, fontWeight: FontWeight.w400),
        suffixIcon: widget.onToggleObscure != null
            ? IconButton(
                icon: Icon(widget.obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 17, color: const Color(0xFF606068)),
                onPressed: widget.onToggleObscure,
              )
            : null,
      ),
      validator: widget.validator,
    );
  }
}

class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onPressed;
  const _LoginButton({required this.isLoading, required this.onPressed});
  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginIntroOverlay extends StatefulWidget {
  final Widget nextPage;
  const _LoginIntroOverlay({required this.nextPage});

  @override
  State<_LoginIntroOverlay> createState() => _LoginIntroOverlayState();
}

class _LoginIntroOverlayState extends State<_LoginIntroOverlay> {
  static const _bg = Color(0xFF0C0C0E);

  static const List<String> _lines = [
    'Berhasil anda login apakah anda udah siapp..',
    'Apk terbaik TRICKSTER X AREA rating terbagus 2026..',
    'video tutorial sender di menu bug udh ada video tonton aja ya simak...',
    'Developer Terbaik OmZillxy silence Founder Dwarriors apakah anda sudah tau cara pasang sender...?',
  ];

  int _currentLine = 0;
  String _displayedText = '';
  bool _doneTyping = false;
  Timer? _typeTimer;

  @override
  void initState() {
    super.initState();
    _typeLine();
  }

  void _typeLine() {
    final line = _lines[_currentLine];
    int charIndex = 0;
    _displayedText = '';
    _doneTyping = false;
    _typeTimer = Timer.periodic(const Duration(milliseconds: 35), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      charIndex++;
      setState(() => _displayedText = line.substring(0, charIndex));
      if (charIndex >= line.length) {
        timer.cancel();
        setState(() => _doneTyping = true);
      }
    });
  }

  void _onTapLanjut() {
    if (!_doneTyping) return;
    if (_currentLine < _lines.length - 1) {
      setState(() => _currentLine++);
      _typeLine();
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => widget.nextPage),
      );
    }
  }

  @override
  void dispose() {
    _typeTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isLastLine = _currentLine == _lines.length - 1;
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                textAlign: TextAlign.left,
                text: TextSpan(
                  style: const TextStyle(
                    color: Color(0xFFFF3B3B),
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    height: 1.7,
                    fontFamily: 'monospace',
                    shadows: [
                      Shadow(color: Color(0x66FF3B3B), blurRadius: 6),
                    ],
                  ),
                  children: [
                    const TextSpan(
                      text: '> ',
                      style: TextStyle(color: Color(0xFF8A2424)),
                    ),
                    TextSpan(text: _displayedText),
                    if (!_doneTyping)
                      TextSpan(
                        text: '_',
                        style: TextStyle(color: const Color(0xFFFF3B3B).withOpacity(0.85)),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 250),
                opacity: _doneTyping ? 1.0 : 0.0,
                child: IgnorePointer(
                  ignoring: !_doneTyping,
                  child: GestureDetector(
                    onTap: _onTapLanjut,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFFF3B3B).withOpacity(0.6), width: 1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        isLastLine ? 'Mengerti' : 'Lanjut',
                        style: const TextStyle(
                          color: Color(0xFFFF3B3B),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LoginButtonState extends State<_LoginButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        if (!widget.isLoading) widget.onPressed();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 100),
        opacity: _pressed ? 0.75 : 1.0,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          transform: Matrix4.identity()..scale(_pressed ? 0.985 : 1.0),
          transformAlignment: Alignment.center,
          height: 44,
          width: double.infinity,
          decoration: BoxDecoration(
            color: widget.isLoading ? const Color(0xFFECECF0).withOpacity(0.5) : const Color(0xFFECECF0),
            borderRadius: BorderRadius.circular(10),
          ),
          child: widget.isLoading
              ? const Center(child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF0C0C0E)))))
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.login_rounded, size: 16, color: Color(0xFF0C0C0E)),
                    SizedBox(width: 8),
                    Text('Masuk', style: TextStyle(color: Color(0xFF0C0C0E), fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: -0.1)),
                  ],
                ),
        ),
      ),
    );
  }
}
