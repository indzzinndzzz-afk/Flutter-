import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'config_service.dart';
import 'theme_provider.dart';

// ─────────────────────────────────────────────
// MODEL
// ─────────────────────────────────────────────
class StoryItem {
  final String id;
  final String username;
  final String role;
  final String? photoUrl;
  final String type; // photo | video | text
  final String? mediaUrl;
  final String caption;
  final int timestamp;
  final int expiresAt;
  bool isViewed;
  bool isLiked;
  int viewCount;
  int likeCount;

  StoryItem({
    required this.id,
    required this.username,
    required this.role,
    this.photoUrl,
    required this.type,
    this.mediaUrl,
    required this.caption,
    required this.timestamp,
    required this.expiresAt,
    this.isViewed = false,
    this.isLiked = false,
    this.viewCount = 0,
    this.likeCount = 0,
  });

  factory StoryItem.fromJson(Map<String, dynamic> j) => StoryItem(
        id: j['id'] ?? '',
        username: j['username'] ?? '',
        role: j['role'] ?? 'member',
        photoUrl: j['photoUrl'],
        type: j['type'] ?? 'photo',
        mediaUrl: j['mediaUrl'],
        caption: j['caption'] ?? '',
        timestamp: j['timestamp'] ?? 0,
        expiresAt: j['expiresAt'] ?? 0,
        isViewed: j['isViewed'] == true,
        isLiked: j['isLiked'] == true,
        viewCount: j['viewCount'] ?? 0,
        likeCount: j['likeCount'] ?? 0,
      );
}

class StoryGroup {
  final String username;
  final String role;
  final String? photoUrl;
  bool hasUnread;
  List<StoryItem> stories;

  StoryGroup({
    required this.username,
    required this.role,
    this.photoUrl,
    required this.hasUnread,
    required this.stories,
  });

  factory StoryGroup.fromJson(Map<String, dynamic> j) => StoryGroup(
        username: j['username'] ?? '',
        role: j['role'] ?? 'member',
        photoUrl: j['photoUrl'],
        hasUnread: j['hasUnread'] == true,
        stories: (j['stories'] as List? ?? [])
            .map((e) => StoryItem.fromJson(e))
            .toList(),
      );
}

// ─────────────────────────────────────────────
// THEME HELPER
// ─────────────────────────────────────────────
class _T {
  final Color primary;
  final Color accent;
  final bool dark;
  const _T({required this.primary, required this.accent, required this.dark});
  Color get bg => dark ? const Color(0xFF060D18) : const Color(0xFFEEF2F7);
  Color get card => dark ? const Color(0xFF0D1B2A) : Colors.white;
  Color get textPrimary => dark ? Colors.white : const Color(0xFF0D1B2A);
  Color get textSub => dark ? Colors.white.withAlpha(102) : Colors.black.withAlpha(102);
  factory _T.of(BuildContext context) {
    final tp = Provider.of<ThemeProvider>(context, listen: true);
    return _T(primary: tp.primaryColor, accent: tp.accentColor, dark: tp.isDarkMode);
  }
}

// ─────────────────────────────────────────────
// HALAMAN STORY LIST
// ─────────────────────────────────────────────
class StoryListPage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String role;

  const StoryListPage({
    super.key,
    required this.sessionKey,
    required this.myUsername,
    required this.role,
  });

  @override
  State<StoryListPage> createState() => _StoryListPageState();
}

class _StoryListPageState extends State<StoryListPage> {
  List<StoryGroup> _groups = [];
  bool _loading = true;
  String? _myPhotoUrl;

  @override
  void initState() {
    super.initState();
    _fetchStories();
    _fetchMyPhoto();
  }

  Future<void> _fetchMyPhoto() async {
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/getProfile'),
        headers: {'x-session-key': widget.sessionKey},
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final url = data['photoUrl'];
        if (url != null && url.toString().isNotEmpty && mounted) {
          setState(() => _myPhotoUrl = url.toString());
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchStories() async {
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/getStories'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _groups = (data['stories'] as List? ?? [])
              .map((e) => StoryGroup.fromJson(e))
              .toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _T.of(context);
    final myGroup = _groups.where((g) => g.username == widget.myUsername).toList();
    final otherGroups = _groups.where((g) => g.username != widget.myUsername).toList();

    return Scaffold(
      backgroundColor: t.bg,
      appBar: AppBar(
        backgroundColor: t.card,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: t.accent, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Story',
          style: TextStyle(
            color: t.textPrimary,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: t.accent),
            onPressed: _fetchStories,
          ),
        ],
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: t.primary))
          : RefreshIndicator(
              color: t.primary,
              onRefresh: _fetchStories,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Story saya
                  Text(
                    'Story Saya',
                    style: TextStyle(
                      color: t.textSub,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildMyStoryCard(context, t, myGroup.isNotEmpty ? myGroup.first : null),
                  const SizedBox(height: 24),
                  if (otherGroups.isNotEmpty) ...[
                    Text(
                      'Story Terbaru',
                      style: TextStyle(
                        color: t.textSub,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ...otherGroups.map((g) => _buildStoryTile(context, g, t)),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _buildMyStoryCard(BuildContext ctx, _T t, StoryGroup? myGroup) {
    return GestureDetector(
      onTap: myGroup != null
          ? () => _openStoryViewer(ctx, myGroup, 0)
          : () => _showAddStorySheet(ctx, t),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: t.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: t.primary.withAlpha(50)),
        ),
        child: Row(
          children: [
            Stack(
              children: [
                _buildAvatar(widget.myUsername, _myPhotoUrl ?? (myGroup != null && myGroup.stories.isNotEmpty ? myGroup.stories.first.photoUrl : null), 28, t, ring: myGroup != null && myGroup.stories.isNotEmpty),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: GestureDetector(
                    onTap: () => _showAddStorySheet(ctx, t),
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: t.primary,
                        shape: BoxShape.circle,
                        border: Border.all(color: t.card, width: 2),
                      ),
                      child: const Icon(Icons.add, color: Colors.white, size: 12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Story Saya',
                    style: TextStyle(
                      color: t.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    myGroup != null
                        ? '${myGroup.stories.length} story aktif'
                        : 'Ketuk + untuk tambah story',
                    style: TextStyle(color: t.textSub, fontSize: 12),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: t.textSub),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryTile(BuildContext ctx, StoryGroup group, _T t) {
    return GestureDetector(
      onTap: () => _openStoryViewer(ctx, group, 0),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: t.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: group.hasUnread ? t.primary.withAlpha(120) : t.primary.withAlpha(30),
          ),
        ),
        child: Row(
          children: [
            _buildAvatar(group.username, group.photoUrl, 26, t, ring: group.hasUnread, read: !group.hasUnread),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    group.username,
                    style: TextStyle(
                      color: t.textPrimary,
                      fontWeight: group.hasUnread ? FontWeight.bold : FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    '${group.stories.length} story',
                    style: TextStyle(color: t.textSub, fontSize: 12),
                  ),
                ],
              ),
            ),
            if (group.hasUnread)
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: t.primary, shape: BoxShape.circle),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatar(String username, String? photoUrl, double radius, _T t,
      {bool ring = false, bool read = false}) {
    final ringColor = read ? Colors.grey : t.primary;
    return Container(
      padding: ring ? const EdgeInsets.all(2.5) : EdgeInsets.zero,
      decoration: ring
          ? BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: read
                    ? [Colors.grey, Colors.grey.shade400]
                    : [t.primary, t.accent],
              ),
            )
          : null,
      child: CircleAvatar(
        radius: radius,
        backgroundColor: t.primary.withAlpha(40),
        backgroundImage: photoUrl != null ? NetworkImage(photoUrl) : null,
        child: photoUrl == null
            ? Text(
                username.isNotEmpty ? username[0].toUpperCase() : '?',
                style: TextStyle(
                  color: t.primary,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  fontSize: radius * 0.7,
                ),
              )
            : null,
      ),
    );
  }

  void _openStoryViewer(BuildContext ctx, StoryGroup group, int startIndex) {
    Navigator.push(
      ctx,
      MaterialPageRoute(
        builder: (_) => StoryViewerPage(
          group: group,
          startIndex: startIndex,
          sessionKey: widget.sessionKey,
          myUsername: widget.myUsername,
          onDone: _fetchStories,
        ),
      ),
    );
  }

  void _showAddStorySheet(BuildContext ctx, _T t) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _AddStorySheet(
        sessionKey: widget.sessionKey,
        onUploaded: _fetchStories,
        t: t,
      ),
    );
  }
}

// ─────────────────────────────────────────────
// BOTTOM SHEET TAMBAH STORY
// ─────────────────────────────────────────────
class _AddStorySheet extends StatefulWidget {
  final String sessionKey;
  final VoidCallback onUploaded;
  final _T t;
  const _AddStorySheet({required this.sessionKey, required this.onUploaded, required this.t});

  @override
  State<_AddStorySheet> createState() => _AddStorySheetState();
}

class _AddStorySheetState extends State<_AddStorySheet> {
  final _captionCtrl = TextEditingController();
  bool _loading = false;
  File? _selectedFile;
  String _type = 'text'; // text | photo | video

  @override
  void dispose() {
    _captionCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickMedia(ImageSource source, {bool isVideo = false}) async {
    final picker = ImagePicker();
    XFile? file;
    if (isVideo) {
      file = await picker.pickVideo(source: source);
      setState(() => _type = 'video');
    } else {
      file = await picker.pickImage(source: source, imageQuality: 80);
      setState(() => _type = 'photo');
    }
    if (file != null) setState(() => _selectedFile = File(file!.path));
  }

  Future<void> _upload() async {
    if (_type != 'text' && _selectedFile == null) return;
    if (_type == 'text' && _captionCtrl.text.trim().isEmpty) return;

    setState(() => _loading = true);
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('${ConfigService.baseUrl}/uploadStory'),
      );
      request.headers['x-session-key'] = widget.sessionKey;
      request.fields['caption'] = _captionCtrl.text.trim();
      request.fields['type'] = _type;

      if (_selectedFile != null) {
        final mimeType = _type == 'video' ? 'video/mp4' : 'image/jpeg';
        request.files.add(await http.MultipartFile.fromPath(
          'media',
          _selectedFile!.path,
          contentType: MediaType.parse(mimeType),
        ));
      }

      final res = await request.send().timeout(const Duration(seconds: 30));
      final body = await res.stream.bytesToString();
      final data = jsonDecode(body);

      if (mounted) {
        Navigator.pop(context);
        if (data['valid'] == true) {
          widget.onUploaded();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Story berhasil diposting!'),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: t.textSub,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Buat Story',
            style: TextStyle(
              color: t.textPrimary,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 20),

          // Preview file
          if (_selectedFile != null)
            Container(
              height: 120,
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                image: _type == 'photo'
                    ? DecorationImage(
                        image: FileImage(_selectedFile!),
                        fit: BoxFit.cover,
                      )
                    : null,
                color: _type == 'video' ? Colors.black : null,
              ),
              child: _type == 'video'
                  ? const Center(child: Icon(Icons.videocam_rounded, color: Colors.white, size: 40))
                  : null,
            ),

          // Pilih tipe
          Row(
            children: [
              _typeBtn(Icons.text_fields_rounded, 'Teks', 'text', t),
              const SizedBox(width: 8),
              _typeBtn(Icons.photo_camera_rounded, 'Foto', 'photo', t),
              const SizedBox(width: 8),
              _typeBtn(Icons.videocam_rounded, 'Video', 'video', t),
            ],
          ),
          const SizedBox(height: 12),

          // Caption
          TextField(
            controller: _captionCtrl,
            style: TextStyle(color: t.textPrimary),
            maxLines: 3,
            decoration: InputDecoration(
              hintText: _type == 'text' ? 'Tulis sesuatu...' : 'Tambah caption (opsional)',
              hintStyle: TextStyle(color: t.textSub),
              filled: true,
              fillColor: t.bg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: t.primary.withAlpha(60)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: t.primary.withAlpha(40)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: t.primary),
              ),
            ),
          ),
          const SizedBox(height: 16),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: t.primary,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _loading ? null : _upload,
              child: _loading
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Text(
                      'Posting Story',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _typeBtn(IconData icon, String label, String value, _T t) {
    final selected = _type == value;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _type = value;
            if (value == 'text') _selectedFile = null;
          });
          if (value == 'photo') _pickMedia(ImageSource.gallery);
          if (value == 'video') _pickMedia(ImageSource.gallery, isVideo: true);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? t.primary.withAlpha(40) : t.bg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: selected ? t.primary : t.primary.withAlpha(40),
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: selected ? t.primary : t.textSub, size: 20),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(
                color: selected ? t.primary : t.textSub,
                fontSize: 11,
              )),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// STORY VIEWER (tampilan penuh mirip WA/IG)
// ─────────────────────────────────────────────
class StoryViewerPage extends StatefulWidget {
  final StoryGroup group;
  final int startIndex;
  final String sessionKey;
  final String myUsername;
  final VoidCallback onDone;

  const StoryViewerPage({
    super.key,
    required this.group,
    required this.startIndex,
    required this.sessionKey,
    required this.myUsername,
    required this.onDone,
  });

  @override
  State<StoryViewerPage> createState() => _StoryViewerPageState();
}

class _StoryViewerPageState extends State<StoryViewerPage> with SingleTickerProviderStateMixin {
  late int _currentIndex;
  late AnimationController _progressCtrl;
  VideoPlayerController? _videoCtrl;
  bool _videoReady = false;
  bool _paused = false;

  // Cache video controllers supaya ga re-load tiap navigate
  final Map<String, VideoPlayerController> _videoCache = {};

  static const _storyDuration = Duration(seconds: 5);

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.startIndex;
    _progressCtrl = AnimationController(vsync: this, duration: _storyDuration)
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) _nextStory();
      });
    _preloadAll();
    _loadStory();
  }

  // Pre-cache semua story biar ga loading lagi waktu navigate
  Future<void> _preloadAll() async {
    for (final story in widget.group.stories) {
      if (story.type == 'video' && story.mediaUrl != null) {
        if (!_videoCache.containsKey(story.mediaUrl)) {
          final ctrl = VideoPlayerController.networkUrl(Uri.parse(story.mediaUrl!));
          await ctrl.initialize();
          await ctrl.setVolume(1.0);
          _videoCache[story.mediaUrl!] = ctrl;
        }
      } else if (story.type == 'photo' && story.mediaUrl != null) {
        // Pre-cache image ke memory Flutter
        if (mounted) {
          precacheImage(NetworkImage(story.mediaUrl!), context);
        }
      }
    }
  }

  @override
  void dispose() {
    _progressCtrl.dispose();
    for (final ctrl in _videoCache.values) {
      ctrl.dispose();
    }
    _videoCache.clear();
    super.dispose();
  }

  StoryItem get _current => widget.group.stories[_currentIndex];

  // Request audio focus ke Android biar suara mau keluar
  Future<void> _activateAudio() async {
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration(
        avAudioSessionCategory: AVAudioSessionCategory.playback,
        avAudioSessionCategoryOptions: AVAudioSessionCategoryOptions.defaultToSpeaker,
        avAudioSessionMode: AVAudioSessionMode.moviePlayback,
        androidAudioAttributes: AndroidAudioAttributes(
          contentType: AndroidAudioContentType.movie,
          usage: AndroidAudioUsage.media,
        ),
        androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
      ));
      await session.setActive(true);
    } catch (_) {}
  }

  Future<void> _loadStory() async {
    _videoCtrl = null;
    _videoReady = false;

    // Mark sebagai viewed
    _markViewed(_current.id);

    if (_current.type == 'video' && _current.mediaUrl != null) {
      // Pakai dari cache kalau udah ada
      if (_videoCache.containsKey(_current.mediaUrl)) {
        final cached = _videoCache[_current.mediaUrl!]!;
        await cached.seekTo(Duration.zero);
        await cached.setVolume(1.0);
        if (mounted) {
          setState(() {
            _videoCtrl = cached;
            _videoReady = true;
          });
          _progressCtrl.duration = cached.value.duration;
          await _activateAudio();
          cached.play();
          _progressCtrl.forward(from: 0);
        }
      } else {
        // Belum ada di cache, init sekarang
        final ctrl = VideoPlayerController.networkUrl(Uri.parse(_current.mediaUrl!));
        await ctrl.initialize();
        await ctrl.setVolume(1.0);
        _videoCache[_current.mediaUrl!] = ctrl;
        if (mounted) {
          setState(() {
            _videoCtrl = ctrl;
            _videoReady = true;
          });
          _progressCtrl.duration = ctrl.value.duration;
          await _activateAudio();
          ctrl.play();
          _progressCtrl.forward(from: 0);
        }
      }
    } else {
      _progressCtrl.duration = _storyDuration;
      if (mounted) {
        setState(() {});
        _progressCtrl.forward(from: 0);
      }
    }
  }

  Future<void> _markViewed(String storyId) async {
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/viewStory'),
        headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
        body: jsonEncode({'storyId': storyId}),
      );
    } catch (_) {}
  }

  Future<void> _toggleLike() async {
    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/likeStory'),
        headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
        body: jsonEncode({'storyId': _current.id}),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _current.isLiked = data['liked'] == true;
          _current.likeCount += _current.isLiked ? 1 : -1;
        });
      }
    } catch (_) {}
  }

  Future<void> _deleteStory() async {
    if (_current.username != widget.myUsername) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Story?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (confirm != true) return;

    await http.post(
      Uri.parse('${ConfigService.baseUrl}/deleteStory'),
      headers: {'x-session-key': widget.sessionKey, 'Content-Type': 'application/json'},
      body: jsonEncode({'storyId': _current.id}),
    );

    if (mounted) {
      widget.onDone();
      Navigator.pop(context);
    }
  }

  void _nextStory() {
    if (_currentIndex < widget.group.stories.length - 1) {
      setState(() => _currentIndex++);
      _loadStory();
    } else {
      widget.onDone();
      if (mounted) Navigator.pop(context);
    }
  }

  void _prevStory() {
    if (_currentIndex > 0) {
      setState(() => _currentIndex--);
      _loadStory();
    }
  }

  void _pauseResume() {
    setState(() => _paused = !_paused);
    if (_paused) {
      _progressCtrl.stop();
      _videoCtrl?.pause();
    } else {
      _progressCtrl.forward();
      _videoCtrl?.play();
    }
  }

  String _timeAgo(int ts) {
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ts));
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
    if (diff.inHours < 24) return '${diff.inHours}j lalu';
    return '${diff.inDays}h lalu';
  }

  @override
  Widget build(BuildContext context) {
    final story = _current;
    final isOwn = story.username == widget.myUsername;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.globalPosition.dx < w / 3) _prevStory();
          else if (d.globalPosition.dx > w * 2 / 3) _nextStory();
          else _pauseResume();
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ─── MEDIA ───────────────────────────────────
            _buildMedia(story),

            // ─── GRADIENT OVERLAY ─────────────────────────
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withAlpha(120),
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withAlpha(160),
                  ],
                  stops: const [0, 0.3, 0.7, 1],
                ),
              ),
            ),

            // ─── PROGRESS BAR ─────────────────────────────
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 8,
              right: 8,
              child: Row(
                children: List.generate(widget.group.stories.length, (i) {
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: LinearProgressIndicator(
                        value: i < _currentIndex
                            ? 1
                            : i == _currentIndex
                                ? _progressCtrl.value
                                : 0,
                        backgroundColor: Colors.white.withAlpha(60),
                        valueColor: const AlwaysStoppedAnimation(Colors.white),
                        minHeight: 2.5,
                      ),
                    ),
                  );
                }),
              ),
            ),

            // ─── HEADER ───────────────────────────────────
            Positioned(
              top: MediaQuery.of(context).padding.top + 20,
              left: 12,
              right: 12,
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundImage: story.photoUrl != null ? NetworkImage(story.photoUrl!) : null,
                    backgroundColor: Colors.white24,
                    child: story.photoUrl == null
                        ? Text(story.username[0].toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))
                        : null,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          story.username,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          _timeAgo(story.timestamp),
                          style: TextStyle(color: Colors.white.withAlpha(180), fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () { widget.onDone(); Navigator.pop(context); },
                  ),
                  if (isOwn)
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, color: Colors.white),
                      onPressed: _deleteStory,
                    ),
                ],
              ),
            ),

            // ─── CAPTION + ACTIONS ────────────────────────
            Positioned(
              bottom: MediaQuery.of(context).padding.bottom + 20,
              left: 16,
              right: 16,
              child: Column(
                children: [
                  if (story.caption.isNotEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.black.withAlpha(120),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        story.caption,
                        style: const TextStyle(color: Colors.white, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Like
                      GestureDetector(
                        onTap: _toggleLike,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.black.withAlpha(100),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                story.isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                color: story.isLiked ? Colors.redAccent : Colors.white,
                                size: 20,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                '${story.likeCount}',
                                style: const TextStyle(color: Colors.white, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Views
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withAlpha(100),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.visibility_rounded, color: Colors.white70, size: 18),
                            const SizedBox(width: 6),
                            Text(
                              '${story.viewCount}',
                              style: const TextStyle(color: Colors.white70, fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMedia(StoryItem story) {
    if (story.type == 'video') {
      if (_videoReady && _videoCtrl != null) {
        return Center(
          child: AspectRatio(
            aspectRatio: _videoCtrl!.value.aspectRatio,
            child: VideoPlayer(_videoCtrl!),
          ),
        );
      }
      return const Center(child: CircularProgressIndicator(color: Colors.white));
    }

    if (story.type == 'photo' && story.mediaUrl != null) {
      return Image.network(
        story.mediaUrl!,
        fit: BoxFit.contain,
        // Sudah pre-cached, langsung tampil tanpa loading
      );
    }

    // Text story
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [const Color(0xFF0D1B2A), const Color(0xFF1a0533)],
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            story.caption,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
