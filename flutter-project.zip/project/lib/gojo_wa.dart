import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'config_service.dart';
import 'theme_provider.dart';

class TRICKSTERWaPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const TRICKSTERWaPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<TRICKSTERWaPage> createState() => _TRICKSTERWaPageState();
}

class _TRICKSTERWaPageState extends State<TRICKSTERWaPage>
    with SingleTickerProviderStateMixin {
  final _numberController = TextEditingController();

  bool _isLoading = false;
  bool _loadingStatus = false;
  String? _pairingCode;
  String? _errorMessage;
  String? _pairedNumber;
  List<dynamic> _activeConnections = [];
  int _totalSessions = 0;
  int _onlineSessions = 0;

  // SC Sessions
  List<dynamic> _scSessions = [];
  int _totalSc = 0;
  int _onlineSc = 0;
  bool _loadingScStatus = false;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // Role yang boleh akses
  static const List<String> _allowedRoles = [
    'owner',
    'vip',
    'reseller',
    'member_permanen',
  ];

  bool get _hasAccess => _allowedRoles.contains(widget.role);

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    if (_hasAccess) {
      _fetchStatus();
      _fetchScStatus();
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _showTutorImageDialog());
  }

  void _showTutorImageDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 360),
          decoration: BoxDecoration(
            color: const Color(0xFF0D1B2A),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFF25D366).withOpacity(0.4), width: 1.2),
            boxShadow: [BoxShadow(color: const Color(0xFF25D366).withOpacity(0.15), blurRadius: 28)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFF25D366).withOpacity(0.08),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                  border: Border(bottom: BorderSide(color: const Color(0xFF25D366).withOpacity(0.2))),
                ),
                child: Row(children: [
                  const Icon(Icons.info_outline_rounded, color: Color(0xFF25D366), size: 18),
                  const SizedBox(width: 10),
                  const Text('INFO', style: TextStyle(
                    color: Colors.white, fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 2,
                  )),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: const Icon(Icons.close_rounded, color: Colors.white54, size: 20),
                  ),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF25D366).withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF25D366).withOpacity(0.15)),
                  ),
                  child: const Text(
                    'WHATSAPP TRICKSTER\n\nKETIKA MAU HUBUNGIN DEVELOPER CARI AJA MIWACHAN\n\nKONTAK NY ADA KENDALA LANGSUNG AJA CHAT KONTAK MIWACHAN BISA CHATAN SESAMA MEMBER',
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Outfit',
                      fontSize: 13,
                      height: 1.6,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: TextButton.styleFrom(
                      backgroundColor: const Color(0xFF25D366).withOpacity(0.12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: const Text('Mengerti', style: TextStyle(
                      color: Color(0xFF25D366), fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700, fontSize: 13,
                    )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _numberController.dispose();
    super.dispose();
  }

  // ─── Fetch status koneksi aktif ──────────────────────────────────────────
  Future<void> _fetchStatus() async {
    setState(() => _loadingStatus = true);
    try {
      final res = await http
          .get(Uri.parse(
              '${ConfigService.baseUrl}/getActiveWa?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() {
          _activeConnections = List<dynamic>.from(data['sessions'] ?? []);
          _totalSessions = data['total'] ?? 0;
          _onlineSessions = data['online'] ?? 0;
        });
      }
    } catch (_) {}
    setState(() => _loadingStatus = false);
  }

  // ─── Fetch status SC (TRICKSTERwa) ─────────────────────────────────────────────
  Future<void> _fetchScStatus() async {
    setState(() => _loadingScStatus = true);
    try {
      final res = await http
          .get(Uri.parse(
              '${ConfigService.baseUrl}/getActiveSc?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() {
          _scSessions = List<dynamic>.from(data['sessions'] ?? []);
          _totalSc = data['total'] ?? 0;
          _onlineSc = data['online'] ?? 0;
        });
      }
    } catch (_) {}
    setState(() => _loadingScStatus = false);
  }

  // ─── Request pairing code ─────────────────────────────────────────────────
  Future<void> _requestPairing() async {
    final number = _numberController.text.trim().replaceAll(RegExp(r'\D'), '');

    if (number.isEmpty) {
      _showSnack('Masukkan nomor WA terlebih dahulu', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
      _pairingCode = null;
      _errorMessage = null;
      _pairedNumber = null;
    });

    try {
      final res = await http
          .get(Uri.parse(
              '${ConfigService.baseUrl}/getPairingTRICKSTERwa?key=${widget.sessionKey}&number=$number'))
          .timeout(const Duration(seconds: 25));
      final data = jsonDecode(res.body);

      if (data['valid'] == true && data['pairingCode'] != null) {
        setState(() {
          _pairingCode = data['pairingCode'];
          _pairedNumber = number;
          _errorMessage = null;
        });
        await _fetchStatus();
      } else {
        setState(() {
          _errorMessage = data['message'] ?? 'Gagal mendapatkan pairing code';
        });
      }
    } catch (_) {
      setState(() {
        _errorMessage = 'Gagal terhubung ke server. Coba lagi.';
      });
    }

    setState(() => _isLoading = false);
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: GoogleFonts.outfit(color: Colors.white)),
      backgroundColor: isError ? Colors.redAccent : Colors.green,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  void _copyCode() {
    if (_pairingCode == null) return;
    Clipboard.setData(ClipboardData(text: _pairingCode!));
    _showSnack('Kode berhasil disalin ✓');
  }

  // ─── Build TextField ─────────────────────────────────────────────────────
  Widget _buildTextField(Color accentColor) {
    return TextField(
      controller: _numberController,
      keyboardType: TextInputType.phone,
      style: GoogleFonts.outfit(color: Colors.white, fontSize: 16),
      decoration: InputDecoration(
        labelText: 'Nomor WhatsApp',
        hintText: 'Nomor WhatsApp',
        hintStyle: GoogleFonts.outfit(color: Colors.white30),
        labelStyle: GoogleFonts.outfit(color: accentColor),
        prefixIcon:
            Icon(FontAwesomeIcons.whatsapp, color: accentColor, size: 20),
        filled: true,
        fillColor: Colors.white.withOpacity(0.07),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.white12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: accentColor, width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      ),
    );
  }

  // ─── Glass Card ──────────────────────────────────────────────────────────
  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required Color accentColor,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.07),
            Colors.white.withOpacity(0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accentColor.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(
            color: accentColor.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [accentColor, accentColor.withOpacity(0.5)]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                      color: accentColor.withOpacity(0.3), blurRadius: 8),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: GoogleFonts.orbitron(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ]),
          const SizedBox(height: 18),
          ...children,
        ],
      ),
    );
  }

  // ─── Pairing Code Box ────────────────────────────────────────────────────
  Widget _buildCodeBox(Color accentColor) {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (_, __) => Transform.scale(
        scale: _pulseAnimation.value,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                accentColor.withOpacity(0.2),
                accentColor.withOpacity(0.05),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border:
                Border.all(color: accentColor.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: accentColor.withOpacity(0.25),
                  blurRadius: 20,
                  spreadRadius: 2),
            ],
          ),
          child: Column(children: [
            Text(
              'KODE PAIRING',
              style: GoogleFonts.orbitron(
                color: accentColor,
                fontSize: 11,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              _pairingCode ?? '',
              style: GoogleFonts.orbitron(
                color: Colors.white,
                fontSize: 32,
                fontWeight: FontWeight.bold,
                letterSpacing: 6,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '📱 ${_pairedNumber ?? ''}',
              style:
                  GoogleFonts.outfit(color: Colors.white54, fontSize: 13),
            ),
            const SizedBox(height: 18),
            GestureDetector(
              onTap: _copyCode,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentColor.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.copy_rounded, color: accentColor, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      'Salin Kode',
                      style: GoogleFonts.outfit(
                          color: accentColor,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: Colors.amber.withOpacity(0.3)),
              ),
              child: Text(
                '⚠️  Buka WhatsApp → Perangkat Tertaut → Tautkan dengan nomor telepon → Masukkan kode ini',
                textAlign: TextAlign.center,
                style: GoogleFonts.outfit(
                    color: Colors.amber.shade200,
                    fontSize: 12,
                    height: 1.5),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ─── Status Tile ─────────────────────────────────────────────────────────
  Widget _buildStatusTile(dynamic conn, Color accentColor) {
    final number = conn['number']?.toString() ?? '';
    final isOnline = conn['online'] == true;
    final statusColor = isOnline ? Colors.greenAccent : Colors.redAccent;
    final statusText = isOnline ? 'ONLINE' : 'OFFLINE';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: statusColor.withOpacity(0.2)),
      ),
      child: Row(children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: statusColor,
            shape: BoxShape.circle,
            boxShadow: isOnline
                ? [BoxShadow(color: statusColor.withOpacity(0.5), blurRadius: 6)]
                : null,
          ),
        ),
        const SizedBox(width: 12),
        Icon(FontAwesomeIcons.whatsapp, color: statusColor, size: 16),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            number,
            style: GoogleFonts.outfit(color: Colors.white, fontSize: 14),
          ),
        ),
        Text(
          statusText,
          style: GoogleFonts.orbitron(
              color: statusColor, fontSize: 10, letterSpacing: 1),
        ),
      ]),
    );
  }

  // ─── SC Session Tile ─────────────────────────────────────────────────────
  Future<void> _deleteScSession(String number) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Hapus Sesi',
            style: GoogleFonts.orbitron(color: Colors.white, fontSize: 14)),
        content: Text('Hapus sesi $number dari TRICKSTERwa?',
            style: GoogleFonts.outfit(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Batal',
                style: GoogleFonts.outfit(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Hapus',
                style: GoogleFonts.outfit(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    try {
      final res = await http.delete(Uri.parse(
          '${ConfigService.baseUrl}/hapusSesiSc?key=${widget.sessionKey}&number=$number'));
      final data = jsonDecode(res.body);
      _showSnack(
        data['message'] ?? 'Sesi dihapus',
        isError: data['valid'] == false,
      );
      await _fetchScStatus();
    } catch (_) {
      _showSnack('Gagal hapus sesi', isError: true);
    }
  }

  Widget _buildScSessionTile(dynamic conn) {
    final number = conn['number']?.toString() ?? '';
    final isOnline = conn['online'] == true;
    final statusColor = isOnline ? Colors.greenAccent : Colors.redAccent;
    final statusText = isOnline ? 'ONLINE' : 'OFFLINE';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.purpleAccent.withOpacity(0.2)),
      ),
      child: Row(children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: statusColor,
            shape: BoxShape.circle,
            boxShadow: isOnline
                ? [BoxShadow(color: statusColor.withOpacity(0.5), blurRadius: 6)]
                : null,
          ),
        ),
        const SizedBox(width: 12),
        Icon(FontAwesomeIcons.robot, color: Colors.purpleAccent, size: 16),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            number,
            style: GoogleFonts.outfit(color: Colors.white, fontSize: 14),
          ),
        ),
        Text(
          statusText,
          style: GoogleFonts.orbitron(
              color: statusColor, fontSize: 10, letterSpacing: 1),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _deleteScSession(number),
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
            ),
            child: const Icon(Icons.delete_outline_rounded,
                color: Colors.redAccent, size: 14),
          ),
        ),
      ]),
    );
  }

  // ─── Summary Item ────────────────────────────────────────────────────────
  Widget _buildSummaryItem(String label, String value, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: GoogleFonts.orbitron(
              color: color, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: GoogleFonts.outfit(color: Colors.white38, fontSize: 11),
        ),
      ],
    );
  }

  // ─── Access Denied View ──────────────────────────────────────────────────
  Widget _buildAccessDenied(Color accentColor) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(
                    color: Colors.redAccent.withOpacity(0.4), width: 2),
              ),
              child: const Icon(Icons.lock_outline_rounded,
                  color: Colors.redAccent, size: 52),
            ),
            const SizedBox(height: 28),
            Text(
              'AKSES DITOLAK',
              style: GoogleFonts.orbitron(
                color: Colors.redAccent,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'Fitur ini hanya untuk:\nOwner  •  VIP  •  Reseller  •  Member Permanen',
              textAlign: TextAlign.center,
              style: GoogleFonts.outfit(
                  color: Colors.white54, fontSize: 14, height: 1.7),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: Colors.redAccent.withOpacity(0.3)),
              ),
              child: Text(
                'Role kamu: ${widget.role.toUpperCase()}',
                style: GoogleFonts.orbitron(
                    color: Colors.redAccent.withOpacity(0.8),
                    fontSize: 12,
                    letterSpacing: 1),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Main Build ───────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final accentColor = theme.accentColor;
    final primaryColor = theme.primaryColor;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          Icon(FontAwesomeIcons.whatsapp, color: accentColor, size: 20),
          const SizedBox(width: 10),
          Text(
            'TRICKSTER WA',
            style: GoogleFonts.orbitron(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ]),
        actions: [
          if (_hasAccess)
            IconButton(
              icon: (_loadingStatus || _loadingScStatus)
                  ? SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          color: accentColor, strokeWidth: 2),
                    )
                  : Icon(Icons.refresh_rounded, color: accentColor),
              onPressed: (_loadingStatus || _loadingScStatus)
                  ? null
                  : () {
                      _fetchStatus();
                      _fetchScStatus();
                    },
              tooltip: 'Refresh',
            ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.2,
            colors: [
              primaryColor.withOpacity(0.15),
              Colors.black,
            ],
          ),
        ),
        child: !_hasAccess
            ? _buildAccessDenied(accentColor)
            : SafeArea(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // ── Card: Input & Pairing ──────────────────────────
                      _buildGlassCard(
                        title: 'PAIR NOMOR WA',
                        icon: FontAwesomeIcons.link,
                        accentColor: accentColor,
                        children: [
                          _buildTextField(accentColor),
                          const SizedBox(height: 14),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed:
                                  _isLoading ? null : _requestPairing,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accentColor,
                                foregroundColor: Colors.white,
                                disabledBackgroundColor:
                                    accentColor.withOpacity(0.4),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.circular(14),
                                ),
                                elevation: 6,
                                shadowColor:
                                    accentColor.withOpacity(0.4),
                              ),
                              child: _isLoading
                                  ? const SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2.5),
                                    )
                                  : Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const Icon(
                                            Icons.qr_code_rounded,
                                            size: 18),
                                        const SizedBox(width: 8),
                                        Text(
                                          'Generate Pairing Code',
                                          style: GoogleFonts.outfit(
                                            fontSize: 15,
                                            fontWeight:
                                                FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                            ),
                          ),

                          // ── Error Message ──────────────────────────
                          if (_errorMessage != null) ...[
                            const SizedBox(height: 14),
                            Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.red.withOpacity(0.1),
                                borderRadius:
                                    BorderRadius.circular(12),
                                border: Border.all(
                                    color: Colors.redAccent
                                        .withOpacity(0.4)),
                              ),
                              child: Row(children: [
                                const Icon(
                                    Icons.error_outline_rounded,
                                    color: Colors.redAccent,
                                    size: 18),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    _errorMessage!,
                                    style: GoogleFonts.outfit(
                                        color: Colors.redAccent,
                                        fontSize: 13),
                                  ),
                                ),
                              ]),
                            ),
                          ],

                          // ── Pairing Code Result ────────────────────
                          if (_pairingCode != null) ...[
                            const SizedBox(height: 18),
                            _buildCodeBox(accentColor),
                          ],
                        ],
                      ),

                      // ── Card: Status Koneksi ───────────────────────
                      _buildGlassCard(
                        title: 'STATUS KONEKSI WA',
                        icon: FontAwesomeIcons.plugCircleCheck,
                        accentColor: accentColor,
                        children: [
                          if (_loadingStatus)
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: CircularProgressIndicator(
                                    color: accentColor, strokeWidth: 2),
                              ),
                            )
                          else ...[ 
                            // ── Summary Bar ────────────────────────
                            if (_activeConnections.isNotEmpty) ...[
                              Container(
                                margin: const EdgeInsets.only(bottom: 14),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.04),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: accentColor.withOpacity(0.15)),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    _buildSummaryItem(
                                        'TOTAL', '$_totalSessions',
                                        Colors.white70),
                                    Container(
                                        width: 1,
                                        height: 28,
                                        color: Colors.white12),
                                    _buildSummaryItem(
                                        'ONLINE', '$_onlineSessions',
                                        Colors.greenAccent),
                                    Container(
                                        width: 1,
                                        height: 28,
                                        color: Colors.white12),
                                    _buildSummaryItem(
                                        'OFFLINE',
                                        '${_totalSessions - _onlineSessions}',
                                        Colors.redAccent),
                                  ],
                                ),
                              ),
                            ],
                            if (_activeConnections.isEmpty)
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 16),
                                  child: Column(children: [
                                    const Icon(FontAwesomeIcons.whatsapp,
                                        color: Colors.white24, size: 32),
                                    const SizedBox(height: 10),
                                    Text(
                                      'Belum ada nomor yang terhubung',
                                      style: GoogleFonts.outfit(
                                          color: Colors.white38,
                                          fontSize: 13),
                                    ),
                                  ]),
                                ),
                              )
                            else
                              ..._activeConnections
                                  .map((c) =>
                                      _buildStatusTile(c, accentColor))
                                  .toList(),
                          ],
                        ],
                      ),

                      // ── Card: Status Sesi SC (TRICKSTERWA) ─────────────
                      _buildGlassCard(
                        title: 'STATUS SESI SC (TRICKSTERWA)',
                        icon: FontAwesomeIcons.robot,
                        accentColor: Colors.purpleAccent,
                        children: [
                          if (_loadingScStatus)
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: CircularProgressIndicator(
                                    color: Colors.purpleAccent, strokeWidth: 2),
                              ),
                            )
                          else ...[
                            if (_scSessions.isNotEmpty) ...[
                              Container(
                                margin: const EdgeInsets.only(bottom: 14),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.04),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: Colors.purpleAccent.withOpacity(0.15)),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    _buildSummaryItem(
                                        'TOTAL', '$_totalSc',
                                        Colors.white70),
                                    Container(
                                        width: 1,
                                        height: 28,
                                        color: Colors.white12),
                                    _buildSummaryItem(
                                        'ONLINE', '$_onlineSc',
                                        Colors.greenAccent),
                                    Container(
                                        width: 1,
                                        height: 28,
                                        color: Colors.white12),
                                    _buildSummaryItem(
                                        'OFFLINE',
                                        '${_totalSc - _onlineSc}',
                                        Colors.redAccent),
                                  ],
                                ),
                              ),
                            ],
                            if (_scSessions.isEmpty)
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 16),
                                  child: Column(children: [
                                    const Icon(FontAwesomeIcons.robot,
                                        color: Colors.white24, size: 32),
                                    const SizedBox(height: 10),
                                    Text(
                                      'Belum ada sesi SC yang terhubung',
                                      style: GoogleFonts.outfit(
                                          color: Colors.white38,
                                          fontSize: 13),
                                    ),
                                  ]),
                                ),
                              )
                            else
                              ..._scSessions
                                  .map((c) => _buildScSessionTile(c))
                                  .toList(),
                          ],
                        ],
                      ),

                      // ── Info Role ──────────────────────────────────
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: accentColor.withOpacity(0.07),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: accentColor.withOpacity(0.2)),
                        ),
                        child: Row(children: [
                          Icon(Icons.verified_user_rounded,
                              color: accentColor, size: 16),
                          const SizedBox(width: 10),
                          Text(
                            'Login sebagai: ',
                            style: GoogleFonts.outfit(
                                color: Colors.white54, fontSize: 13),
                          ),
                          Expanded(
                            child: Text(
                              '${widget.username} (${widget.role.toUpperCase()})',
                              style: GoogleFonts.outfit(
                                color: accentColor,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
