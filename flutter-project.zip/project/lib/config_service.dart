import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ConfigService {
  static const String _configUrl =
      'https://raw.githubusercontent.com/alwaysZillxy/databasetrrrrr/refs/heads/main/config.json';

  static const String _fallback = '';

  static String _baseUrl = _fallback;
  static String get baseUrl => _baseUrl;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();

    // Coba fetch GitHub — 3x retry
    for (int i = 0; i < 3; i++) {
      try {
        final res = await http.get(
          Uri.parse('$_configUrl?t=${DateTime.now().millisecondsSinceEpoch}'),
          headers: {'Cache-Control': 'no-cache', 'Pragma': 'no-cache'},
        ).timeout(const Duration(seconds: 6));

        if (res.statusCode == 200) {
          final body = res.body.trim();
          final data = jsonDecode(body);
          final url = (data['base_url'] as String?)?.trim().replaceAll(RegExp(r'/$'), '');
          if (url != null && url.isNotEmpty) {
            _baseUrl = url;
            await prefs.setString('cached_base_url', _baseUrl);
            print('[Config] ✅ Dari GitHub: $_baseUrl');
            return;
          }
        }
      } catch (e) {
        print('[Config] ⚠️ Retry ${i + 1}/3 gagal: $e');
        await Future.delayed(const Duration(seconds: 1));
      }
    }

    // Semua retry gagal — pakai cache
    final cached = prefs.getString('cached_base_url') ?? '';
    if (cached.isNotEmpty) {
      _baseUrl = cached;
      print('[Config] 🔄 Pakai cache: $_baseUrl');
    } else {
      _baseUrl = _fallback;
      print('[Config] 🔁 Pakai fallback: $_baseUrl');
    }
  }

  static Future<void> setConfigUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    final clean = url.trim().replaceAll(RegExp(r'/$'), '');
    await prefs.setString('cached_base_url', clean);
    _baseUrl = clean;
    print('[Config] 📝 Manual set: $_baseUrl');
  }

  static Future<void> refresh() async => await init();

  static Future<void> resetToDefault() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('cached_base_url');
    _baseUrl = _fallback;
    await init();
  }
}
