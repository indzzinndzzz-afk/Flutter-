import 'config_service.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'dart:io';
import 'asset_service.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'theme_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

// ── Announcement helper ──
class _AnnouncementService {
  static Future<String> fetch() async {
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/announcement'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return (data['text'] as String?)?.trim() ?? 'Tidak ada pengumuman.';
      }
    } catch (_) {}
    return 'Gagal memuat pengumuman.';
  }
}

class _T {
  final Color primary;
  final Color accent;
  final bool dark;
  final Color? bgOverride;
  final Color? cardOverride;
  final Color? cardAltOverride;

  const _T({
    required this.primary,
    required this.accent,
    required this.dark,
    this.bgOverride,
    this.cardOverride,
    this.cardAltOverride,
  });

  Color get bg      => bgOverride      ?? (dark ? const Color(0xFF060D18) : const Color(0xFFEEF2F7));
  Color get card    => cardOverride    ?? (dark ? const Color(0xFF0D1B2A) : Colors.white);
  Color get cardAlt => cardAltOverride ?? (dark ? const Color(0xFF0A1520) : const Color(0xFFF8FAFC));
  Color get border       => primary.withAlpha((dark ? 0.18 : 0.12).round());
  Color get borderBright => primary.withAlpha((dark ? 0.45 : 0.35).round());
  Color get textPrimary  => dark ? Colors.white : const Color(0xFF0D1B2A);
  Color get textSub      => dark ? Colors.white.withAlpha((0.4 * 255).round()) : Colors.black.withAlpha((0.4 * 255).round());
  Color get divider      => dark ? Colors.white.withAlpha((0.06 * 255).round()) : Colors.black.withAlpha((0.06 * 255).round());

  factory _T.of(BuildContext context) {
    final tp = Provider.of<ThemeProvider>(context, listen: false);
    final dt = tp.activeDashTheme;
    return _T(
      primary:        dt.primary,
      accent:         dt.accent,
      dark:           tp.isDarkMode,
      bgOverride:     dt.bg,
      cardOverride:   dt.card,
      cardAltOverride: dt.cardAlt,
    );
  }
}

// ── Bug Dropdown ──
class _BugDropdown extends StatelessWidget {
  final List<Map<String, dynamic>> listBug;
  final String? selectedId;
  final _T t;
  final ValueChanged<String?> onChanged;

  const _BugDropdown({
    super.key,
    required this.listBug,
    required this.selectedId,
    required this.t,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    if (listBug.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: t.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: t.border),
        ),
        child: Text('Tidak ada bug tersedia', style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 13)),
      );
    }

    return SizedBox(
      height: 100,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: listBug.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final bug = listBug[i];
          final isSelected = selectedId == bug['bug_id'];
          final isGroup = bug['bug_id'] == 'group' || bug['bug_id'] == 'groupband';

          return GestureDetector(
            onTap: () => onChanged(bug['bug_id']),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOutCubic,
              width: 130,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: isSelected
                    ? t.primary.withAlpha((0.13 * 255).round())
                    : t.cardAlt,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isSelected
                      ? t.primary.withAlpha((0.7 * 255).round())
                      : t.border,
                  width: isSelected ? 1.5 : 1,
                ),
                boxShadow: isSelected
                    ? [BoxShadow(color: t.primary.withAlpha((0.18 * 255).round()), blurRadius: 12, spreadRadius: 1)]
                    : [],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: (isSelected ? t.primary : t.accent).withAlpha((0.15 * 255).round()),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Image.asset('assets/whatsapp.png', width: 14, height: 14),
                      ),
                      if (isSelected)
                        Icon(Icons.check_circle_rounded, color: t.primary, size: 14),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    bug['bug_name'] ?? '',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: isSelected ? t.textPrimary : t.textSub,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      letterSpacing: 0.2,
                    ),
                  ),
                  if (isGroup)
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: Colors.greenAccent.withAlpha((0.15 * 255).round()),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: Colors.greenAccent.withAlpha((0.4 * 255).round()), width: 1),
                      ),
                      child: const Text(
                        'GRUP',
                        style: TextStyle(
                          color: Colors.greenAccent,
                          fontFamily: 'ShareTechMono',
                          fontSize: 7,
                          letterSpacing: 0.8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Bug SwipeDown (Dropdown Style) ──
class _BugSwipeDown extends StatefulWidget {
  final List<Map<String, dynamic>> listBug;
  final String? selectedId;
  final _T t;
  final ValueChanged<String?> onChanged;

  const _BugSwipeDown({
    super.key,
    required this.listBug,
    required this.selectedId,
    required this.t,
    required this.onChanged,
  });

  @override
  State<_BugSwipeDown> createState() => _BugSwipeDownState();
}

class _BugSwipeDownState extends State<_BugSwipeDown> with SingleTickerProviderStateMixin {
  bool _isOpen = false;
  late AnimationController _anim;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 250));
    _fadeAnim = CurvedAnimation(parent: _anim, curve: Curves.easeOut);
    _scaleAnim = Tween<double>(begin: 0.95, end: 1.0).animate(CurvedAnimation(parent: _anim, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _isOpen = !_isOpen);
    if (_isOpen) _anim.forward(); else _anim.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    final selected = widget.listBug.firstWhere(
      (b) => b['bug_id'] == widget.selectedId,
      orElse: () => {},
    );
    final hasSelected = selected.isNotEmpty;
    final isGroup = selected['bug_id'] == 'group' || selected['bug_id'] == 'groupband';

    if (widget.listBug.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: t.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: t.border),
        ),
        child: Text('Tidak ada bug tersedia', style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 13)),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Trigger button
        GestureDetector(
          onTap: _toggle,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: hasSelected
                  ? t.primary.withAlpha((0.08 * 255).round())
                  : t.cardAlt,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: hasSelected
                    ? t.primary.withAlpha((0.55 * 255).round())
                    : _isOpen ? t.accent.withAlpha((0.4 * 255).round()) : t.border,
                width: hasSelected || _isOpen ? 1.5 : 1,
              ),
              boxShadow: hasSelected
                  ? [BoxShadow(color: t.primary.withAlpha((0.15 * 255).round()), blurRadius: 12)]
                  : [],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: (hasSelected ? t.primary : t.accent).withAlpha((0.12 * 255).round()),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Image.asset('assets/whatsapp.png', width: 16, height: 16),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: hasSelected
                      ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(
                            selected['bug_name'] ?? '',
                            style: TextStyle(color: t.textPrimary, fontFamily: 'ShareTechMono', fontSize: 13, fontWeight: FontWeight.bold),
                          ),
                          if (isGroup)
                            Container(
                              margin: const EdgeInsets.only(top: 3),
                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                              decoration: BoxDecoration(
                                color: Colors.greenAccent.withAlpha((0.15 * 255).round()),
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(color: Colors.greenAccent.withAlpha((0.4 * 255).round())),
                              ),
                              child: const Text('GRUP', style: TextStyle(color: Colors.greenAccent, fontFamily: 'ShareTechMono', fontSize: 8, letterSpacing: 0.8, fontWeight: FontWeight.bold)),
                            ),
                        ])
                      : Text('Tap untuk pilih bug...', style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 13)),
                ),
                AnimatedRotation(
                  turns: _isOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: Icon(Icons.keyboard_arrow_down_rounded, color: t.textSub, size: 20),
                ),
              ],
            ),
          ),
        ),

        // Dropdown list
        AnimatedSize(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          child: _isOpen
              ? FadeTransition(
                  opacity: _fadeAnim,
                  child: ScaleTransition(
                    scale: _scaleAnim,
                    alignment: Alignment.topCenter,
                    child: Container(
                      margin: const EdgeInsets.only(top: 8),
                      decoration: BoxDecoration(
                        color: t.card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: t.borderBright),
                        boxShadow: [
                          BoxShadow(color: t.primary.withAlpha((0.12 * 255).round()), blurRadius: 18, spreadRadius: 1),
                          BoxShadow(color: Colors.black.withAlpha((t.dark ? 0.35 : 0.08).round()), blurRadius: 12, offset: const Offset(0, 4)),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Column(
                          children: widget.listBug.asMap().entries.map((entry) {
                            final i = entry.key;
                            final bug = entry.value;
                            final isSelected = widget.selectedId == bug['bug_id'];
                            final isGroup = bug['bug_id'] == 'group' || bug['bug_id'] == 'groupband';
                            final isLast = i == widget.listBug.length - 1;

                            return GestureDetector(
                              onTap: () {
                                widget.onChanged(bug['bug_id']);
                                _toggle();
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 180),
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? t.primary.withAlpha((0.1 * 255).round())
                                      : Colors.transparent,
                                  border: !isLast
                                      ? Border(bottom: BorderSide(color: t.divider, width: 0.7))
                                      : null,
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: (isSelected ? t.primary : t.accent).withAlpha((0.12 * 255).round()),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Image.asset('assets/whatsapp.png', width: 14, height: 14),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              bug['bug_name'] ?? '',
                                              style: TextStyle(
                                                color: isSelected ? t.textPrimary : t.textSub,
                                                fontFamily: 'ShareTechMono',
                                                fontSize: 12,
                                                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                              ),
                                            ),
                                          ),
                                          if (isGroup)
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                              decoration: BoxDecoration(
                                                color: Colors.greenAccent.withAlpha((0.15 * 255).round()),
                                                borderRadius: BorderRadius.circular(5),
                                                border: Border.all(color: Colors.greenAccent.withAlpha((0.4 * 255).round())),
                                              ),
                                              child: const Text('GRUP', style: TextStyle(color: Colors.greenAccent, fontFamily: 'ShareTechMono', fontSize: 7, letterSpacing: 0.8, fontWeight: FontWeight.bold)),
                                            ),
                                        ],
                                      ),
                                    ),
                                    if (isSelected)
                                      Icon(Icons.check_circle_rounded, color: t.primary, size: 16),
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ),
      ],
    );
  }
}

// ── Sender Mode Tab ──
class _SenderModeTab extends StatelessWidget {
  final bool isGlobal;
  final _T t;
  final ValueChanged<bool> onChanged;

  const _SenderModeTab({
    required this.isGlobal,
    required this.t,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: t.cardAlt,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: t.border, width: 1),
      ),
      child: Row(
        children: [
          _TabItem(
            label: 'PRIVATE',
            icon: Icons.lock_rounded,
            isActive: !isGlobal,
            color: t.primary,
            t: t,
            onTap: () => onChanged(false),
          ),
          _TabItem(
            label: 'GLOBAL',
            icon: Icons.public_rounded,
            isActive: isGlobal,
            color: const Color(0xFF00E5FF),
            t: t,
            onTap: () => onChanged(true),
          ),
        ],
      ),
    );
  }
}

class _TabItem extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isActive;
  final Color color;
  final _T t;
  final VoidCallback onTap;

  const _TabItem({
    required this.label,
    required this.icon,
    required this.isActive,
    required this.color,
    required this.t,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isActive ? color.withAlpha((0.13 * 255).round()) : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            border: isActive ? Border.all(color: color.withAlpha((0.45 * 255).round()), width: 1.2) : Border.all(color: Colors.transparent),
            boxShadow: isActive ? [BoxShadow(color: color.withAlpha((0.15 * 255).round()), blurRadius: 10)] : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isActive ? color : t.textSub, size: 14),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? color : t.textSub,
                  fontFamily: 'ShareTechMono',
                  fontSize: 11,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  letterSpacing: 1.5,
                ),
              ),
              if (isActive && label == 'GLOBAL') ...[
                const SizedBox(width: 5),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                  decoration: BoxDecoration(
                    color: color.withAlpha((0.2 * 255).round()),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'VIP',
                    style: TextStyle(
                      color: color,
                      fontFamily: 'ShareTechMono',
                      fontSize: 7,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ── HomePage ──
class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl    = TextEditingController();

  Map<String, dynamic>? _selectedGroup;
  List<Map<String, dynamic>> _groupList = [];
  bool _isLoadingGroups = false;

  late AnimationController _pulseCtrl;
  late AnimationController _shimmerCtrl;
  late AnimationController _entryCtrl;
  late AnimationController _breathCtrl;

  late Animation<double> _entryFade;
  late Animation<Offset> _entrySlide;

  String? _selectedBugId;
  String? _selectedSenderName;
  bool _isSending        = false;
  bool _isLoadingSender  = false;
  bool _isRefreshing     = false;

  bool _useGlobalSender = false;

  List<Map<String, dynamic>> _senderList = [];
  List<Map<String, dynamic>> _latestBugs = [];

  late VideoPlayerController _videoCtrl;
  ChewieController? _chewieCtrl;
  bool _videoReady = false;

  String? _androidId;

  List<Map<String, dynamic>> _activityLogs = [];
  bool _logLoading = false;
  int _unreadLog = 0;

  bool _isExpired = false;

  // ── Menu Style: 'card' or 'swipe' ──
  String _menuStyle = 'card';

  // ✅ FIX: Tambah groupband di sini
  bool get _isGroupBug => _selectedBugId == 'group' || _selectedBugId == 'groupband';
  bool get _canUseGlobalSender => widget.role == 'vip';
  
  List<String> get _bugsNoNeedSender => ['spamnotif', 'spambanjir'];
  bool get _isSelectedBugNoNeedSender => 
      _selectedBugId != null && _bugsNoNeedSender.contains(_selectedBugId);

  @override
  void initState() {
    super.initState();
    _pulseCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat(reverse: true);
    _shimmerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat();
    _breathCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat(reverse: true);
    _entryCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));
    _fetchLog();
    _checkExpired();

    _entryFade  = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _entrySlide = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));

    _entryCtrl.forward();
    _initVideo();
    _loadAndroidId();
    _loadMenuStyle();
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _refreshListBug();
      _showAutoAnnouncement();
    });
  }

  void _showTutorVideoDialog() {
    final t = _T.of(context);
    final videoFile = File(AssetService.videoPathSync('tutor.mp4'));
    if (!videoFile.existsSync()) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('File tutor.mp4 belum tersedia.', style: TextStyle(fontFamily: 'Outfit', fontSize: 12, color: Colors.white)),
        backgroundColor: t.accent, behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ));
      _videoCtrl.play();
      return;
    }
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _TutorVideoDialog(t: t, videoFile: videoFile),
    ).then((_) {
      if (mounted) {
        _videoCtrl.setVolume(1.0);
        _videoCtrl.play();
      }
    });
  }

  Future<void> _showAutoAnnouncement() async {
    final text = await _AnnouncementService.fetch();
    if (!mounted) return;
    final t = _T.of(context);
    _videoCtrl.pause();
    _videoCtrl.setVolume(0.0);
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 360),
          decoration: BoxDecoration(
            color: t.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: t.accent.withOpacity(0.35), width: 1.2),
            boxShadow: [BoxShadow(color: t.accent.withOpacity(0.15), blurRadius: 28, spreadRadius: 2)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                decoration: BoxDecoration(
                  color: t.accent.withOpacity(0.08),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                  border: Border(bottom: BorderSide(color: t.accent.withOpacity(0.2))),
                ),
                child: Row(children: [
                  Icon(Icons.article_rounded, color: t.accent, size: 18),
                  const SizedBox(width: 10),
                  Text('PENGUMUMAN', style: TextStyle(
                    color: t.textPrimary, fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 2,
                  )),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Icon(Icons.close_rounded, color: t.textSub, size: 20),
                  ),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: t.accent.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: t.accent.withOpacity(0.15)),
                  ),
                  child: Text(
                    text,
                    style: TextStyle(
                      color: t.textPrimary,
                      fontFamily: 'Outfit',
                      fontSize: 13,
                      height: 1.6,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Future.delayed(const Duration(milliseconds: 300), () {
                        if (mounted) _showTutorVideoDialog();
                      });
                    },
                    style: TextButton.styleFrom(
                      backgroundColor: t.accent.withOpacity(0.12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text('Lanjut ▶', style: TextStyle(
                      color: t.accent, fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700, fontSize: 13,
                    )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _checkExpired() {
    try {
      if (widget.expiredDate.isEmpty) return;
      final exp = DateTime.tryParse(widget.expiredDate);
      if (exp == null) return;
      final today = DateTime.now();
      final expEnd = DateTime(exp.year, exp.month, exp.day, 23, 59, 59);
      if (today.isAfter(expEnd)) {
        setState(() => _isExpired = true);
      }
    } catch (_) {}
  }

  Future<void> _loadAndroidId() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _androidId = prefs.getString('androidId') ?? '';
    });
  }

  Future<void> _loadMenuStyle() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('menuStyle') ?? 'card';
    if (mounted) setState(() => _menuStyle = saved);
  }

  Future<void> _saveMenuStyle(String style) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('menuStyle', style);
  }

  Future<void> _refreshListBug() async {
    if (_androidId == null || _androidId!.isEmpty) return;
    setState(() => _isRefreshing = true);
    try {
      final url = '${ConfigService.baseUrl}/myInfo'
          '?username=${widget.username}'
          '&password=${widget.password}'
          '&androidId=${_androidId}'
          '&key=${widget.sessionKey}';
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['listBug'] != null) {
          final newBugs = List<Map<String, dynamic>>.from(data['listBug']);
          if (mounted) {
            setState(() { _latestBugs = newBugs; });
          }
        }
      }
    } catch (e) {
      debugPrint('Error refreshing bug list: $e');
      if (_latestBugs.isEmpty && mounted) {
        setState(() { _latestBugs = List.from(widget.listBug); });
      }
    } finally {
      if (mounted) setState(() => _isRefreshing = false);
    }
  }

  void _initVideo() {
    final videoFile = File(AssetService.videoPathSync('banner.mp4'));
    if (!videoFile.existsSync()) {
      debugPrint('Video banner belum didownload');
      return;
    }
    _videoCtrl = VideoPlayerController.file(videoFile);
    _videoCtrl.initialize().then((_) {
      if (!mounted) return;
      setState(() {
        _videoCtrl.setVolume(1.0);
        _chewieCtrl = ChewieController(
          videoPlayerController: _videoCtrl,
          autoPlay: true, looping: true,
          showControls: false, autoInitialize: true,
        );
        _videoReady = true;
      });
    }).catchError((_) { if (mounted) setState(() => _videoReady = false); });
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _shimmerCtrl.dispose();
    _breathCtrl.dispose();
    _entryCtrl.dispose();
    _targetCtrl.dispose();
    _videoCtrl.dispose();
    _chewieCtrl?.dispose();
    super.dispose();
  }

  String _normalizePhone(String input) {
    String p = input.trim().replaceAll(RegExp(r'[^0-9+]'), '');
    if (p.startsWith('+'))  p = p.substring(1);
    if (p.startsWith('00')) p = p.substring(2);
    if (p.startsWith('0'))  p = '62${p.substring(1)}';
    return p;
  }

  Future<bool> _checkSenderAvailability() async {
    try {
      final endpoint = (_canUseGlobalSender && _useGlobalSender)
          ? '${ConfigService.baseUrl}/allMySenders?key=${widget.sessionKey}'
          : '${ConfigService.baseUrl}/mySender?key=${widget.sessionKey}';

      final res = await http.get(Uri.parse(endpoint)).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        Map<String, dynamic> data;
        try { data = jsonDecode(res.body); } catch (_) { return false; }
        if (data['valid'] == true) {
          final allSenders = List<Map<String, dynamic>>.from(data['connections'] ?? []);

          if (_canUseGlobalSender && _useGlobalSender) {
            _senderList = allSenders.where((s) {
              final id = (s['id'] ?? s['sessionName'] ?? '').toString();
              return s['isShared'] == true || id.startsWith('shared_');
            }).toList();
          } else {
            // Tampilkan semua sender (connected maupun tidak), biarkan user pilih
            _senderList = allSenders;
          }

          return _senderList.isNotEmpty;
        }
      }
      return false;
    } catch (e) {
      debugPrint('Error checking sender: $e');
      return false;
    }
  }

  Future<void> _fetchGroups() async {
    if (_isLoadingGroups) return;
    
    setState(() => _isLoadingGroups = true);
    try {
      final url = '${ConfigService.baseUrl}/api/groups?key=${widget.sessionKey}';
      debugPrint('[GROUPS] Fetching: $url');
      
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 20));
      debugPrint('[GROUPS] Status: ${res.statusCode}');
      debugPrint('[GROUPS] Body: ${res.body}');
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        
        if (data['success'] == true) {
          final senders = data['senders'] as List? ?? [];
          
          if (senders.isNotEmpty) {
            final firstSender = senders[0] as Map<String, dynamic>;
            final groups = firstSender['groups'] as List? ?? [];
            
            debugPrint('[GROUPS] Found ${groups.length} groups');
            
            setState(() {
              _groupList = List<Map<String, dynamic>>.from(groups.map((g) {
                return {
                  'jid': g['jid'] ?? '',
                  'name': g['name'] ?? 'Unknown',
                  'participants': g['participants'] ?? 0,
                };
              }));
            });
          } else {
            debugPrint('[GROUPS] No senders found');
            setState(() => _groupList = []);
          }
        } else {
          debugPrint('[GROUPS] Success false');
          setState(() => _groupList = []);
        }
      } else {
        debugPrint('[GROUPS] HTTP Error: ${res.statusCode}');
        setState(() => _groupList = []);
      }
    } catch (e, stack) {
      debugPrint('[GROUPS] Error: $e');
      debugPrint('[GROUPS] Stack: $stack');
      if (mounted) {
        setState(() => _groupList = []);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal mengambil grup: ${e.toString().substring(0, 100)}')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoadingGroups = false);
    }
  }

  Future<String?> _showSelectSenderDialog() {
    final t = _T.of(context);
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            backgroundColor: t.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: Row(
              children: [
                Icon(Icons.phone_android_rounded, color: t.accent, size: 28),
                const SizedBox(width: 12),
                Text('Pilih Sender', style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
              ],
            ),
            content: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_senderList.isEmpty)
                    Center(
                      child: Column(
                        children: [
                          Icon(Icons.smartphone, color: t.textSub, size: 48),
                          const SizedBox(height: 12),
                          Text('Belum ada sender tersedia', style: TextStyle(color: t.textSub)),
                        ],
                      ),
                    )
                  else
                    Column(
                      children: [
                        ..._senderList.map((sender) => Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          decoration: BoxDecoration(
                            color: t.cardAlt,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: t.border),
                          ),
                          child: ListTile(
                            leading: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: (sender['connected'] == true ? t.primary : t.textSub).withAlpha((0.1 * 255).round()),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                sender['connected'] == true ? Icons.check_circle : Icons.error_outline,
                                color: sender['connected'] == true ? t.primary : t.textSub,
                                size: 20,
                              ),
                            ),
                            title: Text(
                              sender['sessionName'] ?? 'Unknown',
                              style: TextStyle(color: t.textPrimary, fontFamily: 'ShareTechMono', fontSize: 14),
                            ),
                            subtitle: Text(
                              sender['connected'] == true ? '🟢 Online' : '🔴 Offline - Reconnecting...',
                              style: TextStyle(
                                color: sender['connected'] == true ? Colors.greenAccent : Colors.orangeAccent,
                                fontSize: 10,
                              ),
                            ),
                            trailing: Icon(Icons.chevron_right, color: sender['connected'] == true ? t.primary : Colors.orangeAccent),
                            onTap: () { Navigator.pop(context, sender['sessionName']); },
                          ),
                        )),
                      ],
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, null),
                child: Text('Batal', style: TextStyle(color: t.textSub)),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _showConfirmDialog(String target) async {
    final t = _T.of(context);
    final isGroup = _isGroupBug;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: t.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 28),
            const SizedBox(width: 12),
            Text('Konfirmasi', style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(isGroup ? 'Yakin ingin mengirim bug ke grup:' : 'Yakin ingin mengirim bug ke:',
                style: TextStyle(color: t.textSub)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: t.cardAlt, borderRadius: BorderRadius.circular(12), border: Border.all(color: t.border)),
              child: Row(
                children: [
                  Icon(isGroup ? Icons.group_rounded : Icons.phone_android_rounded,
                      color: isGroup ? Colors.greenAccent : t.primary, size: 16),
                  const SizedBox(width: 8),
                  Expanded(child: Text(target,
                      style: TextStyle(color: t.textPrimary, fontFamily: 'ShareTechMono', fontSize: 12),
                      overflow: TextOverflow.ellipsis, maxLines: 2)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text('⚠️ Gunakan dengan bijak!', style: TextStyle(color: Colors.orange, fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Batal', style: TextStyle(color: t.textSub)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: t.accent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text('Kirim', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      HapticFeedback.mediumImpact();
      await _sendBug();
    }
  }

  void _showGroupPickerDialog() async {
    final t = _T.of(context);
    
    await _fetchGroups();
    
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.75,
            decoration: BoxDecoration(
              color: t.card,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border.all(color: t.accent.withOpacity(0.2)),
            ),
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  width: 40, height: 4,
                  decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
                  child: Row(children: [
                    Icon(Icons.group_rounded, color: t.accent, size: 22),
                    const SizedBox(width: 10),
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('PILIH GRUP TARGET',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1)),
                      if (!_isLoadingGroups && _groupList.isNotEmpty)
                        Text('${_groupList.length} grup tersedia',
                          style: const TextStyle(color: Colors.white38, fontSize: 11)),
                    ]),
                    const Spacer(),
                    GestureDetector(
                      onTap: () async {
                        setSheet(() => _isLoadingGroups = true);
                        await _fetchGroups();
                        setSheet(() => _isLoadingGroups = false);
                      },
                      child: _isLoadingGroups
                          ? const SizedBox(width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white38))
                          : const Icon(Icons.refresh_rounded, color: Colors.white38, size: 22),
                    ),
                  ]),
                ),
                Divider(color: Colors.white12, height: 1),
                Expanded(
                  child: _isLoadingGroups
                      ? Center(child: CircularProgressIndicator(color: t.accent))
                      : _groupList.isEmpty
                          ? Center(
                              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                Icon(Icons.group_off_rounded, color: Colors.white24, size: 48),
                                const SizedBox(height: 12),
                                const Text('Tidak ada grup ditemukan', style: TextStyle(color: Colors.white38)),
                                const SizedBox(height: 6),
                                const Text('Pastikan sender sudah aktif', style: TextStyle(color: Colors.white24, fontSize: 12)),
                                const SizedBox(height: 12),
                                ElevatedButton.icon(
                                  onPressed: () async {
                                    setSheet(() => _isLoadingGroups = true);
                                    await _fetchGroups();
                                    setSheet(() => _isLoadingGroups = false);
                                  },
                                  icon: const Icon(Icons.refresh, size: 16),
                                  label: const Text('Refresh'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: t.accent,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                  ),
                                ),
                              ]),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.only(top: 8, bottom: 24),
                              itemCount: _groupList.length,
                              itemBuilder: (_, i) {
                                final g = _groupList[i];
                                final isSelected = _selectedGroup?['jid'] == g['jid'];
                                return GestureDetector(
                                  onTap: () {
                                    setState(() => _selectedGroup = g);
                                    Navigator.pop(ctx);
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                                    decoration: BoxDecoration(
                                      color: isSelected ? t.accent.withOpacity(0.13) : Colors.white.withOpacity(0.04),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(
                                        color: isSelected ? t.accent : Colors.white12,
                                        width: isSelected ? 1.5 : 1,
                                      ),
                                    ),
                                    child: Row(children: [
                                      Container(
                                        width: 38, height: 38,
                                        decoration: BoxDecoration(
                                          color: t.accent.withOpacity(0.1),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                          child: Text(
                                            (g['name'] as String? ?? '?').isNotEmpty
                                                ? (g['name'] as String)[0].toUpperCase()
                                                : '?',
                                            style: TextStyle(color: t.accent, fontWeight: FontWeight.bold, fontSize: 17),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                          Text(g['name'] ?? g['jid'],
                                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
                                            maxLines: 1, overflow: TextOverflow.ellipsis),
                                          Text('${g['participants'] ?? 0} anggota',
                                            style: const TextStyle(color: Colors.white38, fontSize: 11)),
                                        ]),
                                      ),
                                      if (isSelected)
                                        Icon(Icons.check_circle_rounded, color: t.accent, size: 18),
                                    ]),
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _sendBug() async {
    final t = _T.of(context);
    setState(() => _isSending = true);
    try {
      final String target = _isGroupBug
          ? Uri.encodeComponent(_selectedGroup?['jid'] ?? '')
          : _normalizePhone(_targetCtrl.text);

      final senderParam = _selectedSenderName != null ? '&sender=${Uri.encodeComponent(_selectedSenderName!)}' : '';
      final url = '${ConfigService.baseUrl}/sendBug'
          '?key=${widget.sessionKey}&target=$target&bug=$_selectedBugId'
          '&senderMode=${_useGlobalSender ? 'global' : 'private'}$senderParam';

      final res = await http.get(Uri.parse(url)).timeout(
        const Duration(seconds: 30),
        onTimeout: () => throw TimeoutException('Request timeout'),
      );

      final contentType = res.headers['content-type'] ?? '';
      if (!contentType.contains('application/json')) {
        _modalError('Server Error', 'Server return invalid response (${res.statusCode})', t);
        return;
      }

      Map<String, dynamic> data;
      try { data = jsonDecode(res.body); }
      catch (_) { _modalError('Parse Error', 'Response bukan JSON valid.', t); return; }

      if (data['cooldown'] == true) {
        _modalError('Cooldown Aktif', 'Tunggu ${data['wait'] ?? 'sebentar'} detik sebelum kirim lagi.', t);
      } else if (data['busy'] == true) {
        _modalError('Server Sibuk', 'Server sedang menangani banyak proses.\nMohon coba lagi nanti.', t);
      } else if (data['valid'] == false) {
        _modalError('Session Expired', 'Silakan login ulang.', t);
      } else if (data['sended'] == false) {
        _modalError('Gagal Kirim', 'Server sedang maintenance atau error.', t);
      } else {
        if (_isGroupBug) { setState(() => _selectedGroup = null); } else { _targetCtrl.clear(); }
        _modalSuccess(t);
      }
    } on TimeoutException {
      _modalError('Timeout', 'Server tidak merespon. Cek koneksi internet.', t);
    } catch (e) {
      final msg = e.toString();
      _modalError('Koneksi Error', 'Terjadi kesalahan: ${msg.length > 50 ? msg.substring(0, 50) : msg}', t);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _checkAndSend() async {
    final t = _T.of(context);

    if (_selectedBugId == null) {
      _alert('Pilih Bug Dulu', 'Pilih 1 bug sebelum kirim.', t);
      return;
    }

    if (_isSelectedBugNoNeedSender) {
      final displayTarget = _isGroupBug ? (_selectedGroup?['name'] ?? '') : _normalizePhone(_targetCtrl.text);
      await _showConfirmDialog(displayTarget);
      return;
    }

    if (_useGlobalSender && !_canUseGlobalSender) {
      _alert(
        'Akses Ditolak',
        'Fitur Global Sender khusus untuk member VIP!\n\nRole Anda: ${widget.role.toUpperCase()}\nHanya VIP yang dapat mengakses fitur ini.',
        t,
      );
      setState(() { _useGlobalSender = false; });
      return;
    }

    // GLOBAL SENDER HANYA UNTUK delayv3 DAN onehit SAJA (TANPA groupband)
    if (_useGlobalSender && _selectedBugId != 'delayv3' && _selectedBugId != 'onehit') {
      _alert(
        'Bug Tidak Diizinkan',
        'Sender Global hanya bisa digunakan untuk bug DELAY INVISIBLE.\n\nGunakan sender PRIVATE untuk bug lainnya.',
        t,
      );
      return;
    }

    if (_isGroupBug) {
      if (_selectedGroup == null) {
        _alert('Grup Belum Dipilih', 'Klik tombol "Pilih Grup" untuk memilih grup target.', t);
        return;
      }
    } else {
      final target = _normalizePhone(_targetCtrl.text);
      if (target.length < 8) { _alert('Nomor Tidak Valid', 'Masukkan nomor WhatsApp yang valid (min 8 digit).', t); return; }
    }

    setState(() => _isLoadingSender = true);
    final hasSender = await _checkSenderAvailability();
    setState(() => _isLoadingSender = false);

    if (!hasSender) {
      final chosen = await _showSelectSenderDialog();
      if (chosen == null) return;
      setState(() => _selectedSenderName = chosen);
    } else if (_senderList.length == 1) {
      _selectedSenderName = _senderList.first['sessionName']?.toString();
    } else if (_senderList.isNotEmpty && _selectedSenderName == null) {
      final chosen = await _showSelectSenderDialog();
      if (chosen == null) return;
      setState(() => _selectedSenderName = chosen);
    }

    final displayTarget = _isGroupBug ? (_selectedGroup?['name'] ?? _selectedGroup?['jid'] ?? '') : _normalizePhone(_targetCtrl.text);
    await _showConfirmDialog(displayTarget);
  }

  void _alert(String title, String body, _T t) =>
      showDialog(context: context, builder: (_) => _AlertSheet(title: title, body: body, t: t));

  void _modalSuccess(_T t) => showGeneralDialog(
    context: context, barrierDismissible: true, barrierLabel: 'ok',
    barrierColor: Colors.black.withAlpha((0.85 * 255).round()),
    transitionDuration: const Duration(milliseconds: 450),
    pageBuilder: (_, __, ___) => const SizedBox.shrink(),
    transitionBuilder: (ctx, anim, _, __) => _SuccessSheet(anim: anim, t: t),
  );

  void _modalError(String title, String msg, _T t) => showGeneralDialog(
    context: context, barrierDismissible: true, barrierLabel: 'err',
    barrierColor: Colors.black.withAlpha((0.85 * 255).round()),
    transitionDuration: const Duration(milliseconds: 380),
    pageBuilder: (_, __, ___) => const SizedBox.shrink(),
    transitionBuilder: (ctx, anim, _, __) => _ErrorSheet(anim: anim, title: title, message: msg, t: t),
  );

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, tp, _) {
        final t = _T(primary: tp.primaryColor, accent: tp.accentColor, dark: tp.isDarkMode);
        final displayBugs = _latestBugs.isNotEmpty ? _latestBugs : widget.listBug;

        return Scaffold(
          backgroundColor: t.bg,
          body: RefreshIndicator(
            onRefresh: _refreshListBug,
            color: t.primary,
            backgroundColor: t.card,
            child: Stack(children: [
              Positioned.fill(child: CustomPaint(painter: _GridPainter(t.primary))),
              _AmbientOrb(color: t.primary, ctrl: _breathCtrl, top: -80, right: -60, size: 320),
              _AmbientOrb(color: t.accent,  ctrl: _breathCtrl, bottom: -60, left: -40, size: 260),
              SafeArea(
                child: FadeTransition(
                  opacity: _entryFade,
                  child: SlideTransition(
                    position: _entrySlide,
                    child: CustomScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      slivers: [
                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(18, 18, 18, 36),
                          sliver: SliverList(delegate: SliverChildListDelegate([
                            _buildHeader(t),
                            const SizedBox(height: 14),
                            _buildVideo(t),
                            const SizedBox(height: 14),
                            _buildInputCard(t, displayBugs),
                            const SizedBox(height: 36),
                          ])),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (_isExpired) _buildExpiredOverlay(context),
              if (_isRefreshing)
                Positioned(
                  top: 50, left: 0, right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    margin: const EdgeInsets.symmetric(horizontal: 40),
                    decoration: BoxDecoration(
                      color: t.card,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: t.primary.withAlpha((0.3 * 255).round())),
                      boxShadow: [BoxShadow(color: t.primary.withAlpha((0.15 * 255).round()), blurRadius: 12)],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: t.primary)),
                        const SizedBox(width: 12),
                        Text('Mengupdate list bug...', style: TextStyle(color: t.textSub, fontSize: 11, fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ),
                ),
            ]),
          ),
        );
      },
    );
  }

  Widget _buildExpiredOverlay(BuildContext context) {
    return Positioned.fill(
      child: Container(
        color: const Color(0xFF060D18).withOpacity(0.96),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: const Color(0xFFF87171).withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFFF87171).withOpacity(0.4), width: 1.5),
                ),
                child: const Center(child: Text('⏰', style: TextStyle(fontSize: 36))),
              ),
              const SizedBox(height: 22),
              const Text(
                'AKUN EXPIRED',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 20, fontWeight: FontWeight.w900,
                  color: Color(0xFFF87171), letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 10),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 40),
                child: Text(
                  'Akun kamu sudah expired.\nSilakan beli akses atau hubungi admin untuk perpanjang.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 13, color: Color(0xFF94A3B8), height: 1.6,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Column(children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false);
                    },
                    child: Container(
                      width: double.infinity, height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF8B5CF6), Color(0xFF7C3AED)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [BoxShadow(color: const Color(0xFF8B5CF6).withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 6))],
                      ),
                      child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text('🛒', style: TextStyle(fontSize: 16)),
                        SizedBox(width: 10),
                        Text('BELI AKSES',
                            style: TextStyle(fontFamily: 'Outfit', fontSize: 15,
                                fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.5)),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final uri = Uri.parse('https://wa.me/6283187785936');
                          try { await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (_) {}
                        },
                        icon: const Text('💬', style: TextStyle(fontSize: 13)),
                        label: const Text('WhatsApp',
                            style: TextStyle(fontFamily: 'Outfit', fontSize: 12,
                                fontWeight: FontWeight.w700, color: Color(0xFF25D366))),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFF25D366), width: 1),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final uri = Uri.parse('https://t.me/gacha_789bot');
                          try { await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (_) {}
                        },
                        icon: const Text('✈️', style: TextStyle(fontSize: 13)),
                        label: const Text('Telegram',
                            style: TextStyle(fontFamily: 'Outfit', fontSize: 12,
                                fontWeight: FontWeight.w700, color: Color(0xFF229ED9))),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFF229ED9), width: 1),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                  ]),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _fetchLog() async {
    if (_logLoading) return;
    setState(() => _logLoading = true);
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/myLog?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        final logs = List<Map<String, dynamic>>.from(
          (d['logs'] as List).map((e) => Map<String, dynamic>.from(e))
        );
        setState(() {
          _activityLogs = logs;
          _unreadLog = logs.length;
        });
      }
    } catch (_) {}
    if (mounted) setState(() => _logLoading = false);
  }

  void _showAnnouncementDialog(_T t) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => _AnnouncementDialog(t: t),
    );
  }

  void _showMenuStyleDialog() {
    final t = _T.of(context);
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 340),
          decoration: BoxDecoration(
            color: t.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: t.borderBright),
            boxShadow: [BoxShadow(color: t.primary.withOpacity(0.15), blurRadius: 28, spreadRadius: 2)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: t.divider)),
              ),
              child: Row(children: [
                Icon(Icons.dashboard_customize_rounded, color: t.primary, size: 18),
                const SizedBox(width: 8),
                Text('MENU STYLE', style: TextStyle(
                  color: t.textPrimary, fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 2,
                )),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded, color: t.textSub, size: 20),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: StatefulBuilder(
                builder: (ctx, setLocal) {
                  return Column(children: [
                    _MenuStyleOption(
                      label: 'CARD MODE',
                      subtitle: 'Pilih bug via horizontal scroll card',
                      icon: Icons.view_carousel_rounded,
                      isSelected: _menuStyle == 'card',
                      t: t,
                      onTap: () {
                        setState(() => _menuStyle = 'card');
                        _saveMenuStyle('card');
                        setLocal(() {});
                        Future.delayed(const Duration(milliseconds: 300), () {
                          if (mounted) Navigator.pop(context);
                        });
                      },
                    ),
                    const SizedBox(height: 10),
                    _MenuStyleOption(
                      label: 'DROPDOWN MODE',
                      subtitle: 'Pilih bug via dropdown swipe-down',
                      icon: Icons.arrow_drop_down_circle_rounded,
                      isSelected: _menuStyle == 'swipe',
                      t: t,
                      onTap: () {
                        setState(() => _menuStyle = 'swipe');
                        _saveMenuStyle('swipe');
                        setLocal(() {});
                        Future.delayed(const Duration(milliseconds: 300), () {
                          if (mounted) Navigator.pop(context);
                        });
                      },
                    ),
                  ]);
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _showLogDialog(_T t) {
    setState(() => _unreadLog = 0);
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(maxHeight: 480),
          decoration: BoxDecoration(
            color: t.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: t.borderBright),
            boxShadow: [BoxShadow(color: t.primary.withOpacity(0.15), blurRadius: 30)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.fromLTRB(18, 16, 12, 14),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: t.divider)),
              ),
              child: Row(children: [
                Icon(Icons.history_rounded, color: t.primary, size: 18),
                const SizedBox(width: 8),
                Text('ACTIVITY LOG',
                    style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron',
                        fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                const Spacer(),
                GestureDetector(
                  onTap: () { Navigator.pop(context); _fetchLog(); },
                  child: Icon(Icons.refresh_rounded, color: t.primary, size: 18),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded, color: t.textSub, size: 18),
                ),
              ]),
            ),
            Flexible(
              child: _logLoading
                  ? Center(child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: CircularProgressIndicator(color: t.primary, strokeWidth: 2),
                    ))
                  : _activityLogs.isEmpty
                      ? Center(child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.inbox_rounded, color: t.textSub, size: 36),
                            const SizedBox(height: 10),
                            Text('Belum ada aktivitas', style: TextStyle(
                                color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 12)),
                          ]),
                        ))
                      : ListView.separated(
                          shrinkWrap: true,
                          padding: const EdgeInsets.all(12),
                          itemCount: _activityLogs.length,
                          separatorBuilder: (_, __) => Divider(color: t.divider, height: 1),
                          itemBuilder: (_, i) {
                            final log = _activityLogs[i];
                            final type = log['type'] ?? '';
                            final isExec = type == 'executing';
                            final isError = type == 'error';
                            final time = log['time'] != null
                                ? DateTime.fromMillisecondsSinceEpoch(log['time'] as int)
                                : null;
                            final timeStr = time != null
                                ? '${time.hour.toString().padLeft(2,'0')}:${time.minute.toString().padLeft(2,'0')}'
                                : '';

                            return Container(
                              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Container(
                                  width: 32, height: 32,
                                  decoration: BoxDecoration(
                                    color: (isExec ? t.primary : Colors.red).withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Center(child: Text(
                                    isExec ? '⛏️' : '❌',
                                    style: const TextStyle(fontSize: 15),
                                  )),
                                ),
                                const SizedBox(width: 10),
                                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Text(
                                      isExec ? 'TRICKSTER SYSTEM: EXECUTING' : 'TRICKSTER SYSTEM: ERROR',
                                      style: TextStyle(
                                        color: isExec ? t.primary : Colors.red,
                                        fontFamily: 'ShareTechMono',
                                        fontSize: 11, fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const Spacer(),
                                    Text(timeStr, style: TextStyle(
                                        color: t.textSub, fontSize: 10, fontFamily: 'ShareTechMono')),
                                  ]),
                                  const SizedBox(height: 4),
                                  if (isExec) ...[
                                    Text('✍️ ${widget.username}',
                                        style: TextStyle(color: t.textPrimary, fontSize: 12)),
                                    Text('📥 Target: ${log['target'] ?? '-'}',
                                        style: TextStyle(color: t.textSub, fontSize: 11)),
                                    Text('🌟 Bug: ${log['bug'] ?? '-'}',
                                        style: TextStyle(color: t.textSub, fontSize: 11)),
                                  ] else ...[
                                    Text('👤 ${widget.username}',
                                        style: TextStyle(color: t.textPrimary, fontSize: 12)),
                                    Text('❌ ${log['message'] ?? 'Connection Closed'}',
                                        style: const TextStyle(color: Colors.red, fontSize: 11)),
                                  ],
                                ])),
                              ]),
                            );
                          },
                        ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildHeader(_T t) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _cardDecor(t, glowAlpha: 0.12),
      child: Row(children: [
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, child) => Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [t.primary, t.accent], begin: Alignment.topLeft, end: Alignment.bottomRight),
              boxShadow: [BoxShadow(color: t.primary.withAlpha((0.3 + _pulseCtrl.value * 0.25).round()), blurRadius: 18 + _pulseCtrl.value * 10, spreadRadius: 1)],
            ),
            child: child,
          ),
          child: CircleAvatar(radius: 32, backgroundColor: t.bg, backgroundImage: AssetService.imageProvider('logo.png')),
        ),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AnimatedBuilder(
            animation: _shimmerCtrl,
            builder: (_, __) => ShaderMask(
              shaderCallback: (b) => LinearGradient(
                colors: [t.textPrimary.withAlpha((0.45 * 255).round()), t.textPrimary, t.primary, t.textPrimary, t.textPrimary.withAlpha((0.45 * 255).round())],
                stops: [
                  (_shimmerCtrl.value - 0.4).clamp(0.0, 1.0),
                  (_shimmerCtrl.value - 0.15).clamp(0.0, 1.0),
                  _shimmerCtrl.value.clamp(0.0, 1.0),
                  (_shimmerCtrl.value + 0.15).clamp(0.0, 1.0),
                  (_shimmerCtrl.value + 0.4).clamp(0.0, 1.0),
                ],
              ).createShader(b),
              child: Text(widget.username, style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 0.5)),
            ),
          ),
          const SizedBox(height: 10),
          Row(children: [
            _Chip(icon: Icons.verified_rounded, label: widget.role.toUpperCase(), color: t.primary, t: t),
            const SizedBox(width: 8),
            _Chip(icon: Icons.access_time_rounded, label: widget.expiredDate, color: t.accent, t: t),
            const Spacer(),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: widget.sessionKey));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Session Key copied!'), duration: Duration(seconds: 1)));
              },
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: t.primary.withAlpha((0.1 * 255).round()), borderRadius: BorderRadius.circular(8)),
                child: Icon(Icons.copy_rounded, color: t.primary, size: 14),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _showMenuStyleDialog(),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: t.primary.withAlpha((0.1 * 255).round()), borderRadius: BorderRadius.circular(8)),
                child: Icon(
                  _menuStyle == 'card' ? Icons.view_carousel_rounded : Icons.arrow_drop_down_circle_rounded,
                  color: t.primary, size: 14,
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _showAnnouncementDialog(t),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: t.accent.withAlpha((0.1 * 255).round()), borderRadius: BorderRadius.circular(8)),
                child: Icon(Icons.article_rounded, color: t.accent, size: 14),
              ),
            ),
          ]),
        ])),
      ]),
    );
  }

  Widget _buildVideo(_T t) {
    if (!_videoReady) {
      return Container(
        height: 190,
        decoration: _cardDecor(t),
        child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(width: 26, height: 26, child: CircularProgressIndicator(color: t.primary, strokeWidth: 2)),
          const SizedBox(height: 12),
          Text('LOADING VIDEO', style: TextStyle(color: t.primary, fontFamily: 'ShareTechMono', fontSize: 10, letterSpacing: 2.5)),
        ])),
      );
    }
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, child) => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: t.primary.withAlpha((0.18 + _pulseCtrl.value * 0.12).round()), blurRadius: 28, spreadRadius: 2)],
        ),
        child: child,
      ),
      child: Stack(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: AspectRatio(
            aspectRatio: _videoCtrl.value.aspectRatio,
            child: _chewieCtrl != null ? Chewie(controller: _chewieCtrl!) : const SizedBox.shrink(),
          ),
        ),
        Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: t.primary.withAlpha((0.4 * 255).round()), width: 1.5),
        ))),
        ..._cornerAccents(t),
      ]),
    );
  }

  List<Widget> _cornerAccents(_T t) {
    const sz = 18.0; const w = 2.5;
    return [
      Positioned(top: 0,    left: 0,  child: _Corner(color: t.primary, size: sz, strokeWidth: w, flip: false, flipY: false)),
      Positioned(top: 0,    right: 0, child: _Corner(color: t.primary, size: sz, strokeWidth: w, flip: true,  flipY: false)),
      Positioned(bottom: 0, left: 0,  child: _Corner(color: t.primary, size: sz, strokeWidth: w, flip: false, flipY: true)),
      Positioned(bottom: 0, right: 0, child: _Corner(color: t.primary, size: sz, strokeWidth: w, flip: true,  flipY: true)),
    ];
  }

  Widget _buildInputCard(_T t, List<Map<String, dynamic>> bugs) {
    return Container(
      decoration: _cardDecor(t, glowAlpha: 0.08),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: t.divider, width: 1))),
          child: Row(children: [
            Container(width: 3, height: 18,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                gradient: LinearGradient(colors: [t.primary, t.accent], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              ),
            ),
            const SizedBox(width: 10),
            Icon(Icons.settings_input_antenna_rounded, color: t.primary, size: 16),
            const SizedBox(width: 8),
            Text('TARGET CONFIG', style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 2.5)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: t.primary.withAlpha((0.1 * 255).round()),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: t.primary.withAlpha((0.25 * 255).round())),
              ),
              child: Text('READY', style: TextStyle(color: t.primary, fontFamily: 'ShareTechMono', fontSize: 9, letterSpacing: 1.5)),
            ),
          ]),
        ),

        Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            if (_canUseGlobalSender && !_isSelectedBugNoNeedSender) ...[
              _FieldLabel(label: 'MODE SENDER', icon: Icons.swap_horiz_rounded, color: t.primary, t: t),
              const SizedBox(height: 8),
              _SenderModeTab(
                isGlobal: _useGlobalSender,
                t: t,
                onChanged: (val) {
                  setState(() {
                    _useGlobalSender = val;
                    if (val && _selectedBugId != null && _selectedBugId != 'delayv3' && _selectedBugId != 'onehit') {
                      _selectedBugId = null;
                    }
                  });
                },
              ),
              if (_useGlobalSender) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF00E5FF).withAlpha((0.07 * 255).round()),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF00E5FF).withAlpha((0.2 * 255).round())),
                  ),
                  child: Row(children: [
                    const Icon(Icons.info_outline_rounded, color: Color(0xFF00E5FF), size: 13),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Sender Global hanya tersedia untuk bug DELAY INVISIBLE',
                        style: TextStyle(color: const Color(0xFF00E5FF).withAlpha((0.85 * 255).round()), fontFamily: 'ShareTechMono', fontSize: 10),
                      ),
                    ),
                  ]),
                ),
              ],
              const SizedBox(height: 20),
            ] else if (!_isSelectedBugNoNeedSender) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: t.primary.withAlpha((0.07 * 255).round()),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: t.primary.withAlpha((0.2 * 255).round())),
                ),
                child: Row(children: [
                  Icon(Icons.lock_rounded, color: t.primary, size: 13),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      widget.role == 'owner' 
                          ? 'Mode Sender: PRIVATE'
                          : 'Mode Sender: PRIVATE (Hanya VIP yang bisa menggunakan Global Sender)',
                      style: TextStyle(color: t.primary.withAlpha((0.85 * 255).round()), fontFamily: 'ShareTechMono', fontSize: 10),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 20),
            ],

            _FieldLabel(label: 'PILIH BUG', icon: Icons.bug_report_rounded, color: t.accent, t: t),
            const SizedBox(height: 8),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, anim) => FadeTransition(opacity: anim, child: child),
              child: _menuStyle == 'swipe'
                  ? _BugSwipeDown(
                      key: const ValueKey('swipe'),
                      listBug: (_canUseGlobalSender && _useGlobalSender)
                          ? bugs.where((b) => b['bug_id'] == 'delayv3' || b['bug_id'] == 'onehit').toList()  // ❌ TANPA groupband
                          : bugs,
                      selectedId: _selectedBugId,
                      t: t,
                      onChanged: (id) => setState(() {
                        _selectedBugId = id;
                        _targetCtrl.clear();
                        _selectedGroup = null;
                        _selectedSenderName = null;
                      }),
                    )
                  : _BugDropdown(
                      key: const ValueKey('card'),
                      listBug: (_canUseGlobalSender && _useGlobalSender)
                          ? bugs.where((b) => b['bug_id'] == 'delayv3' || b['bug_id'] == 'onehit').toList()  // ❌ TANPA groupband
                          : bugs,
                      selectedId: _selectedBugId,
                      t: t,
                      onChanged: (id) => setState(() {
                        _selectedBugId = id;
                        _targetCtrl.clear();
                        _selectedGroup = null;
                        _selectedSenderName = null;
                      }),
                    ),
            ),
            const SizedBox(height: 20),

            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(anim),
                  child: child,
                ),
              ),
              child: _isGroupBug
                  ? Column(
                      key: const ValueKey('group'),
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _FieldLabel(label: 'GRUP TARGET', icon: Icons.group_rounded, color: Colors.greenAccent, t: t),
                        const SizedBox(height: 8),
                        GestureDetector(
                          onTap: _showGroupPickerDialog,
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                            decoration: BoxDecoration(
                              color: Colors.greenAccent.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: _selectedGroup != null
                                    ? Colors.greenAccent.withOpacity(0.5)
                                    : Colors.white12,
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 36, height: 36,
                                  decoration: BoxDecoration(
                                    color: Colors.greenAccent.withOpacity(0.12),
                                    shape: BoxShape.circle,
                                  ),
                                  child: _isLoadingGroups
                                      ? const Padding(
                                          padding: EdgeInsets.all(8),
                                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.greenAccent),
                                        )
                                      : Icon(
                                          _selectedGroup != null ? Icons.group_rounded : Icons.group_add_rounded,
                                          color: Colors.greenAccent,
                                          size: 18,
                                        ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _selectedGroup != null
                                      ? Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              _selectedGroup!['name'] ?? _selectedGroup!['jid'],
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 14,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            Text(
                                              '${_selectedGroup!['participants'] ?? 0} anggota • tap untuk ganti',
                                              style: TextStyle(
                                                color: Colors.greenAccent.withOpacity(0.6),
                                                fontSize: 11,
                                              ),
                                            ),
                                          ],
                                        )
                                      : Text(
                                          'Tap untuk pilih grup dari sender',
                                          style: TextStyle(color: Colors.white38, fontSize: 13),
                                        ),
                                ),
                                Icon(
                                  Icons.keyboard_arrow_down_rounded,
                                  color: Colors.white38,
                                  size: 20,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    )
                  : Column(
                      key: const ValueKey('phone'),
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _FieldLabel(label: 'NOMOR TARGET', icon: Icons.phone_android_rounded, color: t.primary, t: t),
                        const SizedBox(height: 8),
                        _PhoneField(ctrl: _targetCtrl, t: t),
                      ],
                    ),
            ),

            const SizedBox(height: 24),

            AnimatedBuilder(
              animation: _pulseCtrl,
              builder: (_, __) {
                final canUseGlobal = _canUseGlobalSender;
                final btnColor = !canUseGlobal 
                    ? t.primary 
                    : (_useGlobalSender ? const Color(0xFF00E5FF) : t.primary);
                
                final btnGradient = !canUseGlobal
                    ? [t.primary, t.accent]
                    : (_useGlobalSender 
                        ? [const Color(0xFF00E5FF), const Color(0xFF0077FF)]
                        : [t.primary, t.accent]);
                        
                return Container(
                  width: double.infinity,
                  height: 54,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: btnGradient,
                      begin: Alignment.centerLeft, 
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: btnColor.withAlpha((0.35 + _pulseCtrl.value * 0.15).round()),
                        blurRadius: 18 + _pulseCtrl.value * 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ElevatedButton.icon(
                    onPressed: (_isSending || _isLoadingSender || _isRefreshing) ? null : _checkAndSend,
                    icon: (_isSending || _isLoadingSender)
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.2))
                        : Icon(
                            (!canUseGlobal || !_useGlobalSender) ? Icons.send_rounded : Icons.public_rounded,
                            color: Colors.white, size: 18,
                          ),
                    label: Text(
                      _isSending ? 'MENGIRIM...' : (_isLoadingSender ? 'CEK SENDER...' : 'SEND BUG'),
                      style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 2.5),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      disabledBackgroundColor: Colors.transparent,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 4),
          ]),
        ),
      ]),
    );
  }

  BoxDecoration _cardDecor(_T t, {double glowAlpha = 0.0}) => BoxDecoration(
    color: t.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: t.border),
    boxShadow: [
      if (glowAlpha > 0) BoxShadow(color: t.primary.withAlpha((glowAlpha * 255).round()), blurRadius: 24, spreadRadius: 2),
      BoxShadow(color: Colors.black.withAlpha((t.dark ? 0.35 : 0.07).round()), blurRadius: 16, offset: const Offset(0, 6)),
    ],
  );
}

// ── Menu Style Option ──
class _MenuStyleOption extends StatelessWidget {
  final String label;
  final String subtitle;
  final IconData icon;
  final bool isSelected;
  final _T t;
  final VoidCallback onTap;

  const _MenuStyleOption({
    required this.label,
    required this.subtitle,
    required this.icon,
    required this.isSelected,
    required this.t,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected
              ? t.primary.withAlpha((0.1 * 255).round())
              : t.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected
                ? t.primary.withAlpha((0.6 * 255).round())
                : t.border,
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [BoxShadow(color: t.primary.withAlpha((0.15 * 255).round()), blurRadius: 10)]
              : [],
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: (isSelected ? t.primary : t.accent).withAlpha((0.12 * 255).round()),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: isSelected ? t.primary : t.accent, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(
              color: isSelected ? t.textPrimary : t.textSub,
              fontFamily: 'Orbitron',
              fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
              fontSize: 11,
              letterSpacing: 1.5,
            )),
            const SizedBox(height: 3),
            Text(subtitle, style: TextStyle(
              color: t.textSub,
              fontFamily: 'ShareTechMono',
              fontSize: 10,
            )),
          ])),
          if (isSelected)
            Icon(Icons.check_circle_rounded, color: t.primary, size: 18),
        ]),
      ),
    );
  }
}

// ── Helper Widgets ──

class _Chip extends StatelessWidget {
  final IconData icon; final String label; final Color color; final _T t;
  const _Chip({required this.icon, required this.label, required this.color, required this.t});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: color.withAlpha((0.1 * 255).round()),
      borderRadius: BorderRadius.circular(30),
      border: Border.all(color: color.withAlpha((0.25 * 255).round())),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: color, size: 11),
      const SizedBox(width: 5),
      Text(label, style: TextStyle(color: color, fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
    ]),
  );
}

class _FieldLabel extends StatelessWidget {
  final String label; final IconData icon; final Color color; final _T t;
  const _FieldLabel({required this.label, required this.icon, required this.color, required this.t});
  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(icon, color: color, size: 13),
    const SizedBox(width: 6),
    Text(label, style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 10, letterSpacing: 1.5)),
  ]);
}

class _PhoneField extends StatelessWidget {
  final TextEditingController ctrl; final _T t;
  const _PhoneField({required this.ctrl, required this.t});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: t.cardAlt, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.border)),
    child: TextField(
      controller: ctrl,
      keyboardType: TextInputType.phone,
      style: TextStyle(color: t.textPrimary, fontFamily: 'ShareTechMono', fontSize: 15),
      cursorColor: t.primary,
      decoration: InputDecoration(
        hintText: '628xxxxxxxxxx',
        hintStyle: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 13),
        prefixIcon: Padding(
          padding: const EdgeInsets.all(11),
          child: Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(color: t.primary.withAlpha((0.12 * 255).round()), borderRadius: BorderRadius.circular(9)),
            child: Icon(Icons.phone_android_rounded, color: t.primary, size: 17),
          ),
        ),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: t.primary, width: 1.5)),
        filled: true, fillColor: Colors.transparent,
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      ),
    ),
  );
}

class _Corner extends StatelessWidget {
  final Color color; final double size, strokeWidth; final bool flip, flipY;
  const _Corner({required this.color, required this.size, required this.strokeWidth, required this.flip, required this.flipY});
  @override
  Widget build(BuildContext context) => Transform(
    alignment: Alignment.center,
    transform: Matrix4.identity()..scale(flip ? -1.0 : 1.0, flipY ? -1.0 : 1.0, 1.0),
    child: CustomPaint(size: Size(size, size), painter: _CornerPainter(color: color, strokeWidth: strokeWidth)),
  );
}

class _CornerPainter extends CustomPainter {
  final Color color; final double strokeWidth;
  const _CornerPainter({required this.color, required this.strokeWidth});
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawPath(
      Path()..moveTo(0, size.height)..lineTo(0, strokeWidth / 2)..lineTo(size.width, strokeWidth / 2),
      Paint()..color = color..strokeWidth = strokeWidth..style = PaintingStyle.stroke..strokeCap = StrokeCap.round,
    );
  }
  @override bool shouldRepaint(_) => false;
}

class _AmbientOrb extends StatelessWidget {
  final Color color; final AnimationController ctrl; final double? top, bottom, left, right, size;
  const _AmbientOrb({required this.color, required this.ctrl, this.top, this.bottom, this.left, this.right, this.size = 200});
  @override
  Widget build(BuildContext context) => Positioned(
    top: top, bottom: bottom, left: left, right: right,
    child: IgnorePointer(child: AnimatedBuilder(animation: ctrl,
      builder: (_, __) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(
            color: color.withAlpha((0.05 + ctrl.value * 0.04).round()),
            blurRadius: (size ?? 200) * (0.55 + ctrl.value * 0.1),
            spreadRadius: (size ?? 200) * (0.3 + ctrl.value * 0.08),
          )],
        ),
      ),
    )),
  );
}

class _GridPainter extends CustomPainter {
  final Color color;
  const _GridPainter(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = color.withAlpha((0.035 * 255).round())..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    for (double y = 0; y < size.height; y += step) canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
  }
  @override bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}

// ── Dialog Sheets ──

class _AlertSheet extends StatelessWidget {
  final String title, body; final _T t;
  const _AlertSheet({required this.title, required this.body, required this.t});
  @override
  Widget build(BuildContext context) => Center(child: Material(color: Colors.transparent,
    child: Container(
      width: 310, padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: t.card, borderRadius: BorderRadius.circular(24),
        border: Border.all(color: t.primary.withAlpha((0.3 * 255).round())),
        boxShadow: [BoxShadow(color: t.primary.withAlpha((0.12 * 255).round()), blurRadius: 30)],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: t.primary.withAlpha((0.1 * 255).round()), shape: BoxShape.circle, border: Border.all(color: t.primary.withAlpha((0.3 * 255).round()))),
          child: Icon(Icons.info_outline_rounded, color: t.primary, size: 26),
        ),
        const SizedBox(height: 16),
        Text(title, style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1), textAlign: TextAlign.center),
        const SizedBox(height: 10),
        Text(body, style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 13), textAlign: TextAlign.center),
        const SizedBox(height: 24),
        SizedBox(width: double.infinity, child: ElevatedButton(
          onPressed: () => Navigator.pop(context),
          style: ElevatedButton.styleFrom(
            backgroundColor: t.primary.withAlpha((0.12 * 255).round()), foregroundColor: t.primary, elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: t.primary.withAlpha((0.3 * 255).round()))),
            padding: const EdgeInsets.symmetric(vertical: 13),
          ),
          child: const Text('OK', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 2)),
        )),
      ]),
    ),
  ));
}

class _SuccessSheet extends StatefulWidget {
  final Animation<double> anim; final _T t;
  const _SuccessSheet({required this.anim, required this.t});
  @override State<_SuccessSheet> createState() => _SuccessSheetState();
}

class _SuccessSheetState extends State<_SuccessSheet> with TickerProviderStateMixin {
  late AnimationController _ctrl, _ringCtrl, _particleCtrl;
  late Animation<double> _scale, _fade, _check;

  @override
  void initState() {
    super.initState();
    _ctrl         = AnimationController(vsync: this, duration: const Duration(milliseconds: 750));
    _ringCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _particleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..forward();
    _scale  = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _fade   = CurvedAnimation(parent: _ctrl, curve: const Interval(0.4, 1.0, curve: Curves.easeOut));
    _check  = CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1.0, curve: Curves.elasticOut));
    _ctrl.forward();
  }

  @override void dispose() { _ctrl.dispose(); _ringCtrl.dispose(); _particleCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Center(
      child: FadeTransition(
        opacity: widget.anim,
        child: ScaleTransition(
          scale: _scale,
          child: Material(color: Colors.transparent,
            child: SizedBox(width: 310,
              child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
                AnimatedBuilder(animation: _particleCtrl, builder: (_, __) => Stack(
                  children: List.generate(12, (i) {
                    final angle = (i / 12) * 2 * pi - pi / 2;
                    final radius = 115.0 + _particleCtrl.value * 60;
                    final opacity = (1 - _particleCtrl.value).clamp(0.0, 1.0);
                    final cx = 155 + cos(angle) * radius;
                    final cy = 150 + sin(angle) * radius;
                    final sz = 6.0 + (i % 3) * 3.0;
                    return Positioned(
                      left: cx - sz / 2, top: cy - sz / 2,
                      child: Opacity(opacity: opacity,
                        child: Container(width: sz, height: sz,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: i % 2 == 0 ? t.primary : t.accent,
                            boxShadow: [BoxShadow(color: (i % 2 == 0 ? t.primary : t.accent).withAlpha((0.8 * 255).round()), blurRadius: 8)],
                          ),
                        ),
                      ),
                    );
                  }),
                )),
                Container(
                  padding: const EdgeInsets.fromLTRB(28, 36, 28, 28),
                  decoration: BoxDecoration(
                    color: t.card, borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: t.primary.withAlpha((0.3 * 255).round()), width: 1.5),
                    boxShadow: [
                      BoxShadow(color: t.primary.withAlpha((0.2 * 255).round()), blurRadius: 60, spreadRadius: 5),
                      BoxShadow(color: t.accent.withAlpha((0.12 * 255).round()), blurRadius: 80, spreadRadius: 8),
                    ],
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    AnimatedBuilder(animation: _ringCtrl, builder: (_, __) => Stack(alignment: Alignment.center, children: [
                      Container(width: 96, height: 96,
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: t.primary.withAlpha((0.08 + _ringCtrl.value * 0.2).round()), width: 1.5))),
                      Container(width: 76, height: 76,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [t.primary.withAlpha((0.2 * 255).round()), t.primary.withAlpha((0.04 * 255).round())]),
                          border: Border.all(color: t.primary.withAlpha((0.55 * 255).round()), width: 2),
                          boxShadow: [BoxShadow(color: t.primary.withAlpha((0.35 * 255).round()), blurRadius: 22, spreadRadius: 3)],
                        ),
                        child: ScaleTransition(scale: _check, child: Icon(Icons.check_rounded, color: t.primary, size: 38, shadows: [Shadow(color: t.primary, blurRadius: 18)]))),
                    ])),
                    const SizedBox(height: 24),
                    FadeTransition(opacity: _fade, child: Text('BERHASIL!', style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 26, letterSpacing: 3, shadows: [Shadow(color: t.primary, blurRadius: 14)]))),
                    const SizedBox(height: 8),
                    FadeTransition(opacity: _fade, child: Text('Bug berhasil dikirim ke target!', style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 12), textAlign: TextAlign.center)),
                    const SizedBox(height: 28),
                    FadeTransition(opacity: _fade, child: Container(
                      width: double.infinity, height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [t.primary, t.accent]),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(color: t.primary.withAlpha((0.3 * 255).round()), blurRadius: 14)],
                      ),
                      child: ElevatedButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                        child: const Text('CLOSE', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 3)),
                      ),
                    )),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _ErrorSheet extends StatefulWidget {
  final Animation<double> anim; final String title, message; final _T t;
  const _ErrorSheet({required this.anim, required this.title, required this.message, required this.t});
  @override State<_ErrorSheet> createState() => _ErrorSheetState();
}

class _ErrorSheetState extends State<_ErrorSheet> with TickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale, _shake, _fade;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 580));
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack);
    _shake = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 5.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.2, 1.0)));
    _fade  = CurvedAnimation(parent: _ctrl, curve: const Interval(0.3, 1.0, curve: Curves.easeOut));
    _ctrl.forward();
  }

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Center(
      child: FadeTransition(
        opacity: widget.anim,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Transform.scale(
            scale: _scale.value,
            child: Transform.translate(
              offset: Offset(_shake.value, 0),
              child: Material(color: Colors.transparent,
                child: Container(
                  width: 310, padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    color: t.card, borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.redAccent.withAlpha((0.4 * 255).round()), width: 1.5),
                    boxShadow: [BoxShadow(color: Colors.redAccent.withAlpha((0.15 * 255).round()), blurRadius: 50, spreadRadius: 5)],
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.redAccent.withAlpha((0.1 * 255).round()),
                        border: Border.all(color: Colors.redAccent.withAlpha((0.45 * 255).round()), width: 1.8),
                        boxShadow: [BoxShadow(color: Colors.redAccent.withAlpha((0.2 * 255).round()), blurRadius: 20, spreadRadius: 3)],
                      ),
                      child: const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 34),
                    ),
                    const SizedBox(height: 20),
                    FadeTransition(opacity: _fade, child: Text(widget.title, style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.w800, fontSize: 17, letterSpacing: 1), textAlign: TextAlign.center)),
                    const SizedBox(height: 10),
                    FadeTransition(opacity: _fade, child: Text(widget.message, style: TextStyle(color: t.textSub, fontFamily: 'ShareTechMono', fontSize: 12), textAlign: TextAlign.center)),
                    const SizedBox(height: 26),
                    FadeTransition(opacity: _fade,
                      child: SizedBox(width: double.infinity, height: 48,
                        child: ElevatedButton(
                          onPressed: () => Navigator.of(context).pop(),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.redAccent.withAlpha((0.12 * 255).round()), foregroundColor: Colors.white, elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: Colors.redAccent.withAlpha((0.4 * 255).round()))),
                          ),
                          child: const Text('CLOSE', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 2.5)),
                        ),
                      ),
                    ),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AnnouncementDialog extends StatefulWidget {
  final dynamic t;
  const _AnnouncementDialog({required this.t});
  @override
  State<_AnnouncementDialog> createState() => _AnnouncementDialogState();
}

class _AnnouncementDialogState extends State<_AnnouncementDialog> {
  bool _loading = true;
  String _text = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final text = await _AnnouncementService.fetch();
    if (mounted) setState(() { _text = text; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 360),
        decoration: BoxDecoration(
          color: t.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: t.accent.withOpacity(0.35), width: 1.2),
          boxShadow: [BoxShadow(color: t.accent.withOpacity(0.15), blurRadius: 28, spreadRadius: 2)],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: t.accent.withOpacity(0.08),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                border: Border(bottom: BorderSide(color: t.accent.withOpacity(0.2))),
              ),
              child: Row(children: [
                Icon(Icons.article_rounded, color: t.accent, size: 18),
                const SizedBox(width: 10),
                Text('PENGUMUMAN', style: TextStyle(color: t.textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 2)),
                const Spacer(),
                GestureDetector(
                  onTap: () { setState(() { _loading = true; _text = ''; }); _load(); },
                  child: Icon(Icons.refresh_rounded, color: t.accent, size: 16),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: _loading
                  ? Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: t.accent, strokeWidth: 2)))
                  : Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: t.accent.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: t.accent.withOpacity(0.15)),
                      ),
                      child: Text(
                        _text,
                        style: TextStyle(color: t.textPrimary, fontSize: 13, height: 1.6),
                      ),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: t.accent.withOpacity(0.15),
                    foregroundColor: t.accent,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: t.accent.withOpacity(0.3))),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text('TUTUP', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 2)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Tutor Video Dialog ──
class _TutorVideoDialog extends StatefulWidget {
  final _T t;
  final File videoFile;
  const _TutorVideoDialog({required this.t, required this.videoFile});
  @override
  State<_TutorVideoDialog> createState() => _TutorVideoDialogState();
}

class _TutorVideoDialogState extends State<_TutorVideoDialog> {
  late VideoPlayerController _ctrl;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.file(widget.videoFile)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _ready = true);
          _ctrl.setVolume(1.0);
          _ctrl.play();
          _ctrl.setLooping(true);
        }
      });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      child: Container(
        decoration: BoxDecoration(
          color: t.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: t.primary.withOpacity(0.35), width: 1.2),
          boxShadow: [BoxShadow(color: t.primary.withOpacity(0.15), blurRadius: 28)],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: t.primary.withOpacity(0.08),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                border: Border(bottom: BorderSide(color: t.primary.withOpacity(0.2))),
              ),
              child: Row(children: [
                Icon(Icons.play_circle_outline_rounded, color: t.primary, size: 18),
                const SizedBox(width: 10),
                Text('TUTORIAL SENDER', style: TextStyle(
                  color: t.textPrimary, fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 2,
                )),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Icon(Icons.close_rounded, color: t.textSub, size: 20),
                ),
              ]),
            ),
            ClipRRect(
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18)),
              child: _ready
                  ? GestureDetector(
                      onTap: () {
                        _ctrl.value.isPlaying ? _ctrl.pause() : _ctrl.play();
                        setState(() {});
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          AspectRatio(
                            aspectRatio: _ctrl.value.aspectRatio,
                            child: VideoPlayer(_ctrl),
                          ),
                          if (!_ctrl.value.isPlaying)
                            Container(
                              width: 52, height: 52,
                              decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), shape: BoxShape.circle),
                              child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30),
                            ),
                        ],
                      ),
                    )
                  : Container(
                      height: 200,
                      color: Colors.black,
                      child: Center(child: CircularProgressIndicator(color: t.primary, strokeWidth: 2)),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              child: SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: TextButton.styleFrom(
                    backgroundColor: t.primary.withOpacity(0.12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: Text('Skip', style: TextStyle(
                    color: t.primary, fontFamily: 'Outfit',
                    fontWeight: FontWeight.w700, fontSize: 13,
                  )),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}