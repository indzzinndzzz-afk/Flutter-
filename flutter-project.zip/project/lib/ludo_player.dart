import 'package:flutter/material.dart';

// --- ENUM ROLE & COLOR ---
enum PlayerRole { owner, admin, vip, member, guest }

extension PlayerRoleExt on PlayerRole {
  String get label {
    switch (this) {
      case PlayerRole.owner:  return '👑 OWNER';
      case PlayerRole.admin:  return '🛡️ ADMIN';
      case PlayerRole.vip:    return '💎 VIP';
      case PlayerRole.member: return '🎮 MEMBER';
      case PlayerRole.guest:  return '👤 GUEST';
    }
  }

  Color get badgeColor {
    switch (this) {
      case PlayerRole.owner:  return const Color(0xFFFFD700);
      case PlayerRole.admin:  return const Color(0xFFE74C3C);
      case PlayerRole.vip:    return const Color(0xFF9B59B6);
      case PlayerRole.member: return const Color(0xFF3498DB);
      case PlayerRole.guest:  return const Color(0xFF7F8C8D);
    }
  }
}

enum PawnColor { red, blue, green, yellow }

extension PawnColorExt on PawnColor {
  Color get color {
    switch (this) {
      case PawnColor.red:    return const Color(0xFFFF5252);
      case PawnColor.blue:   return const Color(0xFF448AFF);
      case PawnColor.green:  return const Color(0xFF69F0AE);
      case PawnColor.yellow: return const Color(0xFFFFD740);
    }
  }
  
  String get label {
    switch (this) {
      case PawnColor.red:    return 'Merah';
      case PawnColor.blue:   return 'Biru';
      case PawnColor.green:  return 'Hijau';
      case PawnColor.yellow: return 'Kuning';
    }
  }
}

// --- SKIN SYSTEM (DIPERBAIKI) ---
enum PawnSkin { circle, chess, planet, animal }

extension PawnSkinExt on PawnSkin {
  String get label {
    switch (this) {
      case PawnSkin.circle: return 'Klasik';
      case PawnSkin.chess:  return 'Catur';
      case PawnSkin.planet: return 'Galaksi';
      case PawnSkin.animal: return 'Rimba';
    }
  }

  // PERBAIKAN: Method getEmoji sekarang match dengan enum
  String getEmoji(int playerIndex) {
    final int pIdx = playerIndex % 4;
    
    switch (this) {
      case PawnSkin.circle:
        final List<String> icons = ['🔴', '🔵', '🟢', '🟡'];
        return icons[pIdx];
        
      case PawnSkin.chess:
        final List<String> icons = ['♟️', '♞', '♝', '♜'];
        return icons[pIdx];
        
      case PawnSkin.planet:
        final List<String> icons = ['🌍', '🪐', '☀️', '🌙'];
        return icons[pIdx];
        
      case PawnSkin.animal:
        final List<String> icons = ['🦁', '🐯', '🐼', '🦊'];
        return icons[pIdx];
    }
  }
}

// --- CLASS PEMAIN (DIPERBAIKI) ---
class SnakeLadderPlayer {
  final String name;
  final PawnColor pawnColor;
  final PlayerRole role;
  final bool isBot;
  final int playerIndex;
  
  // Tidak final biar bisa diubah
  PawnSkin pawnSkin;
  
  // Properties yang bisa berubah
  int position;
  int totalRolls;
  int snakesHit;
  int laddersClimbed;

  SnakeLadderPlayer({
    required this.name,
    required this.pawnColor,
    required this.role,
    required this.playerIndex,
    this.isBot = false,
    this.pawnSkin = PawnSkin.circle,
    this.position = 0,
    this.totalRolls = 0,
    this.snakesHit = 0,
    this.laddersClimbed = 0,
  });

  // Getter
  bool get hasWon => position >= 100;
  String get currentEmoji => pawnSkin.getEmoji(playerIndex);
  
  // Method untuk ganti skin
  void changeSkin(PawnSkin newSkin) {
    pawnSkin = newSkin;
  }
  
  // Reset untuk game baru
  void reset() {
    position = 0;
    totalRolls = 0;
    snakesHit = 0;
    laddersClimbed = 0;
  }

  // Widget Badge Role
  Widget buildRoleBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: role.badgeColor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: role.badgeColor.withOpacity(0.5), width: 1),
      ),
      child: Text(
        role.label,
        style: TextStyle(
          color: role.badgeColor,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

// --- TAMBAHAN: Konstanta warna yang mungkin kurang ---
const Color white05 = Color(0x0DFFFFFF);
const Color black05 = Color(0x0D000000);

// --- TAMBAHAN: Icon constants jika diperlukan UI lain ---
const List<String> kChessIcons = ['♟️', '♞', '♝', '♜', '♛', '♚'];

const List<String> kPlanetIcons = ['☿️', '♀️', '🌍', '♂️', '♃', '🪐'];