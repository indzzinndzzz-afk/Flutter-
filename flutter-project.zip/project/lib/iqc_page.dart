import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:battery_plus/battery_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class IqcPage extends StatefulWidget {
  const IqcPage({super.key});

  @override
  State<IqcPage> createState() => _IqcPageState();
}

class _IqcPageState extends State<IqcPage> with TickerProviderStateMixin {
  final TextEditingController _textController = TextEditingController();
  final String _apiKey = 'Miwa';

  Uint8List? _imageBytes;
  bool _loading = false;
  bool _downloading = false;
  String? _errorMsg;

  // Battery
  final Battery _battery = Battery();
  int _batteryLevel = 0;
  BatteryState _batteryState = BatteryState.unknown;

  // Time
  late DateTime _now;
  late Timer _timer;

  // Pulse animation
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  // ── Colors (Purple Theme) ──
  static const Color _accent       = Color(0xFFA855F7);
  static const Color _accentDim    = Color(0x59A855F7); // 35% opacity
  static const Color _accentGlow   = Color(0x1FA855F7); // 12% opacity
  static const Color _accentBorder = Color(0x66A855F7); // 40% opacity
  static const Color _bgColor      = Color(0xFF0D0D0D);
  static const Color _cardBg       = Color(0xFF1A1A2E);
  static const Color _gradientTop  = Color(0xFF1A0A2E);
  static const Color _gradientBot  = Color(0xFF0D0D1F);
  static const Color _dlBg         = Color(0xFF2A1A3E);

  static const Color _batGreen     = Color(0xFF69FF47);
  static const Color _batYellow    = Color(0xFFFFB300);
  static const Color _batRed       = Color(0xFFFF4444);
  static const Color _batCharging  = Color(0xFF00E5FF);

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _initBattery();

    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _now = DateTime.now());
    });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  Future<void> _initBattery() async {
    _batteryLevel = await _battery.batteryLevel;
    _batteryState = await _battery.batteryState;
    setState(() {});

    _battery.onBatteryStateChanged.listen((state) async {
      final level = await _battery.batteryLevel;
      setState(() {
        _batteryState = state;
        _batteryLevel = level;
      });
    });
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    final s = dt.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  String _formatDate(DateTime dt) {
    const days = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    return '${days[dt.weekday - 1]}, ${dt.day} ${months[dt.month - 1]} ${dt.year}';
  }

  Color _batteryColor() {
    if (_batteryState == BatteryState.charging) return _batCharging;
    if (_batteryLevel <= 20) return _batRed;
    if (_batteryLevel <= 50) return _batYellow;
    return _batGreen;
  }

  IconData _batteryIcon() {
    if (_batteryState == BatteryState.charging) return Icons.battery_charging_full;
    if (_batteryLevel >= 90) return Icons.battery_full;
    if (_batteryLevel >= 70) return Icons.battery_6_bar;
    if (_batteryLevel >= 50) return Icons.battery_4_bar;
    if (_batteryLevel >= 30) return Icons.battery_3_bar;
    if (_batteryLevel >= 15) return Icons.battery_2_bar;
    return Icons.battery_1_bar;
  }

  Future<void> _generateImage() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      setState(() => _errorMsg = 'Text tidak boleh kosong!');
      return;
    }
    setState(() {
      _loading = true;
      _errorMsg = null;
      _imageBytes = null;
    });
    try {
      final uri = Uri.parse(
        'https://api.botcahx.eu.org/api/maker/iqc'
        '?text=${Uri.encodeComponent(text)}&apikey=$_apiKey',
      );
      final response = await http.get(
        uri,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
          'Accept': 'application/json, image/*, */*',
          'Referer': 'https://api.botcahx.eu.org',
        },
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final contentType = response.headers['content-type'] ?? '';
        if (contentType.startsWith('image/')) {
          // Langsung image bytes
          setState(() => _imageBytes = response.bodyBytes);
        } else {
          // Coba parse JSON, ambil URL dari field "result"
          try {
            final json = jsonDecode(response.body) as Map<String, dynamic>;
            final imageUrl = json['result'] as String?;
            if (imageUrl != null && imageUrl.isNotEmpty) {
              final imgResponse = await http.get(
                Uri.parse(imageUrl),
                headers: {'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'},
              ).timeout(const Duration(seconds: 15));
              if (imgResponse.statusCode == 200) {
                setState(() => _imageBytes = imgResponse.bodyBytes);
              } else {
                setState(() => _errorMsg = 'Gagal download gambar (${imgResponse.statusCode})');
              }
            } else {
              setState(() => _errorMsg = 'Response tidak valid: ${response.body}');
            }
          } catch (_) {
            setState(() => _errorMsg = 'Gagal parse response (${response.statusCode})');
          }
        }
      } else {
        setState(() => _errorMsg = 'Gagal generate gambar (${response.statusCode})');
      }
    } catch (e) {
      setState(() => _errorMsg = 'Error: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _downloadImage() async {
    if (_imageBytes == null) return;
    setState(() => _downloading = true);
    try {
      PermissionStatus status;
      if (Platform.isAndroid) {
        status = await Permission.storage.request();
        if (!status.isGranted) {
          status = await Permission.manageExternalStorage.request();
        }
      } else {
        status = await Permission.photos.request();
      }
      if (!status.isGranted) {
        setState(() => _errorMsg = 'Permission storage ditolak!');
        return;
      }
      Directory? dir;
      if (Platform.isAndroid) {
        dir = Directory('/storage/emulated/0/Download');
        if (!await dir.exists()) dir = await getExternalStorageDirectory();
      } else {
        dir = await getApplicationDocumentsDirectory();
      }
      final fileName = 'iqc_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final file = File('${dir!.path}/$fileName');
      await file.writeAsBytes(_imageBytes!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ Tersimpan: ${file.path}'),
            backgroundColor: Colors.green.shade700,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      setState(() => _errorMsg = 'Gagal download: $e');
    } finally {
      setState(() => _downloading = false);
    }
  }

  @override
  void dispose() {
    _textController.dispose();
    _timer.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      appBar: AppBar(
        backgroundColor: _bgColor,
        title: const Text(
          'iqc : iphone quotes chat',
          style: TextStyle(
            color: _accent,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: _accent),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // ── Status Card ──
            _buildAnimeStatusCard(),
            const SizedBox(height: 20),

            // ── Input Field ──
            Container(
              decoration: BoxDecoration(
                color: _cardBg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _accentBorder,
                ),
              ),
              child: TextField(
                controller: _textController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Masukkan teks...',
                  hintStyle: TextStyle(color: Colors.white38),
                  prefixIcon: Icon(Icons.text_fields, color: _accent),
                  border: InputBorder.none,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Generate Button ──
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _loading ? null : _generateImage,
                icon: _loading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.auto_awesome),
                label: Text(_loading ? 'Generating...' : 'Generate'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accent,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),

            // ── Error Box ──
            if (_errorMsg != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.shade900.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.redAccent),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.redAccent),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _errorMsg!,
                        style: const TextStyle(color: Colors.redAccent),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            // ── Result Image ──
            if (_imageBytes != null) ...[
              const SizedBox(height: 20),
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.memory(_imageBytes!, fit: BoxFit.contain),
              ),
              const SizedBox(height: 16),

              // ── Download Button ──
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _downloading ? null : _downloadImage,
                  icon: _downloading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.download_rounded),
                  label: Text(_downloading ? 'Menyimpan...' : 'Download Gambar'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _dlBg,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    side: const BorderSide(color: _accentDim),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAnimeStatusCard() {
    final batColor = _batteryColor();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_gradientTop, _gradientBot],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: _accentDim,
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: _accentGlow,
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          // ── Clock Side ──
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulseAnim,
                      builder: (_, __) => Opacity(
                        opacity: _pulseAnim.value,
                        child: const Icon(
                          Icons.favorite,
                          color: _accent,
                          size: 13,
                        ),
                      ),
                    ),
                    const SizedBox(width: 5),
                    const Text(
                      'SISTEM',
                      style: TextStyle(
                        color: _accent,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  _formatTime(_now),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    height: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formatDate(_now),
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.45),
                    fontSize: 11,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),

          // ── Divider ──
          Container(
            width: 1,
            height: 55,
            color: _accentDim,
            margin: const EdgeInsets.symmetric(horizontal: 14),
          ),

          // ── Battery Side ──
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                children: [
                  Text(
                    _batteryState == BatteryState.charging
                        ? 'CHARGING'
                        : 'BATERAI',
                    style: TextStyle(
                      color: batColor,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(width: 4),
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Opacity(
                      opacity: _batteryState == BatteryState.charging
                          ? _pulseAnim.value
                          : 1.0,
                      child: Icon(
                        _batteryIcon(),
                        color: batColor,
                        size: 16,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '$_batteryLevel%',
                style: TextStyle(
                  color: batColor,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  height: 1,
                ),
              ),
              const SizedBox(height: 6),
              SizedBox(
                width: 80,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _batteryLevel / 100,
                    minHeight: 6,
                    backgroundColor: Colors.white12,
                    valueColor: AlwaysStoppedAnimation<Color>(batColor),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
