import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'config_service.dart';

// ─────────────────────────────────────────────────────────────
// 🎨 PREMIUM PALETTE CONSTANTS
// ─────────────────────────────────────────────────────────────
const _kGold       = Color(0xFFFFD700);
const _kGoldLight  = Color(0xFFFFEC6E);
const _kGoldDark   = Color(0xFFB8860B);
const _kRed        = Color(0xFFFF2D55);
const _kDark       = Color(0xFF0A0A0A);
const _kDarkCard   = Color(0xFF151515);
const _kPurple     = Color(0xFF7B2FBE);
const _kPurpleGlow = Color(0xFFBB6BFF);

class SlotMachinePage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const SlotMachinePage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<SlotMachinePage> createState() => _SlotMachinePageState();
}

class _SlotMachinePageState extends State<SlotMachinePage> with TickerProviderStateMixin {
  // ─── LOGIC STATE ───
  int saldo = 0;
  int freeSpin = 0;
  bool _isSpinning = false;
  bool _isLoading = true;
  List<String> reels = ["🎰", "🎰", "🎰"];
  List<String> spinningReels = ["🎰", "🎰", "🎰"];
  
  // ─── RESULT STATE ───
  String _resultMsg = "";
  bool _isWin = false;
  bool _isSkullResult = false;
  int _lastPayout = 0;

  // ─── AUTO PLAY ───
  bool _isAutoPlay = false;
  int _autoPlayCount = 10;
  int _autoPlayRemaining = 0;
  Timer? _autoPlayTimer;

  // ─── AUDIO ───
  late AudioPlayer _bgmPlayer;
  late AudioPlayer _sfxPlayer;
  bool _isMuted = false;
  bool _bgmLoaded = false;

  final TextEditingController _betController = TextEditingController(text: "100");
  final Random _random = Random();

  // ─── ANIMATIONS ───
  late AnimationController _lightCtrl;
  late AnimationController _glowCtrl;

  final List<String> allSymbols = ["🍒", "🍋", "🍊", "🍇", "🔔", "💎", "7️⃣", "💀"];

  @override
  void initState() {
    super.initState();
    _lightCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..repeat(reverse: true);
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    
    // Init audio players
    _bgmPlayer = AudioPlayer();
    _sfxPlayer = AudioPlayer();
    
    _loadSaldo();
    _initAudio();
  }

  // ─────────────────────────────────────────────────────────────
  // 🎵 AUDIO METHODS
  // ─────────────────────────────────────────────────────────────

  Future<void> _initAudio() async {
    try {
      // Set BGM ke mode loop
      await _bgmPlayer.setReleaseMode(ReleaseMode.loop);
      
      // Load dan play BGM
      await _bgmPlayer.play(DeviceFileSource(AssetService.audioPathSync('casino_bg.mp3')));
      setState(() => _bgmLoaded = true);
      
      // 🔥 VOLUME 1.0 (MAX)
      await _bgmPlayer.setVolume(1.0);
      await _sfxPlayer.setVolume(1.0);
    } catch (e) {
      debugPrint('Error loading BGM: $e');
    }
  }

  Future<void> _playSpinSound() async {
    if (_isMuted) return;
    try {
      await _sfxPlayer.stop();
      await _sfxPlayer.play(DeviceFileSource(AssetService.audioPathSync('spin.mp3')));
      await _sfxPlayer.setVolume(1.0);
    } catch (e) {
      debugPrint('Error playing spin sound: $e');
    }
  }

  Future<void> _playFreeSpinSound() async {
    if (_isMuted) return;
    try {
      await _sfxPlayer.stop();
      await _sfxPlayer.play(DeviceFileSource(AssetService.audioPathSync('freespin.mp3')));
      await _sfxPlayer.setVolume(1.0);
    } catch (e) {
      debugPrint('Error playing freespin sound: $e');
    }
  }

  Future<void> _playWinSound() async {
    if (_isMuted) return;
    try {
      await _sfxPlayer.stop();
      await _sfxPlayer.play(DeviceFileSource(AssetService.audioPathSync('win.mp3')));
      await _sfxPlayer.setVolume(1.0);
    } catch (e) {
      debugPrint('Error playing win sound: $e');
    }
  }

  Future<void> _playLoseSound() async {
    if (_isMuted) return;
    try {
      await _sfxPlayer.stop();
      await _sfxPlayer.play(DeviceFileSource(AssetService.audioPathSync('lose.mp3')));
      await _sfxPlayer.setVolume(1.0);
    } catch (e) {
      debugPrint('Error playing lose sound: $e');
    }
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      await _bgmPlayer.setVolume(0);
      await _sfxPlayer.setVolume(0);
    } else {
      await _bgmPlayer.setVolume(1.0);
      await _sfxPlayer.setVolume(1.0);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 🕹️ CORE LOGIC & API
  // ─────────────────────────────────────────────────────────────

  Future<void> _loadSaldo() async {
    try {
      final res = await http.get(Uri.parse("${ConfigService.baseUrl}/getSaldo?key=${widget.sessionKey}"));
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        setState(() {
          saldo = (data["saldo"] as num).toInt();
          freeSpin = (data["freeSpin"] as num? ?? 0).toInt();
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _spin({bool useFree = false}) async {
    if (_isSpinning) return;
    final betAmount = int.tryParse(_betController.text) ?? 100;

    if (!useFree && betAmount > saldo) {
      _showSnack("Saldo tidak cukup!");
      _stopAutoPlay();
      return;
    }

    setState(() {
      _isSpinning = true;
      _resultMsg = "";
    });

    // 🔥 PLAY SPIN SOUND (bedakan free spin vs spin biasa)
    if (useFree) {
      await _playFreeSpinSound();
    } else {
      await _playSpinSound();
    }

    _startSpinAnimation();

    try {
      final url = useFree 
          ? "${ConfigService.baseUrl}/spinSlot?key=${widget.sessionKey}&bet=$betAmount&free=true"
          : "${ConfigService.baseUrl}/spinSlot?key=${widget.sessionKey}&bet=$betAmount";
      
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      await Future.delayed(const Duration(milliseconds: 1500));

      if (data["valid"] == true) {
        final isWin = data["win"] == true;
        final payout = (data["payout"] as num? ?? 0).toInt();
        
        setState(() {
          reels = List<String>.from(data["reels"]);
          saldo = (data["saldo"] as num).toInt();
          freeSpin = (data["freeSpin"] as num? ?? 0).toInt();
          _isWin = isWin;
          _isSkullResult = data["isSkull"] == true;
          _lastPayout = payout;
          _resultMsg = isWin ? "WIN +${_formatRupiah(payout)}" : "TRY AGAIN";
          _isSpinning = false;
        });
        
        // 🔥 PLAY WIN/LOSE SOUND
        if (isWin) {
          HapticFeedback.heavyImpact();
          await _playWinSound();
          _submitToLeaderboard(score: payout, win: true);
        } else {
          await _playLoseSound();
        }
      }
    } catch (e) {
      setState(() => _isSpinning = false);
    }
  }


  Future<void> _submitToLeaderboard({required int score, required bool win}) async {
    if (widget.username.isEmpty) return;
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/games/leaderboard/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'gameName': 'Slot Machine',
          'score': score,
          'win': win,
          'icon': '🎰',
        }),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  void _startSpinAnimation() {
    Future.doWhile(() async {
      if (!_isSpinning) return false;
      setState(() {
        spinningReels = List.generate(3, (_) => allSymbols[_random.nextInt(allSymbols.length)]);
      });
      await Future.delayed(const Duration(milliseconds: 100));
      return _isSpinning;
    });
  }

  void _startAutoPlay() {
    setState(() {
      _isAutoPlay = true;
      _autoPlayRemaining = _autoPlayCount;
    });
    _runAutoTurn();
  }

  void _stopAutoPlay() {
    _autoPlayTimer?.cancel();
    setState(() => _isAutoPlay = false);
  }

  void _runAutoTurn() async {
    if (!_isAutoPlay || _autoPlayRemaining <= 0) {
      _stopAutoPlay();
      return;
    }
    await _spin();
    _autoPlayRemaining--;
    _autoPlayTimer = Timer(const Duration(seconds: 1), _runAutoTurn);
  }

  // ─────────────────────────────────────────────────────────────
  // 💎 UI BUILDERS
  // ─────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kDark,
      body: _isLoading 
          ? const Center(child: CircularProgressIndicator(color: _kGold))
          : SafeArea(
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          _buildBalanceCard(),
                          const SizedBox(height: 25),
                          _buildCasinoMachine(),
                          const SizedBox(height: 20),
                          if (_resultMsg.isNotEmpty) _buildResultBanner(),
                          const SizedBox(height: 25),
                          _buildBetControls(),
                          const SizedBox(height: 25),
                          _buildMainActionButtons(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: _kDarkCard,
        border: Border(bottom: BorderSide(color: _kGoldDark, width: 0.5)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text("LUCKY SLOT", style: TextStyle(color: _kGold, fontWeight: FontWeight.bold, letterSpacing: 2)),
          Row(
            children: [
              // 🔥 MUTE BUTTON
              GestureDetector(
                onTap: _toggleMute,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _isMuted ? _kRed.withOpacity(0.2) : _kGold.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _isMuted ? _kRed : _kGold, width: 0.5),
                  ),
                  child: Icon(
                    _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                    color: _isMuted ? _kRed : _kGold,
                    size: 18,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(widget.username.toUpperCase(), style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBalanceCard() {
    final role = widget.role.toLowerCase();
    final isPrivileged = role == 'owner' || role == 'vip' || role == 'reseller';
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: _kDarkCard,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: _kGold.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("TOTAL SALDO", style: TextStyle(color: Colors.white38, fontSize: 10)),
                  Text("Rp ${_formatRupiah(saldo)}", style: const TextStyle(color: _kGold, fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
              Row(
                children: [
                  if (freeSpin > 0)
                    Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: _kPurple, borderRadius: BorderRadius.circular(8)),
                      child: Text("FREE: $freeSpin", style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                  if (isPrivileged)
                    GestureDetector(
                      onTap: _showTopUpDialog,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFF7B2FBE), Color(0xFF9B4FDE)]),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [BoxShadow(color: _kPurple.withOpacity(0.4), blurRadius: 8)],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.add_card, color: Colors.white, size: 14),
                            SizedBox(width: 4),
                            Text("TOP UP", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showTopUpDialog() {
    final usernameCtrl = TextEditingController();
    final amountCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _kDarkCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: _kGold.withOpacity(0.3))),
        title: const Row(
          children: [
            Icon(Icons.add_card, color: _kGold, size: 20),
            SizedBox(width: 8),
            Text("TOP UP SALDO", style: TextStyle(color: _kGold, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: usernameCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Username",
                labelStyle: const TextStyle(color: Colors.white38),
                hintText: "Username target",
                hintStyle: const TextStyle(color: Colors.white24),
                prefixIcon: const Icon(Icons.person_outline, color: Colors.white38, size: 18),
                filled: true,
                fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.white12)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.white12)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _kGold)),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: amountCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: _kGold),
              decoration: InputDecoration(
                labelText: "Jumlah",
                labelStyle: const TextStyle(color: Colors.white38),
                hintText: "Contoh: 5000",
                hintStyle: const TextStyle(color: Colors.white24),
                prefixIcon: const Icon(Icons.monetization_on_outlined, color: Colors.white38, size: 18),
                filled: true,
                fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.white12)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.white12)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _kGold)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("BATAL", style: TextStyle(color: Colors.white38)),
          ),
          ElevatedButton(
            onPressed: () async {
              final username = usernameCtrl.text.trim();
              final amount = int.tryParse(amountCtrl.text.trim()) ?? 0;
              if (username.isEmpty || amount <= 0) {
                _showSnack("Username & jumlah harus diisi!");
                return;
              }
              Navigator.pop(ctx);
              await _doTopUp(username, amount);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kGold,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text("TOP UP", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _doTopUp(String targetUsername, int amount) async {
    try {
      final res = await http.get(Uri.parse(
        "${ConfigService.baseUrl}/topUpSaldo?key=${widget.sessionKey}&username=$targetUsername&amount=$amount"
      )).timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        _showSnack("✅ Top up Rp ${_formatRupiah(amount)} ke $targetUsername berhasil!");
      } else {
        _showSnack("❌ ${data["message"] ?? "Top up gagal"}");
      }
    } catch (e) {
      _showSnack("❌ Koneksi error");
    }
  }

  Widget _buildCasinoMachine() {
    final display = _isSpinning ? spinningReels : reels;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _kGoldDark, width: 3),
        boxShadow: [BoxShadow(color: _kGold.withOpacity(0.1), blurRadius: 30)],
      ),
      child: Column(
        children: [
          _buildNeonLights(),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(3, (i) => _buildReelItem(display[i])),
          ),
          const SizedBox(height: 15),
          _buildNeonLights(reverse: true),
        ],
      ),
    );
  }

  Widget _buildReelItem(String symbol) {
    return Container(
      width: 85,
      height: 110,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: _kGold.withOpacity(0.2)),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black, Colors.grey.shade900, Colors.black],
        ),
      ),
      child: Center(
        child: Text(symbol, style: const TextStyle(fontSize: 45)),
      ),
    );
  }

  Widget _buildNeonLights({bool reverse = false}) {
    return AnimatedBuilder(
      animation: _lightCtrl,
      builder: (context, child) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(8, (index) {
            bool isOn = (index % 2 == 0) ? _lightCtrl.value > 0.5 : _lightCtrl.value <= 0.5;
            if (reverse) isOn = !isOn;
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: 6, height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isOn ? _kGold : Colors.white10,
                boxShadow: isOn ? [const BoxShadow(color: _kGold, blurRadius: 5)] : [],
              ),
            );
          }),
        );
      },
    );
  }

  Widget _buildResultBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _isWin ? _kGold.withOpacity(0.1) : const Color(0x0DFFFFFF),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _isWin ? _kGold : Colors.white12),
      ),
      child: Text(
        _resultMsg,
        textAlign: TextAlign.center,
        style: TextStyle(color: _isWin ? _kGold : Colors.white70, fontWeight: FontWeight.bold, letterSpacing: 2),
      ),
    );
  }

  Widget _buildBetControls() {
    return Column(
      children: [
        const Text("TARUHAN", style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: 2)),
        const SizedBox(height: 10),
        TextField(
          controller: _betController,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          style: const TextStyle(color: _kGold, fontSize: 24, fontWeight: FontWeight.bold),
          decoration: const InputDecoration(
            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: _kGoldDark)),
            focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: _kGold)),
          ),
        ),
      ],
    );
  }

  Widget _buildMainActionButtons() {
    return Row(
      children: [
        Expanded(
          child: _buildSideButton(
            _isAutoPlay ? "STOP" : "AUTO",
            _isAutoPlay ? _kRed : _kPurple,
            () => _isAutoPlay ? _stopAutoPlay() : _startAutoPlay(),
          ),
        ),
        const SizedBox(width: 15),
        Expanded(
          flex: 2,
          child: GestureDetector(
            onTap: _isSpinning ? null : () => _spin(),
            child: Container(
              height: 65,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_kGoldDark, _kGold, _kGoldLight]),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: _kGold.withOpacity(0.3), blurRadius: 15)],
              ),
              child: Center(
                child: Text(
                  _isSpinning ? "SPINNING..." : "SPIN",
                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 2),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSideButton(String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 65,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: color),
        ),
        child: Center(
          child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: _kRed));
  }

  String _formatRupiah(int n) => n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');

  @override
  void dispose() {
    _stopAutoPlay();
    _lightCtrl.dispose();
    _glowCtrl.dispose();
    _betController.dispose();
    _bgmPlayer.dispose();
    _sfxPlayer.dispose();
    super.dispose();
  }
}