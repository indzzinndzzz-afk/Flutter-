import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'theme_provider.dart';
import 'chat_theme.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'developer_page.dart';
import 'landing.dart';
import 'bug_sender.dart';
import 'adzan_service.dart';
import 'iqc_page.dart';
import 'pou_memory_page.dart';
import 'shop_module.dart';
import 'kisah_nabi_page.dart';
import 'config_service.dart';
import 'asset_service.dart';
import 'download_assets_dialog.dart';
import 'control_panel.dart';

// ============================================================
//  FCM BACKGROUND HANDLER
// ============================================================
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint('[FCM BG] Notif diterima: ${message.notification?.title}');
}

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ============================================================
//  CHANNEL IDs
// ============================================================
const String chMaintenance     = 'TRICKSTER_broadcast';
const String chMaintenanceDone = 'TRICKSTER_broadcast';
const String chBroadcast       = 'TRICKSTER_broadcast';
const String chUpdate          = 'TRICKSTER_broadcast';

// Pilih channel berdasarkan type FCM
String _channelForType(String type) {
  switch (type) {
    case 'maintenance':      return chMaintenance;
    case 'maintenance_done': return chMaintenanceDone;
    case 'broadcast':        return chBroadcast;
    case 'app_update':       return chUpdate;
    default:                 return chBroadcast;
  }
}

// Pilih sound berdasarkan type FCM
String _soundForType(String type) {
  switch (type) {
    case 'maintenance':      return 'lagi_maintace';
    case 'maintenance_done': return 'sesudah_ga_mainatce';
    case 'broadcast':        return 'broadcast';
    case 'app_update':       return 'notif_apk_update';
    default:                 return 'broadcast';
  }
}

// ============================================================
//  VERSION HELPER
// ============================================================
bool _isNewer(String latest, String current) {
  try {
    final l = latest.split('.').map(int.parse).toList();
    final c = current.split('.').map(int.parse).toList();
    for (int i = 0; i < 3; i++) {
      final lv = i < l.length ? l[i] : 0;
      final cv = i < c.length ? c[i] : 0;
      if (lv > cv) return true;
      if (lv < cv) return false;
    }
    return false;
  } catch (_) {
    return false;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await initializeDateFormatting('id', null);
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await ConfigService.init();
  await AssetService.init();

  // ── Setup local notifications ──
  const AndroidInitializationSettings androidSettings =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  await flutterLocalNotificationsPlugin.initialize(
    const InitializationSettings(android: androidSettings),
    onDidReceiveNotificationResponse: (details) async {
      final payload = details.payload;
      if (payload != null) {
        final data = jsonDecode(payload);
        final ctx = navigatorKey.currentContext;
        if (ctx != null && data['type'] == 'app_update') {
          final info = await PackageInfo.fromPlatform();
          if (_isNewer(data['version'] ?? '0.0.0', info.version)) {
            _showUpdateFromNotif(ctx, data);
          }
        }
      }
    },
  );

  // ── Buat 4 channel dengan sound masing-masing ──
  // Taruh semua file di: android/app/src/main/res/raw/
  final impl = flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  await impl?.createNotificationChannel(const AndroidNotificationChannel(
    'TRICKSTER_broadcast',
    'Notifikasi',
    description: 'Notifikasi dari admin',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    sound: RawResourceAndroidNotificationSound('broadcast'),
  ));

  // ── Channel khusus chat ──
  await impl?.createNotificationChannel(const AndroidNotificationChannel(
    'chat_channel',
    'Pesan Chat',
    description: 'Notifikasi pesan masuk dari user lain',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
  ));

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ThemeProvider()),
        ChangeNotifierProvider(create: (context) => ChatThemeProvider()),
        ChangeNotifierProvider(create: (context) => ShopProvider()),
      ],
      child: const MyApp(),
    ),
  );

  WidgetsBinding.instance.addPostFrameCallback((_) async {
    await AdzanService().init();

    await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    await FirebaseMessaging.instance.subscribeToTopic('app_updates');

    // ── Re-register FCM token tiap app dibuka ──
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('sessionKey') ?? '';
      if (sessionKey.isNotEmpty) {
        final fcmToken = await FirebaseMessaging.instance.getToken();
        if (fcmToken != null && fcmToken.isNotEmpty) {
          await http.post(
            Uri.parse("${ConfigService.baseUrl}/api/fcm/token"),
            body: {"key": sessionKey, "fcmToken": fcmToken},
          ).timeout(const Duration(seconds: 5));
        }
      }
    } catch (_) {}

    // FCM foreground — pilih channel + sound sesuai type
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      final notif = message.notification;
      final data = message.data;

      if (notif != null) {
        final type      = data['type'] ?? 'broadcast';
        final channelId = _channelForType(type);
        final sound     = _soundForType(type);

        final androidDetails = AndroidNotificationDetails(
          channelId,
          channelId,
          importance: Importance.max,
          priority: Priority.high,
          playSound: type != 'new_message', // chat pake default sound
          sound: type != 'new_message' ? RawResourceAndroidNotificationSound(sound) : null,
          showWhen: true,
        );

        await flutterLocalNotificationsPlugin.show(
          DateTime.now().millisecondsSinceEpoch ~/ 1000,
          notif.title,
          notif.body,
          NotificationDetails(android: androidDetails),
          payload: jsonEncode(data),
        );
      }

      final ctx = navigatorKey.currentContext;
      if (ctx != null && data['type'] == 'app_update') {
        final info = await PackageInfo.fromPlatform();
        if (_isNewer(data['version'] ?? '0.0.0', info.version)) {
          _showUpdateFromNotif(ctx, data);
        }
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      final data = message.data;
      final ctx = navigatorKey.currentContext;
      if (ctx == null) return;
      if (data['type'] == 'app_update') {
        final info = await PackageInfo.fromPlatform();
        if (_isNewer(data['version'] ?? '0.0.0', info.version)) {
          _showUpdateFromNotif(ctx, data);
        }
      }
    });

    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null && initialMessage.data['type'] == 'app_update') {
      final ctx = navigatorKey.currentContext;
      if (ctx != null) {
        final info = await PackageInfo.fromPlatform();
        if (_isNewer(initialMessage.data['version'] ?? '0.0.0', info.version)) {
          _showUpdateFromNotif(ctx, initialMessage.data);
        }
      }
    }
  });
}

void _showUpdateFromNotif(BuildContext context, Map<String, dynamic> data) {
  final apkUrl     = data['apk_url'] ?? '';
  final version    = data['version'] ?? '';
  final changelog  = data['changelog'] ?? '';
  final forceUpdate = data['force_update'] == 'true';

  if (apkUrl.isEmpty) return;

  showDialog(
    context: context,
    barrierDismissible: !forceUpdate,
    builder: (_) => PopScope(
      canPop: !forceUpdate,
      child: AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFFFF2D2D), width: 1),
        ),
        title: Row(children: [
          const Text(' '),
          Expanded(
            child: Text('Update v$version',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
          ),
        ]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(changelog,
                style: const TextStyle(color: Color(0xFF888888), fontSize: 13)),
            if (forceUpdate) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD600).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: const Color(0xFFFFD600).withValues(alpha: 0.4)),
                ),
                child: const Text(
                  '️ Update ini wajib. Kamu tidak bisa skip.',
                  style: TextStyle(color: Color(0xFFFFD600), fontSize: 12),
                ),
              ),
            ],
          ],
        ),
        actions: [
          if (!forceUpdate)
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Nanti',
                  style: TextStyle(color: Color(0xFF555555))),
            ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF2D2D),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            onPressed: () async {
              final uri = Uri.parse(apkUrl);
              if (await canLaunchUrl(uri)) {
                launchUrl(uri, mode: LaunchMode.externalApplication);
              }
            },
            child: const Text('️ Download Sekarang',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    ),
  );
}

// ============================================================
//  AUTH GATE
// ============================================================
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) Navigator.pushReplacementNamed(context, '/landing');
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF0C0C0E),
      body: Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFECECF0)),
          strokeWidth: 2,
        ),
      ),
    );
  }
}

// ============================================================
//  LOGOUT HELPER
// ============================================================
Future<void> logout(BuildContext context) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.clear();
  if (context.mounted) {
    Navigator.pushNamedAndRemoveUntil(context, '/landing', (_) => false);
  }
}

// ============================================================
//  MY APP
// ============================================================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      navigatorKey: navigatorKey,
      navigatorObservers: [dashboardRouteObserver],
      debugShowCheckedModeBanner: false,
      title: 'TRICKSTER X AREA',
      theme: ThemeData(
        brightness:
            themeProvider.isDarkMode ? Brightness.dark : Brightness.light,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor:
            themeProvider.isDarkMode ? Colors.black : Colors.white,
        primaryColor: themeProvider.primaryColor,
        colorScheme: ColorScheme.fromSeed(
          seedColor: themeProvider.primaryColor,
          brightness:
              themeProvider.isDarkMode ? Brightness.dark : Brightness.light,
        ).copyWith(
          primary: themeProvider.primaryColor,
          secondary: themeProvider.accentColor,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: themeProvider.primaryColor,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: themeProvider.accentColor,
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: themeProvider.primaryColor),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: themeProvider.primaryColor,
            foregroundColor: Colors.white,
          ),
        ),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const AuthGate());
          case '/landing':
            return MaterialPageRoute(builder: (_) => const LandingPage());
          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());
          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );
          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );
          case '/bug-sender':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
                role: args['role'],
              ),
            );
          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(
                keyToken: args['keyToken'],
                userRole: args['userRole'] ?? 'reseller',
                username: args['username'] ?? '',
              ),
            );
          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(
                sessionKey: args['sessionKey'],
                userRole: args['userRole'] ?? 'owner',
                username: args['username'] ?? '',
              ),
            );
          case '/owner':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => OwnerPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
              ),
            );
          case '/developer':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DeveloperPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
              ),
            );
          case '/pou-memory':
            return MaterialPageRoute(builder: (_) => const PouMemoryPage());
          case '/shop':
            return MaterialPageRoute(builder: (_) => const ShopPage());
          case '/iqc':
            return MaterialPageRoute(builder: (_) => const IqcPage());
            case '/control_panel':
  final args = settings.arguments as Map<String, dynamic>?;
  return MaterialPageRoute(
    builder: (_) => ControlCenterPage(
      targetDevice: args?['targetDevice'],
      role: args?['role'] ?? 'member',
    ),
  );
          case '/kisah-nabi':
            return MaterialPageRoute(builder: (_) => const KisahNabiPage());
          case '/cart':
            return MaterialPageRoute(builder: (_) => const CartPage());
          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text("404 - Not Found")),
              ),
            );
        }
      },
    );
  }
}
