import 'dart:io';
import 'dart:convert';
import 'dart:isolate';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:archive/archive_io.dart';
import 'config_service.dart';

class AssetService {
  static const String _versionKey = 'assets_version';
  static const String _githubZipUrl =
      'https://github.com/alwaysZillxy/databasetrrrrr/releases/download/V2.0.0/app_assets.zip';

  static String? _assetsDir;

  static Future<String> get assetsDir async {
    if (_assetsDir != null) return _assetsDir!;
    final dir = await getApplicationDocumentsDirectory();
    _assetsDir = '${dir.path}/app_assets';
    return _assetsDir!;
  }

  static Future<void> init() async {
    await assetsDir;
  }

  static Future<bool> needsDownload() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final localVersion = prefs.getString(_versionKey) ?? '';
      final dir = await assetsDir;

      if (!Directory(dir).existsSync()) return true;

      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/assets/version'),
      ).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      return (data['version'] ?? '0.0.0') != localVersion;
    } catch (e) {
      final dir = await assetsDir;
      return !Directory(dir).existsSync();
    }
  }

  static Future<void> downloadAssets({
    required Function(double progress, String status) onProgress,
    required Function() onComplete,
    required Function(String error) onError,
  }) async {
    try {
      final dir = await assetsDir;
      final tempDir = await getTemporaryDirectory();
      final zipPath = '${tempDir.path}/app_assets.zip';

      onProgress(0.0, 'Menghubungkan ke GitHub...');

      final request = http.Request('GET', Uri.parse(_githubZipUrl));
      final response = await request.send().timeout(const Duration(minutes: 10));

      if (response.statusCode != 200) {
        onError('Gagal download: HTTP ${response.statusCode}');
        return;
      }

      final totalBytes = response.contentLength ?? 0;
      int receivedBytes = 0;
      final sink = File(zipPath).openWrite();

      await for (final chunk in response.stream) {
        sink.add(chunk);
        receivedBytes += chunk.length;
        if (totalBytes > 0) {
          final progress = receivedBytes / totalBytes * 0.85;
          final recvMb = (receivedBytes / 1024 / 1024).toStringAsFixed(1);
          final totalMb = (totalBytes / 1024 / 1024).toStringAsFixed(1);
          onProgress(progress, 'Mengunduh... $recvMb / $totalMb MB');
        } else {
          final recvMb = (receivedBytes / 1024 / 1024).toStringAsFixed(1);
          onProgress(0.5, 'Mengunduh... $recvMb MB');
        }
      }
      await sink.close();

      onProgress(0.87, 'Mengekstrak assets...');

      final dirPath = dir;
      await Isolate.run(() {
        final bytes = File(zipPath).readAsBytesSync();
        final archive = ZipDecoder().decodeBytes(bytes);
        for (final file in archive) {
          final parts = file.name.split('/');
          if (parts.length < 2) continue;
          final relativePath = parts.sublist(1).join('/');
          if (relativePath.isEmpty) continue;

          final outPath = '$dirPath/$relativePath';
          if (file.isFile) {
            File(outPath)
              ..createSync(recursive: true)
              ..writeAsBytesSync(file.content as List<int>);
          } else {
            Directory(outPath).createSync(recursive: true);
          }
        }
        File(zipPath).deleteSync();
      });

      onProgress(0.97, 'Menyimpan versi...');

      try {
        final verRes = await http.get(
          Uri.parse('${ConfigService.baseUrl}/api/assets/version'),
        ).timeout(const Duration(seconds: 8));
        final verData = jsonDecode(verRes.body);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_versionKey, verData['version'] ?? '1.0.0');
      } catch (_) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_versionKey, '1.0.0');
      }

      onProgress(1.0, 'Selesai!');
      onComplete();
    } catch (e) {
      onError(e.toString());
    }
  }

  // ── PATH HELPERS ──
  static Future<String> imagePath(String filename) async {
    final dir = await assetsDir;
    return '$dir/images/$filename';
  }

  static Future<String> audioPath(String filename) async {
    final dir = await assetsDir;
    return '$dir/audio/$filename';
  }

  static Future<String> videoPath(String filename) async {
    final dir = await assetsDir;
    return '$dir/videos/$filename';
  }

  // ── SYNC PATH ──
  static String imagePathSync(String filename) {
    return '${_assetsDir ?? ''}/images/$filename';
  }

  static String audioPathSync(String filename) {
    return '${_assetsDir ?? ''}/audio/$filename';
  }

  static String videoPathSync(String filename) {
    return '${_assetsDir ?? ''}/videos/$filename';
  }

  // ── WIDGET HELPERS ──
  static Widget image(
    String filename, {
    double? width,
    double? height,
    BoxFit fit = BoxFit.cover,
    Widget Function(BuildContext, Object, StackTrace?)? errorBuilder,
  }) {
    if (_assetsDir != null) {
      final f = File('$_assetsDir/images/$filename');
      if (f.existsSync()) {
        return Image.file(
          f,
          width: width,
          height: height,
          fit: fit,
          errorBuilder: errorBuilder,
        );
      }
    }
    return SizedBox(width: width, height: height);
  }

  // Non-const, jangan dipake di const context
  static ImageProvider imageProvider(String filename) {
    if (_assetsDir != null) {
      final f = File('$_assetsDir/images/$filename');
      if (f.existsSync()) return FileImage(f);
    }
    return const AssetImage('assets/icon/icon.jpg');
  }
}
