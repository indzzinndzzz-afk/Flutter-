// lib/jadi_hitam_page.dart
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:gallery_saver_plus/gallery_saver.dart';

class JadiHitamPage extends StatefulWidget {
  const JadiHitamPage({super.key});

  @override
  State<JadiHitamPage> createState() => _JadiHitamPageState();
}

class _JadiHitamPageState extends State<JadiHitamPage>
    with TickerProviderStateMixin {
  // ─── State ───────────────────────────────────────────────────
  File? _selectedImage;
  String? _resultUrl;
  bool _isLoading = false;
  bool _isSaving = false;
  String _statusText = '';
  final String _apiKey = 'Miwa';
  final ImagePicker _picker = ImagePicker();

  // ─── Animations ──────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // ─── Colors ──────────────────────────────────────────────────
  static const _bg       = Color(0xFF0A0A0A);
  static const _surface  = Color(0xFF1A1A1A);
  static const _card     = Color(0xFF222222);
  static const _accent   = Color(0xFF444444);
  static const _white    = Colors.white;
  static const _grey     = Color(0xFF888888);

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200), lowerBound: 0.95, upperBound: 1.0)
      ..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ─── Pick Image ───────────────────────────────────────────────
  Future<void> _pickImage(ImageSource source) async {
    final XFile? picked = await _picker.pickImage(source: source, imageQuality: 100);
    if (picked != null) {
      setState(() {
        _selectedImage = File(picked.path);
        _resultUrl = null;
        _statusText = '';
      });
      _fadeCtrl.reset();
      _fadeCtrl.forward();
    }
  }

  // ─── Upload to filn.pp.ua ────────────────────────────────────
  Future<String?> _uploadImage(File file) async {
    setState(() => _statusText = '📤 Mengupload foto...');
    try {
      final request = http.MultipartRequest('POST', Uri.parse('https://filn.pp.ua/api/upload'));
      request.files.add(await http.MultipartFile.fromPath('files', file.path));
      final response = await request.send();
      final body = await response.stream.bytesToString();
      final data = jsonDecode(body);
      if (data['success'] == true && data['uploaded'] != null && (data['uploaded'] as List).isNotEmpty) {
        return data['uploaded'][0]['url'];
      }
    } catch (e) {
      debugPrint('Upload error: $e');
    }
    return null;
  }

  // ─── Process jadi hitam ───────────────────────────────────────
  Future<void> _process() async {
    if (_selectedImage == null) return;
    HapticFeedback.mediumImpact();
    setState(() {
      _isLoading = true;
      _resultUrl = null;
      _statusText = '⏳ Memproses...';
    });
    try {
      final uploadedUrl = await _uploadImage(_selectedImage!);
      if (uploadedUrl == null) {
        _showError('Gagal upload foto. Coba lagi.');
        return;
      }

      setState(() => _statusText = '🖤 Menggelapkan foto...');
      final uri = Uri.parse(
        'https://api.botcahx.eu.org/api/maker/jadihitam?apikey=$_apiKey&url=${Uri.encodeComponent(uploadedUrl)}',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 60));
      final ct = res.headers['content-type'] ?? '';

      if (ct.contains('image')) {
        // API return gambar langsung → upload lagi buat dapet URL
        final tempFile = File('${Directory.systemTemp.path}/jh_${DateTime.now().millisecondsSinceEpoch}.jpg');
        await tempFile.writeAsBytes(res.bodyBytes);
        final resultUrl = await _uploadImage(tempFile);
        await tempFile.delete();
        if (resultUrl != null) {
          _fadeCtrl.reset();
          _fadeCtrl.forward();
          HapticFeedback.heavyImpact();
          setState(() {
            _resultUrl = resultUrl;
            _statusText = '✅ Selesai!';
          });
        } else {
          // Simpan bytes langsung ke galeri tanpa URL
          final saveFile = File('${Directory.systemTemp.path}/jh_save_${DateTime.now().millisecondsSinceEpoch}.jpg');
          await saveFile.writeAsBytes(res.bodyBytes);
          final success = await GallerySaver.saveImage(saveFile.path, albumName: 'Jadi Hitam');
          await saveFile.delete();
          if (success == true && mounted) {
            HapticFeedback.heavyImpact();
            _showSnackSuccess('Foto hitam tersimpan ke galeri!');
            setState(() => _statusText = '✅ Tersimpan ke galeri!');
          } else {
            _showError('Gagal menyimpan hasil.');
          }
        }
      } else {
        // API return JSON
        final data = jsonDecode(res.body);
        final imageUrl = data['result'] ?? data['url'] ?? data['image'] ?? data['image_url'];
        if (imageUrl != null) {
          _fadeCtrl.reset();
          _fadeCtrl.forward();
          HapticFeedback.heavyImpact();
          setState(() {
            _resultUrl = imageUrl.toString();
            _statusText = '✅ Selesai!';
          });
        } else {
          _showError(data['message']?.toString() ?? 'Gagal memproses foto.');
        }
      }
    } catch (e) {
      _showError('Terjadi error: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // ─── Save to Gallery ─────────────────────────────────────────
  Future<void> _saveToGallery() async {
    if (_resultUrl == null) return;
    HapticFeedback.mediumImpact();
    setState(() => _isSaving = true);
    try {
      final res = await http.get(Uri.parse(_resultUrl!));
      final tempFile = File('${Directory.systemTemp.path}/jh_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await tempFile.writeAsBytes(res.bodyBytes);
      final success = await GallerySaver.saveImage(tempFile.path, albumName: 'Jadi Hitam');
      await tempFile.delete();
      if (success == true && mounted) {
        HapticFeedback.heavyImpact();
        _showSnackSuccess('Foto tersimpan ke galeri!');
      } else {
        _showError('Gagal menyimpan foto.');
      }
    } catch (e) {
      _showError('Error saat menyimpan: $e');
    } finally {
      setState(() => _isSaving = false);
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    setState(() { _statusText = ''; _isLoading = false; });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.error_outline, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: Colors.red.shade800,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  void _showSnackSuccess(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.check_circle_outline, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Text(msg, style: const TextStyle(color: Colors.white)),
      ]),
      backgroundColor: Colors.grey.shade800,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  // ─── UI ──────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'JADI HITAM',
          style: TextStyle(
            color: _white,
            fontFamily: 'Orbitron',
            fontSize: 16,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // ─── Image Preview Area ───────────────────────
              _buildImageArea(),
              const SizedBox(height: 20),

              // ─── Pick Image Buttons ───────────────────────
              if (_resultUrl == null) ...[
                Row(children: [
                  Expanded(child: _buildPickBtn(
                    icon: Icons.photo_library_rounded,
                    label: 'Galeri',
                    onTap: () => _pickImage(ImageSource.gallery),
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: _buildPickBtn(
                    icon: Icons.camera_alt_rounded,
                    label: 'Kamera',
                    onTap: () => _pickImage(ImageSource.camera),
                  )),
                ]),
                const SizedBox(height: 16),
              ],

              // ─── Status ───────────────────────────────────
              if (_statusText.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: _surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _accent),
                  ),
                  child: Text(
                    _statusText,
                    style: const TextStyle(color: _white, fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                ),

              // ─── Process Button ───────────────────────────
              if (_selectedImage != null && _resultUrl == null)
                _buildMainBtn(
                  label: _isLoading ? 'Memproses...' : '🖤  JADIKAN HITAM',
                  onTap: _isLoading ? null : _process,
                  isLoading: _isLoading,
                ),

              // ─── Result Actions ───────────────────────────
              if (_resultUrl != null) ...[
                Row(children: [
                  Expanded(child: _buildPickBtn(
                    icon: Icons.refresh_rounded,
                    label: 'Foto Baru',
                    onTap: () => setState(() {
                      _selectedImage = null;
                      _resultUrl = null;
                      _statusText = '';
                    }),
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: _buildMainBtn(
                    label: _isSaving ? 'Menyimpan...' : '⬇  Simpan Galeri',
                    onTap: _isSaving ? null : _saveToGallery,
                    isLoading: _isSaving,
                    small: true,
                  )),
                ]),
              ],

              const SizedBox(height: 32),

              // ─── Info ─────────────────────────────────────
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _accent.withOpacity(0.5)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline_rounded, color: _grey, size: 16),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Upload foto → diproses oleh AI → hasil foto jadi lebih gelap/hitam. Hasil bisa disimpan ke galeri.',
                        style: TextStyle(color: _grey, fontSize: 11, height: 1.5),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Image Area ───────────────────────────────────────────────
  Widget _buildImageArea() {
    return Container(
      height: 320,
      width: double.infinity,
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _accent, width: 1.5),
      ),
      clipBehavior: Clip.hardEdge,
      child: _isLoading
          ? _buildLoadingState()
          : _resultUrl != null
              ? _buildResultImage()
              : _selectedImage != null
                  ? _buildSelectedImage()
                  : _buildEmptyState(),
    );
  }

  Widget _buildEmptyState() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ScaleTransition(
          scale: _pulseAnim,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _card,
              shape: BoxShape.circle,
              border: Border.all(color: _accent),
            ),
            child: const Icon(Icons.add_photo_alternate_rounded, color: _grey, size: 48),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Pilih foto dari galeri atau kamera', style: TextStyle(color: _grey, fontSize: 13)),
        const SizedBox(height: 4),
        const Text('Foto akan diubah jadi gelap/hitam', style: TextStyle(color: Color(0xFF555555), fontSize: 11)),
      ],
    );
  }

  Widget _buildSelectedImage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.file(_selectedImage!, fit: BoxFit.cover),
          Positioned(
            bottom: 10, right: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('ORIGINAL', style: TextStyle(color: _grey, fontSize: 10, letterSpacing: 1)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultImage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            _resultUrl!,
            fit: BoxFit.cover,
            loadingBuilder: (_, child, progress) => progress == null
                ? child
                : const Center(child: CircularProgressIndicator(color: _white, strokeWidth: 2)),
            errorBuilder: (_, __, ___) => const Center(
              child: Icon(Icons.broken_image_rounded, color: _grey, size: 48),
            ),
          ),
          Positioned(
            bottom: 10, right: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(children: [
                Icon(Icons.auto_awesome, color: _white, size: 10),
                SizedBox(width: 4),
                Text('HASIL', style: TextStyle(color: _white, fontSize: 10, letterSpacing: 1, fontWeight: FontWeight.bold)),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(
          width: 48, height: 48,
          child: CircularProgressIndicator(color: _white, strokeWidth: 2),
        ),
        const SizedBox(height: 20),
        Text(_statusText, style: const TextStyle(color: _grey, fontSize: 13)),
      ],
    );
  }

  Widget _buildPickBtn({required IconData icon, required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: _surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _accent),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _white, size: 18),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildMainBtn({
    required String label,
    required VoidCallback? onTap,
    required bool isLoading,
    bool small = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: small ? 14 : 16),
        decoration: BoxDecoration(
          color: onTap == null ? _accent : _white,
          borderRadius: BorderRadius.circular(14),
        ),
        child: isLoading
            ? const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _bg)))
            : Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: onTap == null ? _grey : _bg,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                ),
              ),
      ),
    );
  }
}
