import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'config_service.dart';

// ─── Service Icons / Colors ───────────────────────────────────────────────────

class _ServiceMeta {
  final Color color;
  final IconData icon;
  final String? logoUrl;
  const _ServiceMeta(this.color, this.icon, {this.logoUrl});
}

const _serviceMap = <String, _ServiceMeta>{
  'whatsapp':  _ServiceMeta(Color(0xFF25D366), Icons.chat,              logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/WhatsApp.svg/120px-WhatsApp.svg.png'),
  'telegram':  _ServiceMeta(Color(0xFF2AABEE), Icons.send,              logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Telegram_logo.svg/120px-Telegram_logo.svg.png'),
  'instagram': _ServiceMeta(Color(0xFFE1306C), Icons.camera_alt,        logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/120px-Instagram_icon.png'),
  'tiktok':    _ServiceMeta(Color(0xFF69C9D0), Icons.music_note,        logoUrl: 'https://sf-tb-sg.ibytedtos.com/obj/eden-sg/uhtyvueh7nulogpoguhm/tiktok-icon2.png'),
  'facebook':  _ServiceMeta(Color(0xFF1877F2), Icons.facebook,          logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/2023_Facebook_icon.svg/120px-2023_Facebook_icon.svg.png'),
  'twitter':   _ServiceMeta(Color(0xFF1DA1F2), Icons.alternate_email,   logoUrl: 'https://abs.twimg.com/favicons/twitter.3.ico'),
  'x.com':     _ServiceMeta(Color(0xFF000000), Icons.alternate_email,   logoUrl: 'https://abs.twimg.com/favicons/twitter.3.ico'),
  'google':    _ServiceMeta(Color(0xFFEA4335), Icons.g_mobiledata,      logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/120px-Google_%22G%22_logo.svg.png'),
  'gmail':     _ServiceMeta(Color(0xFFEA4335), Icons.email,             logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Gmail_icon_%282020%29.svg/120px-Gmail_icon_%282020%29.svg.png'),
  'line':      _ServiceMeta(Color(0xFF06C755), Icons.chat_bubble,       logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/LINE_logo.svg/120px-LINE_logo.svg.png'),
  'viber':     _ServiceMeta(Color(0xFF665CAC), Icons.phone_in_talk,     logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Viber_2017_icon.svg/120px-Viber_2017_icon.svg.png'),
  'snapchat':  _ServiceMeta(Color(0xFFFFFC00), Icons.camera,            logoUrl: 'https://upload.wikimedia.org/wikipedia/en/thumb/a/ad/Snapchat_logo.svg/120px-Snapchat_logo.svg.png'),
  'discord':   _ServiceMeta(Color(0xFF5865F2), Icons.headset_mic,       logoUrl: 'https://assets-global.website-files.com/6257adef93867e50d84d30e2/636e0a6a49cf127bf92de1e2_icon_clyde_blurple_RGB.png'),
  'shopee':    _ServiceMeta(Color(0xFFEE4D2D), Icons.shopping_bag,      logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Shopee.svg/120px-Shopee.svg.png'),
  'tokopedia': _ServiceMeta(Color(0xFF03AC0E), Icons.store,             logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Tokopedia_icon.svg/120px-Tokopedia_icon.svg.png'),
  'gojek':     _ServiceMeta(Color(0xFF00AA13), Icons.delivery_dining,   logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Gojek_logo_2019.svg/120px-Gojek_logo_2019.svg.png'),
  'grab':      _ServiceMeta(Color(0xFF00B14F), Icons.directions_car,    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Logo_Grab_%282019%29.svg/120px-Logo_Grab_%282019%29.svg.png'),
  'ovo':       _ServiceMeta(Color(0xFF4C3494), Icons.account_balance_wallet, logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo_ovo_purple.svg/120px-Logo_ovo_purple.svg.png'),
  'dana':      _ServiceMeta(Color(0xFF118EEA), Icons.account_balance_wallet, logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/Logo_dana_blue.svg/120px-Logo_dana_blue.svg.png'),
  'gopay':     _ServiceMeta(Color(0xFF00AA13), Icons.payment,           logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Gopay_logo.svg/120px-Gopay_logo.svg.png'),
  'lazada':    _ServiceMeta(Color(0xFF0F146D), Icons.shopping_bag,      logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Lazada_Logo.svg/120px-Lazada_Logo.svg.png'),
  'linkedin':  _ServiceMeta(Color(0xFF0A66C2), Icons.business,          logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/LinkedIn_logo_initials.png/120px-LinkedIn_logo_initials.png'),
  'twitter x': _ServiceMeta(Color(0xFF000000), Icons.alternate_email,  logoUrl: 'https://abs.twimg.com/favicons/twitter.3.ico'),
};

_ServiceMeta _getMeta(String name) {
  final key = name.toLowerCase();
  for (final e in _serviceMap.entries) {
    if (key.contains(e.key)) return e.value;
  }
  return const _ServiceMeta(Color(0xFF00E5FF), Icons.sim_card);
}

// ─── Harga markup — diambil dari /api/markup (dinamis) ───────────────────────
// Fallback dipakai kalau fetch gagal
const int _kFallbackPrice = 8000;
const String _kFallbackPriceFmt = 'Rp8.000';

// ─── Models ──────────────────────────────────────────────────────────────────

class RotpService {
  final String id;
  final String name;
  final String? logo;
  final int price;
  final String priceFormatted;
  final int stock;

  RotpService({
    required this.id,
    required this.name,
    this.logo,
    this.price = _kFallbackPrice,
    this.priceFormatted = _kFallbackPriceFmt,
    this.stock = 0,
  });

  factory RotpService.fromJson(Map<String, dynamic> j) => RotpService(
        id:             j['id']?.toString() ?? '',
        name:           j['name'] ?? '',
        logo:           j['logo'],
        price:          (j['price'] ?? _kFallbackPrice).toInt(),
        priceFormatted: j['price_formated'] ?? j['price_formatted'] ?? 'Rp${(j['price'] ?? _kFallbackPrice).toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}',
        stock:          (j['stock'] ?? 0).toInt(),
      );
}

class RotpNumber {
  final String numberId;
  final String providerId;
  final String operatorId;
  final String number;
  final int price;
  final String priceFormatted;
  final int stock;

  RotpNumber({
    required this.numberId,
    required this.providerId,
    required this.operatorId,
    required this.number,
    required this.price,
    required this.priceFormatted,
    this.stock = 0,
  });

  factory RotpNumber.fromJson(Map<String, dynamic> j) => RotpNumber(
        numberId:       j['number_id']?.toString()  ?? '',
        providerId:     j['provider_id']?.toString() ?? '',
        operatorId:     j['operator_id']?.toString() ?? '1',
        number:         j['number']?.toString()      ?? '',
        price:          (j['price'] ?? _kFallbackPrice).toInt(),
        priceFormatted: j['price_formatted'] ?? j['price_formated'] ?? _kFallbackPriceFmt,
        stock:          (j['stock'] ?? 0).toInt(),
      );
}

class RotpCountry {
  final String id;
  final String name;
  final String? flag;
  final String? code;
  final int stock;

  RotpCountry({required this.id, required this.name, this.flag, this.code, this.stock = 0});

  factory RotpCountry.fromJson(Map<String, dynamic> j) {
    // RumahOTP returns iso_code (e.g. 'ID'), OTPku returned numeric id ('6')
    final isoCode = j['iso_code']?.toString() ?? j['id']?.toString() ?? '';
    final idStr   = isoCode;
    final idNum   = _isoToId[isoCode.toUpperCase()] ?? (int.tryParse(isoCode) ?? -1);
    return RotpCountry(
      id:    idStr,
      name:  j['name']?.toString() ?? 'Country $idStr',
      flag:  _countryFlag(idNum),
      code:  j['code']?.toString() ?? isoCode,
      stock: (j['stock'] ?? 0).toInt(),
    );
  }

  static const _isoToId = <String, int>{
    'RU':0,'UA':1,'KZ':2,'CN':3,'PH':4,'MM':5,'ID':6,'MY':7,'KE':8,'TZ':9,
    'VN':10,'KG':11,'US':12,'IL':13,'HK':14,'PL':15,'GB':16,'MG':17,'CD':18,'NG':19,
    'MO':20,'EG':21,'IN':22,'IE':23,'KH':24,'LA':25,'HT':26,'CI':27,'GM':28,'RS':29,
    'YE':30,'ZA':31,'RO':32,'CO':33,'EE':34,'AZ':35,'CA':36,'MA':37,'GH':38,'AR':39,
    'UZ':40,'CM':41,'TD':42,'DE':43,'LT':44,'HR':45,'SE':46,'IQ':47,'NL':48,'LV':49,
    'AT':50,'BY':51,'TH':52,'SA':53,'MX':54,'TW':55,'ES':56,'IR':57,'DZ':58,'SI':59,
    'BD':60,'SN':61,'TR':62,'CZ':63,'LK':64,'PE':65,'PK':66,'NZ':67,'GN':68,'ML':69,
    'VE':70,'ET':71,'MN':72,'BR':73,'AF':74,'UG':75,'AO':76,'CY':77,'FR':78,'PG':79,
    'MZ':80,'NP':81,'BE':82,'BG':83,'HU':84,'MD':85,'IT':86,'PY':87,'HN':88,'TN':89,
    'NI':90,'BO':91,'CR':92,'GT':93,'AE':94,'ZW':95,'PR':96,'SD':97,'TG':98,'KW':99,
    'SV':100,'LY':101,'JM':102,'TT':103,'EC':104,'MR':105,'SO':106,'BJ':107,'SL':108,'JO':109,
    'PT':110,'BI':111,'BF':112,'ZM':113,'MW':114,'BT':115,'GY':116,'PA':117,'BH':118,'OM':119,
    'BW':120,'NA':121,'LS':122,'SZ':123,'RW':124,'LR':125,'NE':126,'SR':127,'TL':128,'QA':129,
    'BN':188,'SG':189,'JP':190,'KR':191,'AU':198,'GR':199,'CH':200,'DK':201,'FI':202,'NO':203,'IS':204,
  };

  static const _idToIso = <int, String>{
    0:'RU',1:'UA',2:'KZ',3:'CN',4:'PH',5:'MM',6:'ID',7:'MY',8:'KE',9:'TZ',
    10:'VN',11:'KG',12:'US',13:'IL',14:'HK',15:'PL',16:'GB',17:'MG',18:'CD',19:'NG',
    20:'MO',21:'EG',22:'IN',23:'IE',24:'KH',25:'LA',26:'HT',27:'CI',28:'GM',29:'RS',
    30:'YE',31:'ZA',32:'RO',33:'CO',34:'EE',35:'AZ',36:'CA',37:'MA',38:'GH',39:'AR',
    40:'UZ',41:'CM',42:'TD',43:'DE',44:'LT',45:'HR',46:'SE',47:'IQ',48:'NL',49:'LV',
    50:'AT',51:'BY',52:'TH',53:'SA',54:'MX',55:'TW',56:'ES',57:'IR',58:'DZ',59:'SI',
    60:'BD',61:'SN',62:'TR',63:'CZ',64:'LK',65:'PE',66:'PK',67:'NZ',68:'GN',69:'ML',
    70:'VE',71:'ET',72:'MN',73:'BR',74:'AF',75:'UG',76:'AO',77:'CY',78:'FR',79:'PG',
    80:'MZ',81:'NP',82:'BE',83:'BG',84:'HU',85:'MD',86:'IT',87:'PY',88:'HN',89:'TN',
    90:'NI',91:'BO',92:'CR',93:'GT',94:'AE',95:'ZW',96:'PR',97:'SD',98:'TG',99:'KW',
    100:'SV',101:'LY',102:'JM',103:'TT',104:'EC',105:'MR',106:'SO',107:'BJ',108:'SL',109:'JO',
    110:'PT',111:'BI',112:'BF',113:'ZM',114:'MW',115:'BT',116:'GY',117:'PA',118:'BH',119:'OM',
    120:'BW',121:'NA',122:'LS',123:'SZ',124:'RW',125:'LR',126:'NE',127:'SR',128:'TL',129:'QA',
    188:'BN',189:'SG',190:'JP',191:'KR',198:'AU',199:'GR',200:'CH',201:'DK',202:'FI',203:'NO',204:'IS',
  };

  static String? _countryFlag(int id) {
    final iso = _idToIso[id];
    if (iso == null) return null;
    final points = iso.codeUnits.map((u) => u - 0x41 + 0x1F1E6);
    return String.fromCharCodes(points);
  }
}

class CsContact {
  final String name;
  final String? wa;
  final String? telegram;
  CsContact({required this.name, this.wa, this.telegram});
  factory CsContact.fromJson(Map<String, dynamic> j) => CsContact(
        name: j['name'] ?? 'CS', wa: j['wa'], telegram: j['telegram']);
  bool get hasWa       => wa != null && wa!.isNotEmpty;
  bool get hasTelegram => telegram != null && telegram!.isNotEmpty;
}

extension IntFmt on int {
  String fmt() {
    final s = toString();
    final r = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) r.write('.');
      r.write(s[i]);
    }
    return r.toString();
  }
}

// ─── Page ────────────────────────────────────────────────────────────────────

class OtpStorePage extends StatefulWidget {
  const OtpStorePage({super.key});
  @override
  State<OtpStorePage> createState() => _OtpStorePageState();
}

class _OtpStorePageState extends State<OtpStorePage>
    with SingleTickerProviderStateMixin {
  static const _bg     = Color(0xFF0A0A0F);
  static const _card   = Color(0xFF12121A);
  static const _accent = Color(0xFF00E5FF);
  static const _purple = Color(0xFF7B2FFF);
  static const _text   = Color(0xFFE8E8F0);
  static const _sub    = Color(0xFF6B6B80);

  late TabController _tab;
  String _sessionKey = '';

  int    _balance  = 0;
  String _username = '';

  // ── Dynamic markup dari /api/markup ─────────────────────────────────────
  Map<String, int> _otpkuPrices = {}; // { 'wa': 9000, 'tg': 6500, ... }
  int _fayuMarkupPer1k = 2000;
  int _kursUsd         = 16000;

  // ── Provider toggle ─────────────────────────────────────────────────────
  // false = ROTP (existing), true = Suntik sosmed
  bool _useFayu = false;

  // Suntik sosmed state
  List<Map<String, dynamic>> _fayuServices   = [];
  bool                       _loadingFayuSvc = false;
  String                     _searchFayuSvc  = '';
  Map<String, dynamic>?      _fayuSelectedSvc;

  // SMM order state
  Map<String, dynamic>?      _fayuOrder;
  bool                       _fayuOrdering   = false;

  // Banner carousel
  List<String> _otpBanners = [];
  int          _bannerPage = 0;
  final PageController _bannerCtrl = PageController();
  Timer? _bannerTimer;

  // TopUp
  String _danaNumber = '';
  String _danaName   = '';
  String _qrisImageUrl = ''; // URL gambar QRIS dari backend
  String _paymentMethod = 'dana'; // 'dana' atau 'qris'
  List<CsContact> _csList = [];
  bool _loadingTopupInfo = false;
  int  _selectedAmount   = 0;
  final _customCtrl       = TextEditingController();
  final _namaPengirimCtrl = TextEditingController();
  XFile? _buktiImage;
  final _picker = ImagePicker();

  // OTP flow
  List<RotpService>  _services  = [];
  bool               _loadingServices = false;
  String             _searchService   = '';
  RotpService?       _selectedService;

  List<RotpCountry>  _countries       = [];
  bool               _loadingCountries = false;
  String             _searchCountry    = '';
  RotpCountry?       _selectedCountry;

  List<RotpNumber>   _numbers      = [];
  bool               _loadingNumbers = false;
  String             _searchNumber   = '';

  Map<String, dynamic>? _orderResult;
  String _otpCode      = '';
  Timer? _otpTimer;
  int    _otpCountdown = 120;
  bool   _otpPolling   = false;
  bool   _checkingOtp  = false; // untuk tombol Cek SMS

  // Activation ID dari order result (untuk tampilan detail)
  String _activationId = '';

  final List<int> _quickAmounts = [5000, 10000, 20000, 50000, 100000, 200000];

  // Notifikasi
  List<Map<String, dynamic>> _notifList = [];
  bool _loadingNotif = false;
  int  _unreadNotif  = 0;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _loadPrefs();
  }

  @override
  void dispose() {
    _tab.dispose();
    _otpTimer?.cancel();
    _bannerTimer?.cancel();
    _bannerCtrl.dispose();
    _customCtrl.dispose();
    _namaPengirimCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    await ConfigService.init();
    _sessionKey = p.getString('sessionKey') ?? '';
    setState(() {});
    await Future.wait([_fetchBalance(), _fetchTopupInfo(), _fetchInitialCountries(), _fetchNotifications(), _fetchMarkup()]);
  }

  Map<String, String> get _h => {
    'Content-Type': 'application/json',
    'x-session-key': _sessionKey,
  };

  // ── API ──────────────────────────────────────────────────────────────────

  void _startBannerTimer() {
    _bannerTimer?.cancel();
    if (_otpBanners.length <= 1) return;
    _bannerTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted) return;
      final next = (_bannerPage + 1) % _otpBanners.length;
      _bannerCtrl.animateToPage(next,
        duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
    });
  }

  Widget _buildBannerCarousel() {
    if (_otpBanners.isEmpty) return const SizedBox.shrink();
    return Column(children: [
      SizedBox(
        height: MediaQuery.of(context).size.width * 9 / 16,
        child: PageView.builder(
          controller: _bannerCtrl,
          itemCount: _otpBanners.length,
          onPageChanged: (i) => setState(() => _bannerPage = i),
          itemBuilder: (_, i) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                _otpBanners[i],
                fit: BoxFit.cover,
                width: double.infinity,
                loadingBuilder: (_, child, p) => p == null
                  ? child
                  : Container(color: _card,
                      child: Center(child: CircularProgressIndicator(
                        value: p.expectedTotalBytes != null
                          ? p.cumulativeBytesLoaded / p.expectedTotalBytes! : null,
                        color: _accent, strokeWidth: 2))),
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          ),
        ),
      ),
      if (_otpBanners.length > 1) ...[
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (int i = 0; i < _otpBanners.length; i++)
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: _bannerPage == i ? 20 : 8,
              height: 8,
              decoration: BoxDecoration(
                color: _bannerPage == i ? _accent : _sub.withOpacity(0.4),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
        ]),
      ],
      const SizedBox(height: 14),
    ]);
  }

  Future<void> _fetchBalance() async {
    try {
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/rotp/balance'), headers: _h);
      final d = jsonDecode(r.body);
      if (d['success'] == true) setState(() => _balance = (d['balance'] ?? 0).toInt());
    } catch (_) {}
  }

  Future<void> _fetchMarkup() async {
    try {
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/markup'), headers: _h);
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        final otpku = d['otpku'] as Map<String, dynamic>? ?? {};
        final fayu  = d['fayu']  as Map<String, dynamic>? ?? {};
        final rawPrices = otpku['prices'] as Map<String, dynamic>? ?? {};
        setState(() {
          _otpkuPrices     = rawPrices.map((k, v) => MapEntry(k, (v as num).toInt()));
          _fayuMarkupPer1k = (fayu['markup_per_1k'] ?? 2000) as int;
          _kursUsd         = (fayu['kurs_usd'] ?? 16000) as int;
        });
      }
    } catch (_) {}
  }

  Future<void> _fetchNotifications() async {
    setState(() => _loadingNotif = true);
    try {
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/rotp/notifications'), headers: _h);
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        final list = (d['data'] as List? ?? []).cast<Map<String, dynamic>>();
        setState(() {
          _notifList  = list;
          _unreadNotif = list.where((n) => n['read'] == false).length;
        });
      }
    } catch (_) {}
    setState(() => _loadingNotif = false);
  }

  Future<void> _markAllNotifRead() async {
    try {
      await http.post(Uri.parse('${ConfigService.baseUrl}/api/rotp/notifications/read'), headers: _h);
      setState(() {
        _unreadNotif = 0;
        for (final n in _notifList) n['read'] = true;
      });
    } catch (_) {}
  }

  Future<void> _fetchTopupInfo() async {
    setState(() => _loadingTopupInfo = true);
    try {
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/topup/info'), headers: _h);
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        setState(() {
          _danaNumber = d['dana_number'] ?? '';
          _danaName   = d['dana_name']   ?? 'Admin';
          _qrisImageUrl = d['qris_image_url'] ?? ''; // ambil URL QRIS
          if ((d['banner_url'] ?? '').toString().isNotEmpty) {
            final url = d['banner_url'].toString();
            if (!_otpBanners.contains(url)) _otpBanners = [url];
          }
          if (d['banners'] is List) {
            final list = (d['banners'] as List)
              .map((b) => (b is String ? b : b?['imageUrl'] ?? b?['url'] ?? '').toString())
              .where((s) => s.isNotEmpty).toList();
            if (list.isNotEmpty) _otpBanners = list;
          }
          _startBannerTimer();
          if ((d['username'] ?? '').toString().isNotEmpty) _username = d['username'].toString();
          if (d['cs_list'] is List && (d['cs_list'] as List).isNotEmpty) {
            _csList = (d['cs_list'] as List).map((e) => CsContact.fromJson(e as Map<String, dynamic>)).toList();
          }
        });
      }
    } catch (_) {}
    setState(() => _loadingTopupInfo = false);
  }

  Future<void> _fetchInitialCountries() async {
    setState(() => _loadingCountries = true);
    try {
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/rotp/countries'), headers: _h);
      final d = jsonDecode(r.body);
      if (d['loading'] == true || d['success'] == false) {
        await Future.delayed(const Duration(seconds: 5));
        if (mounted) await _fetchInitialCountries();
        return;
      }
      final raw  = d['data'];
      final list = (raw is List) ? raw : [];
      setState(() {
        _countries = list
            .map((e) => RotpCountry.fromJson(e as Map<String, dynamic>))
            .where((c) => c.id.toUpperCase() == 'ID' || c.id == '6' || c.name.toLowerCase() == 'indonesia')
            .toList();
        _loadingCountries = false;
      });
    } catch (_) {
      setState(() => _loadingCountries = false);
    }
  }

  Future<void> _selectCountry(RotpCountry country) async {
    setState(() {
      _selectedCountry = country;
      _selectedService = null;
      _services        = [];
      _loadingServices = true;
      _numbers         = [];
      _searchService   = '';
    });
    try {
      final r = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/rotp/services?country=${country.id}'),
        headers: _h,
      );
      final d   = jsonDecode(r.body);
      if (d['loading'] == true) { setState(() => _loadingServices = false); _snack('Server masih menyiapkan data...'); return; }
      final raw = d['data'];
      final list = (raw is List) ? raw : [];
      setState(() {
        _services        = list.map((e) => RotpService.fromJson(e as Map<String, dynamic>)).toList();
        _loadingServices = false;
      });
    } catch (_) { setState(() => _loadingServices = false); }
  }

  Future<void> _fetchNumbers(RotpService svc) async {
    setState(() { _selectedService = svc; _loadingNumbers = true; _numbers = []; _searchNumber = ''; });
    try {
      final r = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/rotp/numbers?country=${_selectedCountry!.id}&service_id=${svc.id}'),
        headers: _h,
      );
      final d   = jsonDecode(r.body);
      final raw = d['data'];
      final list = (raw is List) ? raw : [];
      setState(() { _numbers = list.map((e) => RotpNumber.fromJson(e as Map<String, dynamic>)).toList(); _loadingNumbers = false; });
    } catch (_) { setState(() => _loadingNumbers = false); }
  }

  Future<void> _orderNumber(RotpNumber num) async {
    if (_balance < num.price) { _snack('Saldo kurang! Saldo: Rp${_balance.fmt()}'); return; }
    _showLoading('Ordering nomor...');
    try {
      final r = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/rotp/order'),
        headers: _h,
        body: jsonEncode({
          'number_id':    num.numberId,
          'provider_id':  num.providerId,
          'operator_id':  num.operatorId,
          'price_markup': num.price,
          'service_id':   _selectedService?.id ?? '',
          'country':      _selectedCountry?.id  ?? '6',
        }),
      );
      Navigator.pop(context);
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        final orderId     = d['data']?['order_id']?.toString()     ?? '';
        final phoneNum    = d['data']?['phone_number']?.toString()  ?? num.number;
        final activId     = d['data']?['activation_id']?.toString() ?? orderId;
        final createdAt   = d['data']?['created_at']?.toString()    ?? '';
        setState(() {
          _orderResult   = d;
          _activationId  = activId;
          _balance       = (d['saldo_sisa'] ?? _balance).toInt();
          _otpCode       = '';
          _otpCountdown  = 120;
          _otpPolling    = false;
        });
        _startOtpPolling(orderId);
        _showOtpSheet(num, orderId, phoneNumber: phoneNum, createdAt: createdAt, activId: activId);
      } else {
        _snack(d['message'] ?? 'Order gagal');
      }
    } catch (e) { Navigator.pop(context); _snack('Error: $e'); }
  }

  // Poll OTP — dipanggil manual (tombol Cek SMS) atau dari timer
  Future<void> _pollOtp(String orderId) async {
    try {
      final r = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/rotp/status?order_id=$orderId'),
        headers: _h,
      );
      final d    = jsonDecode(r.body);
      final code = d['data']?['otp_code']?.toString() ?? '';
      if (code.isNotEmpty && mounted) {
        _otpTimer?.cancel();
        HapticFeedback.heavyImpact();
        setState(() { _otpCode = code; _otpPolling = false; });
      }
    } catch (_) {}
  }

  // Timer berjalan di parent — sheet baca state dari sini
  void _startOtpPolling(String orderId) {
    if (orderId.isEmpty) return;
    setState(() { _otpPolling = true; _otpCountdown = 120; _otpCode = ''; });
    _otpTimer?.cancel();
    _otpTimer = Timer.periodic(const Duration(seconds: 5), (t) async {
      if (_otpCountdown <= 0) {
        t.cancel();
        if (mounted) setState(() => _otpPolling = false);
        return;
      }
      if (mounted) setState(() => _otpCountdown -= 5);
      await _pollOtp(orderId);
    });
  }

  // ── Cancel ───────────────────────────────────────────────────────────────

  Future<void> _cancelOrder(String orderId, void Function(void Function()) setSheetState) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 8),
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(color: Colors.orange.withOpacity(0.15), shape: BoxShape.circle),
            child: const Icon(Icons.cancel_outlined, color: Colors.orange, size: 28),
          ),
          const SizedBox(height: 16),
          const Text('Batalkan Pesanan?', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          const Text('Pesanan akan dibatalkan dan saldo akan otomatis dikembalikan.',
            style: TextStyle(color: _sub, fontSize: 13, height: 1.5), textAlign: TextAlign.center),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => Navigator.pop(context, false),
              style: OutlinedButton.styleFrom(
                foregroundColor: _sub,
                side: const BorderSide(color: Color(0xFF2A2A3A)),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Tidak'),
            )),
            const SizedBox(width: 12),
            Expanded(child: ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.withOpacity(0.15),
                foregroundColor: Colors.red,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Ya, Batalkan', style: TextStyle(fontWeight: FontWeight.bold)),
            )),
          ]),
        ]),
      ),
    );
    if (confirm != true) return;
    _otpTimer?.cancel();
    _showLoading('Membatalkan pesanan...');
    try {
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/rotp/cancel?order_id=$orderId'), headers: _h);
      Navigator.pop(context); // tutup loading
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        final refund = (d['refund_amount'] ?? 0).toInt();
        await _fetchBalance();
        if (mounted) Navigator.pop(context); // tutup sheet OTP
        if (mounted) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (_) => AlertDialog(
              backgroundColor: _card,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                const SizedBox(height: 8),
                // Icon sukses
                Container(
                  width: 64, height: 64,
                  decoration: BoxDecoration(color: const Color(0xFF25D366).withOpacity(0.15), shape: BoxShape.circle),
                  child: const Icon(Icons.check_circle_outline, color: Color(0xFF25D366), size: 36),
                ),
                const SizedBox(height: 16),
                const Text('Pesanan Dibatalkan', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 17)),
                const SizedBox(height: 10),
                if (refund > 0) ...[
                  // Refund amount card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF25D366).withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF25D366).withOpacity(0.3)),
                    ),
                    child: Column(children: [
                      const Text('Dana Dikembalikan', style: TextStyle(color: _sub, fontSize: 12)),
                      const SizedBox(height: 6),
                      Text('+Rp ${refund.fmt()}', style: const TextStyle(
                        color: Color(0xFF25D366), fontSize: 26, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                      const SizedBox(height: 4),
                      Text('Saldo kamu sekarang: Rp ${_balance.fmt()}',
                        style: const TextStyle(color: _sub, fontSize: 12)),
                    ]),
                  ),
                ] else
                  const Text('Pesanan berhasil dibatalkan.',
                    style: TextStyle(color: _sub, fontSize: 13, height: 1.5), textAlign: TextAlign.center),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accent, foregroundColor: Colors.black,
                      elevation: 0, padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('OK', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  ),
                ),
              ]),
            ),
          );
        }
      } else {
        _snack(d['message'] ?? 'Gagal membatalkan');
      }
    } catch (e) {
      Navigator.pop(context);
      _snack('Error: $e');
    }
  }

  // ── Fayupedia SMM API ────────────────────────────────────────────────────

  Future<void> _fayuFetchServices() async {
    setState(() { _loadingFayuSvc = true; _fayuServices = []; _fayuSelectedSvc = null; _searchFayuSvc = ''; });
    try {
      if (ConfigService.baseUrl.isEmpty) {
        _snack('Server belum terhubung. Coba restart app.');
        setState(() => _loadingFayuSvc = false);
        return;
      }
      final r = await http.get(Uri.parse('${ConfigService.baseUrl}/api/fayu/services'), headers: _h);
      if (r.headers['content-type']?.contains('text/html') == true) {
        _snack('Server error: endpoint tidak ditemukan');
        setState(() => _loadingFayuSvc = false);
        return;
      }
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        setState(() => _fayuServices = (d['data'] as List? ?? []).cast<Map<String, dynamic>>());
      } else {
        _snack(d['message'] ?? 'Gagal memuat layanan Fayupedia');
      }
    } catch (e) { _snack('Error: $e'); }
    setState(() => _loadingFayuSvc = false);
  }

  Future<void> _fayuPlaceOrder({
    required int serviceId,
    required String link,
    required int quantity,
    required int price,
  }) async {
    if (_balance < price) { _snack('Saldo kurang! Saldo: Rp${_balance.fmt()}'); return; }
    if (ConfigService.baseUrl.isEmpty) { _snack('Server belum terhubung.'); return; }
    setState(() => _fayuOrdering = true);
    try {
      final r = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/fayu/order'),
        headers: _h,
        body: jsonEncode({
          'service':      serviceId,
          'link':         link,
          'quantity':     quantity,
          'price_markup': price,
        }),
      );
      if (r.headers['content-type']?.contains('text/html') == true || r.body.trimLeft().startsWith('<!')) {
        _snack('Server error: endpoint tidak ditemukan');
        setState(() => _fayuOrdering = false);
        return;
      }
      final d = jsonDecode(r.body);
      if (d['success'] == true) {
        setState(() {
          _fayuOrder = d;
          _balance   = (d['saldo_sisa'] ?? _balance) as int;
        });
        _showFayuSuccessSheet(d);
      } else {
        _snack(d['message'] ?? 'Order gagal');
      }
    } catch (e) { _snack('Error: $e'); }
    setState(() => _fayuOrdering = false);
  }

  void _showFayuSuccessSheet(Map<String, dynamic> d) {
    final orderId   = d['data']?['order_id']?.toString() ?? '-';
    final svcName   = (_fayuSelectedSvc?['name'] ?? 'Layanan').toString();
    final meta      = _getMeta(svcName);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF12121A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _sub, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(color: const Color(0xFF25D366).withOpacity(0.12), shape: BoxShape.circle),
            child: const Icon(Icons.check_circle_outline, color: Color(0xFF25D366), size: 36),
          ),
          const SizedBox(height: 14),
          const Text('Order Berhasil!', style: TextStyle(color: Color(0xFF25D366), fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 6),
          Text(svcName, style: TextStyle(color: meta.color, fontSize: 13)),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF1E1E2A))),
            child: Column(children: [
              _detailRow('Order ID', orderId),
              const Divider(color: Color(0xFF1E1E2A), height: 16),
              _detailRow('Status', 'Diproses', valueColor: Colors.orange),
              const Divider(color: Color(0xFF1E1E2A), height: 16),
              _detailRow('Saldo Sisa', 'Rp${_balance.fmt()}', valueColor: _accent),
            ]),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity, padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.orange.withOpacity(0.06), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.orange.withOpacity(0.2))),
            child: const Row(children: [
              Icon(Icons.info_outline, color: Colors.orange, size: 15),
              SizedBox(width: 8),
              Expanded(child: Text('Pesanan sedang diproses. Cek hasilnya langsung di akun sosmed kamu.', style: TextStyle(color: _sub, fontSize: 12, height: 1.4))),
            ]),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () { Navigator.pop(context); setState(() { _fayuSelectedSvc = null; }); },
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF118EEA), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0),
              child: const Text('Selesai', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            ),
          ),
        ]),
      ),
    );
  }

    // ── TopUp helpers ─────────────────────────────────────────────────────────

  Future<void> _pickBukti(ImageSource source) async {
    try {
      final img = await _picker.pickImage(source: source, imageQuality: 85);
      if (img != null) { setState(() => _buktiImage = img); _snack('Bukti dipilih'); }
    } catch (e) { _snack('Gagal pilih gambar: $e'); }
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context, backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(color: _sub, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 16),
        const Text('Pilih Sumber Gambar', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _sourceButton(icon: Icons.camera_alt, label: 'Kamera', onTap: () { Navigator.pop(context); _pickBukti(ImageSource.camera); })),
          const SizedBox(width: 12),
          Expanded(child: _sourceButton(icon: Icons.photo_library, label: 'Galeri', onTap: () { Navigator.pop(context); _pickBukti(ImageSource.gallery); })),
        ]),
      ]))),
    );
  }

  Widget _sourceButton({required IconData icon, required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(color: _accent.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: _accent.withOpacity(0.3))),
        child: Column(children: [Icon(icon, color: _accent, size: 28), const SizedBox(height: 8), Text(label, style: const TextStyle(color: _text, fontSize: 13))]),
      ),
    );
  }

  Future<void> _kirimBuktiWA(int amount) async {
    if (amount <= 0) { _snack('Pilih nominal dulu!'); return; }
    if (!mounted) return;
    if (_csList.length == 1 && _csList.first.hasWa && !_csList.first.hasTelegram) { await _sendBukti(amount, _csList.first, 'wa'); return; }
    if (_csList.isEmpty) { _snack('Info CS belum tersedia. Coba refresh.'); return; }
    await showModalBottomSheet(
      context: context, backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      isScrollControlled: true,
      builder: (_) => _CsPickerSheet(
        csList: _csList, amount: amount, username: _username, buktiImage: _buktiImage,
        onSelected: (cs, platform) async { Navigator.pop(context); await _sendBukti(amount, cs, platform); },
      ),
    );
  }

  Future<void> _sendBukti(int amount, CsContact cs, String platform) async {
    final namaAkun     = _username.isNotEmpty ? _username : '-';
    final namaPengirim = _namaPengirimCtrl.text.trim().isNotEmpty ? _namaPengirimCtrl.text.trim() : '-';
    final String metodeInfo = _paymentMethod == 'qris'
        ? '💳 Metode: QRIS (GoPay Merchant)'
        : '🏦 Transfer ke: DANA a/n $_danaName ($_danaNumber)\n💌 Dana atas nama pengirim: $namaPengirim';
    final msg = 'Halo min, saya mau top up TOKO STORE MIWACHAN.\n\n👤 Username: $namaAkun\n💵 Nominal: Rp${amount.fmt()}\n$metodeInfo\n\nBerikut bukti transfernya: [terlampir]';
    if (platform == 'wa') await _openWhatsAppText(msg, cs.wa!);
    else if (platform == 'telegram') await _openTelegram(msg, cs.telegram!);
  }

  Future<void> _openWhatsAppText(String message, String csWa) async {
    final number  = csWa.replaceAll(RegExp(r'\D'), '');
    final encoded = Uri.encodeComponent(message);
    final uri     = Uri.parse('https://wa.me/$number?text=$encoded');
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
    else _snack('Tidak bisa membuka WhatsApp');
  }

  Future<void> _openTelegram(String message, String csTelegram) async {
    final handle  = csTelegram.replaceAll(RegExp(r'^@'), '').replaceAll('https://t.me/', '');
    final encoded = Uri.encodeComponent(message);
    final uri     = Uri.parse('https://t.me/$handle?text=$encoded');
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
    else _snack('Tidak bisa membuka Telegram');
  }

  // ── Notification Sheet ────────────────────────────────────────────────────

  void _showNotificationSheet() {
    _markAllNotifRead();
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSt) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.75,
          maxChildSize: 0.92,
          minChildSize: 0.4,
          builder: (_, sc) => Column(children: [
            // Handle
            Container(margin: const EdgeInsets.only(top: 12, bottom: 4), width: 40, height: 4,
              decoration: BoxDecoration(color: _sub.withOpacity(0.4), borderRadius: BorderRadius.circular(2))),
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
              child: Row(children: [
                const Text('Notifikasi', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 18)),
                const SizedBox(width: 10),
                if (_notifList.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: const Color(0xFFFFAA00).withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                    child: Text('${_notifList.length} baru', style: const TextStyle(color: Color(0xFFFFAA00), fontSize: 11, fontWeight: FontWeight.w600)),
                  ),
                const Spacer(),
                GestureDetector(
                  onTap: () async { await _fetchNotifications(); setSt(() {}); },
                  child: const Text('Refresh', style: TextStyle(color: _accent, fontSize: 13)),
                ),
              ]),
            ),
            const SizedBox(height: 8),
            const Divider(height: 1, color: Color(0xFF1E1E2A)),
            // List
            Expanded(
              child: _loadingNotif
                ? const Center(child: CircularProgressIndicator(color: _accent))
                : _notifList.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.notifications_off_outlined, color: _sub, size: 48),
                      const SizedBox(height: 12),
                      const Text('Belum ada notifikasi', style: TextStyle(color: _sub)),
                    ]))
                  : ListView.separated(
                      controller: sc,
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                      itemCount: _notifList.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final n       = _notifList[i];
                        final type    = (n['type'] ?? '').toString();
                        final isCancel = type == 'cancel' || (n['title'] ?? '').toString().toLowerCase().contains('pembatalan');
                        final isBuy   = type == 'buy' || (n['title'] ?? '').toString().toLowerCase().contains('pembelian');
                        final isApiKey = (n['title'] ?? '').toString().toLowerCase().contains('api key');
                        final amount  = (n['amount'] ?? 0) as int;
                        final isPlus  = isCancel || amount > 0 && !isBuy;

                        Color iconBg, iconColor;
                        IconData iconData;
                        if (isCancel) {
                          iconBg = Colors.red.withOpacity(0.15); iconColor = Colors.red; iconData = Icons.cancel_outlined;
                        } else if (isBuy) {
                          iconBg = _accent.withOpacity(0.1); iconColor = _accent; iconData = Icons.phone_callback_outlined;
                        } else if (isApiKey) {
                          iconBg = _purple.withOpacity(0.15); iconColor = _purple; iconData = Icons.key_outlined;
                        } else {
                          iconBg = _sub.withOpacity(0.1); iconColor = _sub; iconData = Icons.notifications_outlined;
                        }

                        final isUnread = n['read'] == false;

                        return Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: isUnread ? _accent.withOpacity(0.04) : _bg,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: isUnread ? _accent.withOpacity(0.15) : const Color(0xFF1E1E2A)),
                          ),
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Container(
                              width: 40, height: 40,
                              decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(10)),
                              child: Icon(iconData, color: iconColor, size: 20),
                            ),
                            const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(n['title'] ?? '', style: const TextStyle(color: _text, fontWeight: FontWeight.w600, fontSize: 14)),
                              const SizedBox(height: 3),
                              if ((n['subtitle'] ?? '').toString().isNotEmpty)
                                Text(n['subtitle'].toString(), style: const TextStyle(color: _sub, fontSize: 12)),
                              const SizedBox(height: 4),
                              Row(children: [
                                if ((n['time'] ?? '').toString().isNotEmpty)
                                  Text(n['time'].toString(), style: const TextStyle(color: _sub, fontSize: 11)),
                                const Spacer(),
                                if (amount != 0)
                                  Text(
                                    '${isPlus ? '+' : '-'}Rp ${amount.abs().fmt()}',
                                    style: TextStyle(
                                      color: isPlus ? const Color(0xFF25D366) : Colors.red,
                                      fontWeight: FontWeight.bold, fontSize: 13),
                                  ),
                              ]),
                            ])),
                            if (isUnread)
                              Container(width: 8, height: 8, margin: const EdgeInsets.only(top: 4, left: 4),
                                decoration: const BoxDecoration(color: _accent, shape: BoxShape.circle)),
                          ]),
                        );
                      },
                    ),
            ),
          ]),
        ),
      ),
    );
  }

  // ── UI Helpers ────────────────────────────────────────────────────────────

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg, style: const TextStyle(color: _text)), backgroundColor: _card, behavior: SnackBarBehavior.floating),
  );

  void _showLoading(String msg) => showDialog(
    context: context, barrierDismissible: false,
    builder: (_) => AlertDialog(backgroundColor: _card, content: Row(children: [
      const CircularProgressIndicator(color: _accent), const SizedBox(width: 16),
      Text(msg, style: const TextStyle(color: _text)),
    ])),
  );

  void _copyToClipboard(String text, String label) { Clipboard.setData(ClipboardData(text: text)); _snack('$label disalin!'); }

  Widget _sectionTitle(String t) => Text(t, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 15));

  // ── BUILD ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        title: const Text('TOKO STORE MIWACHAN', style: TextStyle(color: _text, fontWeight: FontWeight.bold, letterSpacing: 1)),
        actions: [
          // Bell icon notifikasi
          GestureDetector(
            onTap: _showNotificationSheet,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 4),
                  padding: const EdgeInsets.all(8),
                  child: Icon(
                    _unreadNotif > 0 ? Icons.notifications : Icons.notifications_outlined,
                    color: _unreadNotif > 0 ? const Color(0xFFFFAA00) : _sub,
                    size: 22,
                  ),
                ),
                if (_unreadNotif > 0)
                  Positioned(
                    top: 4, right: 4,
                    child: Container(
                      width: 17, height: 17,
                      decoration: const BoxDecoration(color: Color(0xFFFFAA00), shape: BoxShape.circle),
                      alignment: Alignment.center,
                      child: Text(
                        _unreadNotif > 9 ? '9+' : '$_unreadNotif',
                        style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          // Balance chip
          GestureDetector(
            onTap: _fetchBalance,
            child: Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accent.withOpacity(0.4))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.account_balance_wallet, color: _accent, size: 14),
                const SizedBox(width: 6),
                Text('Rp${_balance.fmt()}', style: const TextStyle(color: _accent, fontSize: 13, fontWeight: FontWeight.bold)),
              ]),
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: _accent,
          labelColor: _accent,
          unselectedLabelColor: _sub,
          tabs: const [
            Tab(icon: Icon(Icons.account_balance_wallet, size: 18), text: 'Top Up'),
            Tab(icon: Icon(Icons.sim_card, size: 18), text: 'nokos'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        physics: const NeverScrollableScrollPhysics(),
        children: [_buildTopupTab(), _buildOtpTab()],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // TAB TOP UP
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildTopupTab() {
    final amount = _selectedAmount > 0 ? _selectedAmount : int.tryParse(_customCtrl.text.replaceAll('.', '')) ?? 0;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // ── Banner Carousel ───────────────────────────────────────────────
        _buildBannerCarousel(),

        // ── Saldo Card (OTPKU style) ──────────────────────────────────────
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF0D1F2D),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _accent.withOpacity(0.2)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('SALDO AKUN', style: TextStyle(color: _sub, fontSize: 11, letterSpacing: 1)),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFF00E5FF).withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                child: const Text('AKTIF', style: TextStyle(color: _accent, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
              ),
            ]),
            const SizedBox(height: 8),
            Text('Rp ${_balance.fmt()}', style: const TextStyle(color: _text, fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
            if (_username.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('Username: @$_username', style: const TextStyle(color: _sub, fontSize: 13)),
            ],
            const SizedBox(height: 16),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Top Up', style: TextStyle(fontWeight: FontWeight.bold)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _text,
                    side: const BorderSide(color: Color(0xFF2A2A3A)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _tab.animateTo(1),
                  icon: const Icon(Icons.phone_outlined, size: 16),
                  label: const Text('nokos', style: TextStyle(fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accent,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    elevation: 0,
                  ),
                ),
              ),
            ]),
          ]),
        ),

        const SizedBox(height: 20),

        // ── Step 1: Nominal ───────────────────────────────────────────────
        _topupSectionLabel('1', 'Pilih Nominal Top Up'),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10,
          childAspectRatio: 2.2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          children: _quickAmounts.map((a) => GestureDetector(
            onTap: () { setState(() { _selectedAmount = a; _customCtrl.clear(); }); HapticFeedback.selectionClick(); },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              decoration: BoxDecoration(
                color: _selectedAmount == a ? _accent.withOpacity(0.12) : _card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _selectedAmount == a ? _accent : const Color(0xFF1E1E2A), width: _selectedAmount == a ? 1.5 : 1)),
              alignment: Alignment.center,
              child: Text('Rp${a.fmt()}', style: TextStyle(
                color: _selectedAmount == a ? _accent : _text,
                fontWeight: FontWeight.w600, fontSize: 12)),
            ),
          )).toList(),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _customCtrl, keyboardType: TextInputType.number,
          style: const TextStyle(color: _text, fontSize: 14),
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (_) => setState(() => _selectedAmount = 0),
          decoration: InputDecoration(
            hintText: 'Atau masukkan nominal lain...',
            hintStyle: const TextStyle(color: _sub, fontSize: 13),
            prefixText: 'Rp  ',
            prefixStyle: const TextStyle(color: _accent, fontWeight: FontWeight.bold),
            filled: true, fillColor: _card,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _accent)),
          ),
        ),

        const SizedBox(height: 20),

        // ── Step 2: Pilih Metode Pembayaran ──────────────────────────────
        _topupSectionLabel('2', 'Pilih Metode Pembayaran'),
        const SizedBox(height: 10),

        // Toggle Dana / QRIS
        Row(children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _paymentMethod = 'dana'),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: _paymentMethod == 'dana' ? const Color(0xFF118EEA).withOpacity(0.15) : _card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _paymentMethod == 'dana' ? const Color(0xFF118EEA) : const Color(0xFF1E1E2A),
                    width: _paymentMethod == 'dana' ? 1.5 : 1,
                  ),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.account_balance_wallet, color: Color(0xFF118EEA), size: 22),
                  const SizedBox(height: 4),
                  const Text('DANA', style: TextStyle(color: Color(0xFF118EEA), fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 2)),
                ]),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _paymentMethod = 'qris'),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: _paymentMethod == 'qris' ? const Color(0xFF00AA13).withOpacity(0.15) : _card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _paymentMethod == 'qris' ? const Color(0xFF00AA13) : const Color(0xFF1E1E2A),
                    width: _paymentMethod == 'qris' ? 1.5 : 1,
                  ),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.qr_code_2, color: Color(0xFF00AA13), size: 22),
                  const SizedBox(height: 4),
                  const Text('QRIS', style: TextStyle(color: Color(0xFF00AA13), fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 2)),
                ]),
              ),
            ),
          ),
        ]),

        const SizedBox(height: 12),

        // Info metode terpilih
        _loadingTopupInfo
          ? const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: _accent)))
          : _paymentMethod == 'dana'
            ? Container(
                width: double.infinity,
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF1E1E2A))),
                child: Column(children: [
                  // Header DANA
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: const BoxDecoration(
                      color: Color(0xFF118EEA),
                      borderRadius: BorderRadius.vertical(top: Radius.circular(13)),
                    ),
                    alignment: Alignment.center,
                    child: const Text('DANA', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 6)),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(children: [
                      _danaRow(Icons.phone_outlined, 'Nomor', _danaNumber.isEmpty ? '-' : _danaNumber, copyVal: _danaNumber),
                      const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(color: Color(0xFF1E1E2A), height: 1)),
                      _danaRow(Icons.person_outline, 'Atas Nama', _danaName.isEmpty ? '-' : _danaName),
                      if (amount > 0) ...[
                        const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(color: Color(0xFF1E1E2A), height: 1)),
                        _danaRow(Icons.payments_outlined, 'Nominal Transfer', 'Rp ${amount.fmt()}',
                          valueColor: _accent, copyVal: amount.toString()),
                      ],
                    ]),
                  ),
                ]),
              )
            : Container(
                width: double.infinity,
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF00AA13).withOpacity(0.4))),
                child: Column(children: [
                  // Header QRIS
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: const BoxDecoration(
                      color: Color(0xFF00AA13),
                      borderRadius: BorderRadius.vertical(top: Radius.circular(13)),
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.qr_code_2, color: Colors.white, size: 22),
                      SizedBox(width: 8),
                      Text('QRIS', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 6)),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(children: [
                      const Text('Scan QR di bawah dengan aplikasi apapun\n(GoPay, OVO, Dana, BCA, semua bank)',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: _sub, fontSize: 12, height: 1.5)),
                      const SizedBox(height: 14),
                      // QR Code image
                      _qrisImageUrl.isNotEmpty
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.network(
                              _qrisImageUrl,
                              width: 200, height: 200,
                              fit: BoxFit.contain,
                              errorBuilder: (_, __, ___) => Container(
                                width: 200, height: 200,
                                decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(10)),
                                child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  Icon(Icons.qr_code_2, color: _sub, size: 60),
                                  SizedBox(height: 8),
                                  Text('Gagal load QR', style: TextStyle(color: _sub, fontSize: 12)),
                                ]),
                              ),
                            ),
                          )
                        : Container(
                            width: 200, height: 200,
                            decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF1E1E2A))),
                            child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Icon(Icons.qr_code_2, color: _sub, size: 60),
                              SizedBox(height: 8),
                              Text('QR belum tersedia', style: TextStyle(color: _sub, fontSize: 12)),
                            ]),
                          ),
                      if (amount > 0) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: const Color(0xFF00AA13).withOpacity(0.08),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFF00AA13).withOpacity(0.3)),
                          ),
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            const Icon(Icons.payments_outlined, color: Color(0xFF00AA13), size: 16),
                            const SizedBox(width: 8),
                            Text('Nominal: Rp ${amount.fmt()}',
                              style: const TextStyle(color: Color(0xFF00AA13), fontWeight: FontWeight.bold, fontSize: 14)),
                          ]),
                        ),
                      ],
                      const SizedBox(height: 8),
                      const Text('⚠️ Pastikan nominal transfer sesuai',
                        style: TextStyle(color: Colors.orange, fontSize: 11)),
                    ]),
                  ),
                ]),
              ),

        const SizedBox(height: 20),

        // ── Step 3: Upload bukti ──────────────────────────────────────────
        _topupSectionLabel('3', 'Upload Bukti Transfer'),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: _showImageSourceDialog,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _buktiImage != null ? _accent.withOpacity(0.06) : _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _buktiImage != null ? _accent.withOpacity(0.5) : const Color(0xFF1E1E2A),
                width: _buktiImage != null ? 1.5 : 1,
                style: _buktiImage == null ? BorderStyle.solid : BorderStyle.solid,
              ),
            ),
            child: _buktiImage == null
              ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(width: 48, height: 48, decoration: BoxDecoration(color: _sub.withOpacity(0.1), shape: BoxShape.circle),
                    child: const Icon(Icons.cloud_upload_outlined, color: _sub, size: 26)),
                  const SizedBox(height: 10),
                  const Text('Tap untuk upload bukti transfer', style: TextStyle(color: _text, fontSize: 13, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  const Text('Kamera atau Galeri', style: TextStyle(color: _sub, fontSize: 11)),
                ])
              : Row(children: [
                  Container(width: 50, height: 50,
                    decoration: BoxDecoration(color: _accent.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.image_outlined, color: _accent, size: 28)),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_buktiImage!.name, style: const TextStyle(color: _text, fontWeight: FontWeight.w600, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Row(children: [
                      const Icon(Icons.check_circle, color: Color(0xFF25D366), size: 13),
                      const SizedBox(width: 4),
                      const Text('Bukti dipilih', style: TextStyle(color: Color(0xFF25D366), fontSize: 12)),
                    ]),
                  ])),
                  GestureDetector(
                    onTap: () => setState(() => _buktiImage = null),
                    child: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: _sub.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.close, color: _sub, size: 16)),
                  ),
                ]),
          ),
        ),

        const SizedBox(height: 20),

        // ── Step 4: Kirim ke CS ───────────────────────────────────────────
        _topupSectionLabel('4', 'Konfirmasi ke CS'),
        const SizedBox(height: 10),
        Container(
          width: double.infinity, padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF1E1E2A))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Username badge
            if (_username.isNotEmpty) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _accent.withOpacity(0.2)),
                ),
                child: Row(children: [
                  const Icon(Icons.person_pin_outlined, color: _accent, size: 15),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Username "@$_username" akan otomatis terisi', style: const TextStyle(color: _sub, fontSize: 12, height: 1.4))),
                ]),
              ),
              const SizedBox(height: 12),
            ],
            // Input nama pengirim
            TextField(
              controller: _namaPengirimCtrl, style: const TextStyle(color: _text, fontSize: 14),
              decoration: InputDecoration(
                hintText: _paymentMethod == 'qris' ? 'Nama akun pengirim (opsional)' : 'Nama akun Dana pengirim',
                hintStyle: TextStyle(color: _sub.withOpacity(0.6), fontSize: 13),
                prefixIcon: const Icon(Icons.person_outline, color: _sub, size: 18),
                filled: true, fillColor: _bg,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF1E1E2A))),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF1E1E2A))),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: _accent.withOpacity(0.6))),
              ),
            ),
            const SizedBox(height: 10),
            const Text('Setelah transfer, kirim bukti ke CS untuk konfirmasi.',
              style: TextStyle(color: _sub, fontSize: 12, height: 1.5)),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _kirimBuktiWA(amount),
                icon: const Icon(Icons.support_agent_outlined, size: 18),
                label: Text(
                  amount <= 0
                    ? 'Pilih Nominal Dulu'
                    : _buktiImage != null
                      ? 'Kirim Bukti ke CS'
                      : 'Konfirmasi ke CS',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: amount > 0 ? _accent : _sub.withOpacity(0.3),
                  foregroundColor: amount > 0 ? Colors.black : _sub,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
              ),
            ),
          ]),
        ),

        const SizedBox(height: 20),

        // ── Garansi & Keamanan ────────────────────────────────────────────
        Container(
          width: double.infinity, padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.green.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.green.withOpacity(0.2)),
          ),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.verified_user_outlined, color: Colors.green, size: 20),
            const SizedBox(width: 10),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Garansi & Keamanan', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 13)),
              SizedBox(height: 4),
              Text('Saldo aman & terenkripsi. Refund otomatis jika nomor gagal dalam 20 menit.',
                style: TextStyle(color: _sub, fontSize: 12, height: 1.5)),
            ])),
          ]),
        ),

      ]),
    );
  }

  Widget _topupSectionLabel(String num, String label) {
    return Row(children: [
      Container(
        width: 24, height: 24,
        decoration: BoxDecoration(color: _accent, shape: BoxShape.circle),
        alignment: Alignment.center,
        child: Text(num, style: const TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.bold)),
      ),
      const SizedBox(width: 10),
      Text(label, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 14)),
    ]);
  }

  Widget _danaRow(IconData icon, String label, String value, {Color? valueColor, String? copyVal}) {
    return Row(children: [
      Icon(icon, color: _sub, size: 16),
      const SizedBox(width: 10),
      Text(label, style: const TextStyle(color: _sub, fontSize: 13)),
      const Spacer(),
      Text(value, style: TextStyle(color: valueColor ?? _text, fontWeight: FontWeight.bold, fontSize: 14)),
      if (copyVal != null && copyVal.isNotEmpty) ...[
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _copyToClipboard(copyVal, label),
          child: Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(color: _accent.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
            child: const Icon(Icons.copy_outlined, color: _accent, size: 13),
          ),
        ),
      ],
    ]);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // TAB OTP — OTPKU Style
  // ══════════════════════════════════════════════════════════════════════════

  // Step index: 0=negara, 1=layanan, 2=nomor
  int get _otpStep {
    if (_selectedCountry == null) return 0;
    if (_selectedService == null) return 1;
    return 2;
  }

  Widget _buildOtpStepIndicator() {
    const steps = ['Negara', 'Layanan', 'Nomor'];
    return Container(
      color: _bg,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(children: List.generate(steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          // connector line
          final leftDone = (i ~/ 2) < _otpStep;
          return Expanded(child: Container(height: 2, color: leftDone ? _accent : const Color(0xFF2A2A3A)));
        }
        final idx    = i ~/ 2;
        final active = idx == _otpStep;
        final done   = idx < _otpStep;
        return GestureDetector(
          onTap: () {
            if (idx == 0 && _otpStep > 0) setState(() { _selectedCountry = null; _selectedService = null; _services = []; _numbers = []; _searchService = ''; _searchNumber = ''; });
            if (idx == 1 && _otpStep > 1) setState(() { _selectedService = null; _numbers = []; _searchNumber = ''; });
          },
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 28, height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: done ? _accent : active ? _accent.withOpacity(0.2) : const Color(0xFF1E1E2A),
                border: Border.all(color: active || done ? _accent : const Color(0xFF2A2A3A), width: 2),
              ),
              child: Center(child: done
                ? const Icon(Icons.check, color: Colors.black, size: 14)
                : Text('${idx + 1}', style: TextStyle(color: active ? _accent : _sub, fontSize: 12, fontWeight: FontWeight.bold))),
            ),
            const SizedBox(height: 4),
            Text(steps[idx], style: TextStyle(
              color: active || done ? _accent : _sub,
              fontSize: 10,
              fontWeight: active ? FontWeight.bold : FontWeight.normal,
            )),
          ]),
        );
      })),
    );
  }

  Widget _buildOtpTab() {
    return Column(children: [
      // ── Provider Toggle ──────────────────────────────────────────────────
      Container(
        color: _bg,
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        child: Row(children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                if (_useFayu) setState(() { _useFayu = false; });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: !_useFayu ? _accent.withOpacity(0.15) : _card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: !_useFayu ? _accent : const Color(0xFF2A2A3A), width: !_useFayu ? 1.5 : 1),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.sim_card_outlined, color: !_useFayu ? _accent : _sub, size: 15),
                  const SizedBox(width: 6),
                  Text('ROTP', style: TextStyle(color: !_useFayu ? _accent : _sub, fontWeight: FontWeight.bold, fontSize: 13)),
                ]),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () {
                if (!_useFayu) {
                  setState(() { _useFayu = true; });
                  if (_fayuServices.isEmpty && !_loadingFayuSvc) _fayuFetchServices();
                }
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: _useFayu ? const Color(0xFF118EEA).withOpacity(0.15) : _card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _useFayu ? const Color(0xFF118EEA) : const Color(0xFF2A2A3A), width: _useFayu ? 1.5 : 1),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.language_outlined, color: _useFayu ? const Color(0xFF118EEA) : _sub, size: 15),
                  const SizedBox(width: 6),
                  Text('Suntik sosmed', style: TextStyle(color: _useFayu ? const Color(0xFF118EEA) : _sub, fontWeight: FontWeight.bold, fontSize: 13)),
                ]),
              ),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 8),
      // ── Content per provider ─────────────────────────────────────────────
      if (!_useFayu) ...[
        _buildOtpStepIndicator(),
        const Divider(height: 1, color: Color(0xFF1E1E2A)),
        Expanded(child: () {
          if (_selectedCountry == null) return _buildCountryView();
          if (_selectedService == null) return _buildServicesView();
          return _buildNumbersView();
        }()),
      ] else ...[
        const Divider(height: 1, color: Color(0xFF1E1E2A)),
        Expanded(child: _fayuSelectedSvc == null
          ? _buildFayuServicesView()
          : _buildFayuOrderForm()),
      ],
    ]);
  }

  // ── Step 1: Negara (auto-select Indonesia, tampilkan card saja) ───────────

  Widget _buildCountryView() {
    if (_loadingCountries) {
      return const Center(child: CircularProgressIndicator(color: _accent));
    }

    // Auto-select jika Indonesia sudah ada
    if (_countries.isNotEmpty && _selectedCountry == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _selectedCountry == null && _countries.isNotEmpty) {
          _selectCountry(_countries.first);
        }
      });
    }

    if (_countries.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.public_off, color: _sub, size: 48),
        const SizedBox(height: 12),
        const Text('Tidak ada negara tersedia', style: TextStyle(color: _sub)),
        const SizedBox(height: 8),
        const Text('Server mungkin masih scan data\nCoba refresh sebentar lagi', style: TextStyle(color: _sub, fontSize: 12), textAlign: TextAlign.center),
        const SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: _fetchInitialCountries,
          icon: const Icon(Icons.refresh, size: 16),
          label: const Text('Refresh'),
          style: ElevatedButton.styleFrom(backgroundColor: _accent.withOpacity(0.15), foregroundColor: _accent, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
        ),
      ]));
    }

    // Tampilkan card Indonesia yang bisa di-tap
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Pilih Negara', style: TextStyle(color: _sub, fontSize: 12, letterSpacing: 0.5)),
        const SizedBox(height: 10),
        ..._countries.map((country) => GestureDetector(
          onTap: () => _selectCountry(country),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _accent.withOpacity(0.4), width: 1.5),
            ),
            child: Row(children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(color: _accent.withOpacity(0.08), borderRadius: BorderRadius.circular(10)),
                alignment: Alignment.center,
                child: country.flag != null && country.flag!.isNotEmpty
                  ? Text(country.flag!, style: const TextStyle(fontSize: 26))
                  : const Icon(Icons.flag, color: _accent, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(country.name, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 15)),
                const SizedBox(height: 4),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: country.stock > 10 ? Colors.green.withOpacity(0.15) : Colors.orange.withOpacity(0.15), borderRadius: BorderRadius.circular(4)),
                    child: Text('${country.stock} nomor tersedia', style: TextStyle(color: country.stock > 10 ? Colors.green : Colors.orange, fontSize: 10, fontWeight: FontWeight.w600)),
                  ),
                ]),
              ])),
              const Icon(Icons.chevron_right, color: _accent, size: 22),
            ]),
          ),
        )).toList(),
      ]),
    );
  }

  // ── Step 2: Layanan — OTPKU style (grid 2-col, search bar, label count) ──

  Widget _buildServicesView() {
    final filtered = _services.where((s) => s.name.toLowerCase().contains(_searchService.toLowerCase())).toList();

    return Column(children: [
      // Header info negara
      Container(
        color: _bg, padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
        child: Row(children: [
          if (_selectedCountry?.flag != null)
            Text(_selectedCountry!.flag!, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_selectedCountry?.name ?? '', style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 15)),
            const Text('Pilih Layanan', style: TextStyle(color: _sub, fontSize: 11)),
          ])),
          if (!_loadingServices)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: _accent.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
              child: Text('${_services.length} layanan', style: const TextStyle(color: _accent, fontSize: 11, fontWeight: FontWeight.w600)),
            ),
        ]),
      ),
      // Search bar
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: TextField(
          style: const TextStyle(color: _text, fontSize: 14),
          onChanged: (v) => setState(() => _searchService = v),
          decoration: InputDecoration(
            hintText: 'Cari layanan (WhatsApp, Telegram, Instagram...)',
            hintStyle: const TextStyle(color: _sub, fontSize: 13),
            prefixIcon: const Icon(Icons.search, color: _sub, size: 20),
            filled: true, fillColor: _card,
            contentPadding: const EdgeInsets.symmetric(vertical: 10),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _accent)),
          ),
        ),
      ),
      // Grid
      Expanded(
        child: _loadingServices
          ? const Center(child: CircularProgressIndicator(color: _accent))
          : filtered.isEmpty
            ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.apps_outage, color: _sub, size: 48), const SizedBox(height: 12),
                Text(_searchService.isEmpty ? 'Tidak ada layanan tersedia' : 'Layanan tidak ditemukan', style: const TextStyle(color: _sub)),
              ]))
            : GridView.builder(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.55),
                itemCount: filtered.length,
                itemBuilder: (_, i) {
                  final svc  = filtered[i];
                  final meta = _getMeta(svc.name);
                  return GestureDetector(
                    onTap: () => _fetchNumbers(svc),
                    child: Container(
                      decoration: BoxDecoration(
                        color: _card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF1E1E2A)),
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Row(children: [
                        // App icon/logo
                        Container(
                          width: 46, height: 46,
                          decoration: BoxDecoration(color: meta.color.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: () {
                              final logoSrc = (svc.logo != null && svc.logo!.isNotEmpty) ? svc.logo! : meta.logoUrl;
                              if (logoSrc != null && logoSrc.isNotEmpty) {
                                return Image.network(logoSrc, width: 46, height: 46, fit: BoxFit.contain,
                                  errorBuilder: (_, __, ___) => Icon(meta.icon, color: meta.color, size: 26));
                              }
                              return Icon(meta.icon, color: meta.color, size: 26);
                            }(),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(svc.name, style: const TextStyle(color: _text, fontWeight: FontWeight.w600, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                          const SizedBox(height: 6),
                          Row(children: [
                            const Icon(Icons.phone_outlined, color: _sub, size: 11), const SizedBox(width: 3),
                            Flexible(child: Text('${svc.stock.fmt()} nomor', style: const TextStyle(color: _sub, fontSize: 11), overflow: TextOverflow.ellipsis)),
                          ]),
                        ])),
                      ]),
                    ),
                  );
                },
              ),
      ),
    ]);
  }

  // ── Step 3: Nomor — OTPKU style (info card, qty selector, beli button) ──

  int _orderQty = 1; // quantity selector

  Widget _buildNumbersView() {
    final filtered  = _numbers.where((n) => n.number.contains(_searchNumber)).toList();
    final meta      = _getMeta(_selectedService?.name ?? '');

    return Column(children: [
      // Info negara + layanan + total
      Container(
        color: _bg, padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
        child: Column(children: [
          // Baris negara + layanan
          Row(children: [
            _infoChip(label: 'NEGARA', value: _selectedCountry?.name ?? ''),
            const SizedBox(width: 10),
            _infoChip(label: 'LAYANAN', value: _selectedService?.name ?? '', flex: 2),
          ]),
          const SizedBox(height: 8),
          // Total harga
          _infoChip(label: 'TOTAL', value: _selectedService?.priceFormatted ?? _kFallbackPriceFmt, valueColor: _accent, full: true),
          const SizedBox(height: 8),
          // Qty selector
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF1E1E2A))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.layers_outlined, color: _sub, size: 14),
                const SizedBox(width: 6),
                const Text('JUMLAH NOMOR', style: TextStyle(color: _sub, fontSize: 11, letterSpacing: 0.5)),
              ]),
            ),
            const Spacer(),
            // Qty buttons
            Row(children: [
              _qtyButton(Icons.remove, () { if (_orderQty > 1) setState(() => _orderQty--); }),
              Container(
                width: 44, alignment: Alignment.center,
                child: Text('$_orderQty', style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 16)),
              ),
              _qtyButton(Icons.add, () { if (_orderQty < 10) setState(() => _orderQty++); }),
            ]),
          ]),
          const SizedBox(height: 6),
          // Quick qty buttons
          Row(children: [
            for (final q in [1, 3, 5, 10]) ...[
              GestureDetector(
                onTap: () => setState(() => _orderQty = q),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: _orderQty == q ? _accent.withOpacity(0.15) : _card,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _orderQty == q ? _accent : const Color(0xFF1E1E2A), width: _orderQty == q ? 1.5 : 1),
                  ),
                  child: Text('${q}x', style: TextStyle(color: _orderQty == q ? _accent : _sub, fontWeight: FontWeight.w600, fontSize: 13)),
                ),
              ),
            ],
            const Spacer(),
            Text('Max 10 per order', style: const TextStyle(color: _sub, fontSize: 11)),
          ]),
        ]),
      ),
      // Info refund
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10)),
        child: Row(children: [
          const Icon(Icons.info_outline, color: _sub, size: 16),
          const SizedBox(width: 8),
          const Expanded(child: Text('Saldo dipotong saat pembelian. Bila SMS gagal masuk dalam 20 menit, dana otomatis dikembalikan per nomor. Multi-order diproses paralel.',
            style: TextStyle(color: _sub, fontSize: 11, height: 1.4))),
        ]),
      ),
      const SizedBox(height: 4),
      // Search bar
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: TextField(
          style: const TextStyle(color: _text, fontSize: 13),
          onChanged: (v) => setState(() => _searchNumber = v),
          decoration: InputDecoration(
            hintText: 'Cari nomor...', hintStyle: const TextStyle(color: _sub, fontSize: 13),
            prefixIcon: const Icon(Icons.search, color: _sub, size: 18),
            filled: true, fillColor: _card,
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _accent)),
          ),
        ),
      ),
      // List nomor
      Expanded(
        child: _loadingNumbers
          ? const Center(child: CircularProgressIndicator(color: _accent))
          : filtered.isEmpty
            ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.sim_card_outlined, color: _sub, size: 48), const SizedBox(height: 12),
                const Text('Tidak ada nomor tersedia', style: TextStyle(color: _sub)),
              ]))
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  final num    = filtered[i];
                  final canBuy = _balance >= num.price;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: _card, borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF1E1E2A))),
                    child: Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(num.number, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.5)),
                        const SizedBox(height: 4),
                        Row(children: [
                          Text(num.priceFormatted, style: TextStyle(color: meta.color, fontWeight: FontWeight.w600, fontSize: 12)),
                          const SizedBox(width: 8),
                          if (num.stock > 0)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: num.stock > 10 ? Colors.green.withOpacity(0.15) : Colors.orange.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(4)),
                              child: Text('Stok: ${num.stock}', style: TextStyle(
                                color: num.stock > 10 ? Colors.green : Colors.orange, fontSize: 10, fontWeight: FontWeight.w600)),
                            ),
                        ]),
                      ])),
                      GestureDetector(
                        onTap: canBuy ? () => _showConfirmOrder(num) : null,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          decoration: BoxDecoration(
                            color: canBuy ? meta.color.withOpacity(0.15) : _sub.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: canBuy ? meta.color.withOpacity(0.4) : Colors.transparent)),
                          child: Text('Beli', style: TextStyle(color: canBuy ? meta.color : _sub, fontWeight: FontWeight.bold, fontSize: 13)),
                        ),
                      ),
                    ]),
                  );
                },
              ),
      ),
      // Bottom CTA — beli sekarang (ambil nomor pertama available)
      if (filtered.isNotEmpty)
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _showConfirmOrder(filtered.first),
              icon: const Icon(Icons.shopping_bag_outlined, size: 18),
              label: const Text('nokos', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent, foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
          ),
        ),
    ]);
  }

  Widget _infoChip({required String label, required String value, Color? valueColor, bool full = false, int flex = 1}) {
    return Expanded(
      flex: flex,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF1E1E2A))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: _sub, fontSize: 10, letterSpacing: 0.5)),
          const SizedBox(height: 3),
          Text(value, style: TextStyle(color: valueColor ?? _text, fontWeight: FontWeight.bold, fontSize: 13), overflow: TextOverflow.ellipsis),
        ]),
      ),
    );
  }

  Widget _qtyButton(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFF2A2A3A))),
        child: Icon(icon, color: _text, size: 18),
      ),
    );
  }

  // ── Confirm Order ─────────────────────────────────────────────────────────

  void _showConfirmOrder(RotpNumber num) {
    showModalBottomSheet(
      context: context, backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _sub, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          const Text('Konfirmasi Order', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 20),
          _confirmRow('Nomor', num.number),
          _confirmRow('Layanan', _selectedService?.name ?? '-'),
          if (_selectedCountry != null)
            _confirmRow('Negara', '${_selectedCountry!.flag != null && !_selectedCountry!.flag!.startsWith('http') ? _selectedCountry!.flag! + ' ' : ''}${_selectedCountry!.name}'),
          _confirmRow('Harga', num.priceFormatted),
          _confirmRow('Saldo kamu', 'Rp${_balance.fmt()}'),
          _confirmRow('Sisa saldo', 'Rp${(_balance - num.price).fmt()}'),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => Navigator.pop(context),
              style: OutlinedButton.styleFrom(foregroundColor: _sub, side: const BorderSide(color: Color(0xFF2A2A3A)), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: const Text('Batal'),
            )),
            const SizedBox(width: 12),
            Expanded(child: ElevatedButton(
              onPressed: () { Navigator.pop(context); _orderNumber(num); },
              style: ElevatedButton.styleFrom(backgroundColor: _accent, foregroundColor: _bg, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0),
              child: const Text('Order Sekarang', style: TextStyle(fontWeight: FontWeight.bold)),
            )),
          ]),
        ]),
      ),
    );
  }

  Widget _confirmRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [
      Text(label, style: const TextStyle(color: _sub, fontSize: 13)),
      const Spacer(),
      Text(value, style: const TextStyle(color: _text, fontWeight: FontWeight.w600, fontSize: 13)),
    ]),
  );

  // ── OTP Sheet (mirip otpku.co.id) ────────────────────────────────────────

  void _showOtpSheet(RotpNumber num, String orderId, {
    required String phoneNumber,
    String createdAt = '',
    String activId   = '',
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      isScrollControlled: true,
      isDismissible: false,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          // Sync parent state ke sheet
          final otpReceived = _otpCode.isNotEmpty;
          final timedOut    = _otpCountdown <= 0 && !otpReceived;
          final meta        = _getMeta(_selectedService?.name ?? '');

          // Warna & label status (mirip otpku)
          Color statusColor;
          IconData statusIcon;
          String statusLabel;
          if (otpReceived) {
            statusColor = const Color(0xFF25D366);
            statusIcon  = Icons.check_circle_outline;
            statusLabel = 'SMS Diterima';
          } else if (timedOut) {
            statusColor = Colors.orange;
            statusIcon  = Icons.timer_off_outlined;
            statusLabel = 'Waktu Habis';
          } else {
            statusColor = Colors.orange;
            statusIcon  = Icons.hourglass_top_outlined;
            statusLabel = 'Menunggu SMS';
          }

          // Setiap kali parent setState -> sheet ikut rebuild karena addPostFrameCallback
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) setSheetState(() {});
          });

          return Padding(
            padding: EdgeInsets.fromLTRB(0, 0, 0, MediaQuery.of(ctx).viewInsets.bottom),
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  // Handle
                  Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(color: _sub.withOpacity(0.5), borderRadius: BorderRadius.circular(2))),

                  // Header "Detail Aktivasi"
                  Row(children: [
                    Container(width: 36, height: 36, decoration: BoxDecoration(color: meta.color.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                      child: Icon(Icons.receipt_long_outlined, color: meta.color, size: 18)),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('Detail Aktivasi', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 17))),
                    GestureDetector(
                      onTap: () { if (otpReceived || timedOut) { _otpTimer?.cancel(); Navigator.pop(ctx); } },
                      child: Container(width: 30, height: 30, decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(8)),
                        child: Icon(Icons.close, color: (otpReceived || timedOut) ? _sub : _sub.withOpacity(0.3), size: 16)),
                    ),
                  ]),

                  const SizedBox(height: 16),

                  // ── STATUS CARD (mirip otpku) ──
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: statusColor.withOpacity(0.4))),
                    child: Row(children: [
                      Icon(statusIcon, color: statusColor, size: 28),
                      const SizedBox(width: 12),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('STATUS', style: TextStyle(color: statusColor.withOpacity(0.7), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
                        const SizedBox(height: 2),
                        Text(statusLabel, style: TextStyle(color: statusColor, fontSize: 15, fontWeight: FontWeight.bold)),
                      ]),
                      if (!otpReceived && !timedOut) ...[
                        const Spacer(),
                        SizedBox(width: 20, height: 20, child: CircularProgressIndicator(value: _otpCountdown / 120, color: statusColor, backgroundColor: statusColor.withOpacity(0.2), strokeWidth: 2.5)),
                      ],
                    ]),
                  ),

                  const SizedBox(height: 12),

                  // ── SMS CODE box (muncul saat OTP diterima) ──
                  if (otpReceived) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF25D366).withOpacity(0.07),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.4))),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('SMS CODE', style: TextStyle(color: Color(0xFF25D366), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
                        const SizedBox(height: 8),
                        Row(children: [
                          Text(_otpCode, style: const TextStyle(color: Color(0xFF25D366), fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 6)),
                          const Spacer(),
                          GestureDetector(
                            onTap: () => _copyToClipboard(_otpCode, 'Kode OTP'),
                            child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: const Color(0xFF25D366).withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                              child: const Icon(Icons.copy_outlined, color: Color(0xFF25D366), size: 18)),
                          ),
                        ]),
                      ]),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // ── Nomor telepon ──
                  Container(
                    width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF1E1E2A))),
                    child: Row(children: [
                      Icon(Icons.phone_outlined, color: meta.color, size: 18), const SizedBox(width: 10),
                      Text(phoneNumber, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 0.5)),
                      const Spacer(),
                      GestureDetector(onTap: () => _copyToClipboard(phoneNumber, 'Nomor'),
                        child: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(6)),
                          child: const Icon(Icons.copy_outlined, color: _sub, size: 16))),
                    ]),
                  ),

                  const SizedBox(height: 12),

                  // ── Info rows (mirip otpku) ──
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF1E1E2A))),
                    child: Column(children: [
                      _detailRow('Layanan',       _selectedService?.name ?? '-'),
                      const Divider(color: Color(0xFF1E1E2A), height: 16),
                      _detailRow('Negara',        '${_selectedCountry?.flag ?? ''} ${_selectedCountry?.name ?? '-'}'),
                      const Divider(color: Color(0xFF1E1E2A), height: 16),
                      _detailRowWithCopy('Activation ID', activId.isNotEmpty ? activId : orderId, orderId),
                      const Divider(color: Color(0xFF1E1E2A), height: 16),
                      _detailRow('Harga', num.priceFormatted, valueColor: _accent),
                      if (createdAt.isNotEmpty) ...[
                        const Divider(color: Color(0xFF1E1E2A), height: 16),
                        _detailRow('Dibuat',      createdAt),
                      ],
                    ]),
                  ),

                  const SizedBox(height: 16),

                  // ── Timeout warning ──
                  if (timedOut) ...[
                    Container(
                      width: double.infinity, padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.orange.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.orange.withOpacity(0.3))),
                      child: Column(children: [
                        const Icon(Icons.timer_off, color: Colors.orange, size: 32), const SizedBox(height: 8),
                        const Text('OTP tidak masuk dalam 2 menit', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w600, fontSize: 13)),
                        const SizedBox(height: 4),
                        const Text('Kamu bisa cancel pesanan dan saldo akan dikembalikan.', style: TextStyle(color: _sub, fontSize: 12, height: 1.4), textAlign: TextAlign.center),
                      ]),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // ── Countdown bar (saat menunggu) ──
                  if (!otpReceived && !timedOut) ...[
                    Row(children: [
                      const Icon(Icons.access_time, color: _sub, size: 14),
                      const SizedBox(width: 6),
                      Text('Polling tiap 5 detik · Sisa ${_otpCountdown}s', style: const TextStyle(color: _sub, fontSize: 11)),
                    ]),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _otpCountdown / 120,
                        backgroundColor: const Color(0xFF1E1E2A),
                        color: _otpCountdown > 60 ? _accent : Colors.orange,
                        minHeight: 4,
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // ── Tombol Cek SMS (manual poll — muncul saat menunggu / timeout) ──
                  if (!otpReceived) ...[
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _checkingOtp ? null : () async {
                          setState(() => _checkingOtp = true);
                          setSheetState(() {});
                          await _pollOtp(orderId);
                          if (mounted) setState(() => _checkingOtp = false);
                          setSheetState(() {});
                        },
                        icon: _checkingOtp
                          ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: _accent, strokeWidth: 2))
                          : const Icon(Icons.refresh, size: 16),
                        label: Text(_checkingOtp ? 'Mengecek...' : 'Cek SMS', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _card,
                          foregroundColor: _accent,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: _accent.withOpacity(0.4))),
                          elevation: 0),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],

                  // ── Aksi bawah ──
                  if (otpReceived) ...[
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () { _otpTimer?.cancel(); Navigator.pop(ctx); },
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0),
                        child: const Text('Selesai', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ),
                    ),
                  ] else ...[
                    Row(children: [
                      Expanded(child: ElevatedButton.icon(
                        onPressed: () => _cancelOrder(orderId, setSheetState),
                        icon: const Icon(Icons.cancel_outlined, size: 15),
                        label: const Text('Batalkan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red.withOpacity(0.12), foregroundColor: Colors.red, padding: const EdgeInsets.symmetric(vertical: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.red.withOpacity(0.3))), elevation: 0),
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: OutlinedButton(
                        onPressed: () { Navigator.pop(ctx); },
                        style: OutlinedButton.styleFrom(foregroundColor: _sub, side: const BorderSide(color: Color(0xFF2A2A3A)), padding: const EdgeInsets.symmetric(vertical: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                        child: const Text('Tutup', style: TextStyle(fontSize: 13)),
                      )),
                    ]),
                  ],

                  const SizedBox(height: 12),

                  // ── Support ──
                  GestureDetector(
                    onTap: _csList.isNotEmpty ? () => _kirimBuktiWA(0) : null,
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.headset_mic_outlined, color: _sub, size: 14),
                      const SizedBox(width: 6),
                      Text('Butuh bantuan? Lapor ke tim support', style: TextStyle(color: _sub.withOpacity(0.7), fontSize: 12, decoration: TextDecoration.underline)),
                    ]),
                  ),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _detailRow(String label, String value, {Color? valueColor}) => Row(children: [
    Text(label, style: const TextStyle(color: _sub, fontSize: 13)),
    const Spacer(),
    Text(value, style: TextStyle(color: valueColor ?? _text, fontWeight: FontWeight.w600, fontSize: 13)),
  ]);

  Widget _detailRowWithCopy(String label, String display, String copyVal) => Row(children: [
    Text(label, style: const TextStyle(color: _sub, fontSize: 13)),
    const Spacer(),
    Text(display, style: const TextStyle(color: _text, fontWeight: FontWeight.w600, fontSize: 13)),
    const SizedBox(width: 6),
    GestureDetector(onTap: () => _copyToClipboard(copyVal, label),
      child: const Icon(Icons.copy_outlined, color: _sub, size: 14)),
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // FAYUPEDIA VIEWS
  // ══════════════════════════════════════════════════════════════════════════

  // ══════════════════════════════════════════════════════════════════════════
  // FAYUPEDIA SMM VIEWS
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildFayuServicesView() {
    if (_loadingFayuSvc) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFF118EEA)));
    }
    if (_fayuServices.isEmpty) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.campaign_outlined, color: Color(0xFF118EEA), size: 52),
          const SizedBox(height: 16),
          const Text('Belum ada layanan', style: TextStyle(color: _sub, fontSize: 14)),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _fayuFetchServices,
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Muat Ulang'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF118EEA),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ]),
      );
    }

    final filtered = _fayuServices.where((s) {
      final name = (s['name'] ?? s['service_name'] ?? '').toString().toLowerCase();
      return name.contains(_searchFayuSvc.toLowerCase());
    }).toList();

    return Column(children: [
      // Search bar
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: TextField(
          style: const TextStyle(color: _text, fontSize: 13),
          onChanged: (v) => setState(() => _searchFayuSvc = v),
          decoration: InputDecoration(
            hintText: 'Cari layanan (IG followers, TikTok views...)',
            hintStyle: const TextStyle(color: _sub, fontSize: 13),
            prefixIcon: const Icon(Icons.search, color: _sub, size: 18),
            filled: true, fillColor: _card,
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF118EEA))),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: const Color(0xFF118EEA).withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
            child: Text('${filtered.length} layanan', style: const TextStyle(color: Color(0xFF118EEA), fontSize: 11, fontWeight: FontWeight.w600)),
          ),
        ]),
      ),
      // List layanan
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          itemCount: filtered.length,
          itemBuilder: (_, i) {
            final svc  = filtered[i];
            final name = (svc['name'] ?? svc['service_name'] ?? 'Layanan').toString();
            final meta = _getMeta(name);
            final rate = svc['rate']?.toString() ?? '';
            final minO = svc['min']?.toString() ?? '';
            final maxO = svc['max']?.toString() ?? '';
            return GestureDetector(
              onTap: () => setState(() => _fayuSelectedSvc = svc),
              child: Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF1E1E2A)),
                ),
                child: Row(children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(color: meta.color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                    child: Icon(meta.icon, color: meta.color, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(name, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 13), maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 5),
                    Row(children: [
                      if (rate.isNotEmpty) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: const Color(0xFF118EEA).withOpacity(0.12), borderRadius: BorderRadius.circular(4)),
                          child: Text('Rp${(int.tryParse(rate) ?? 0).fmt()}/1K', style: const TextStyle(color: Color(0xFF118EEA), fontSize: 10, fontWeight: FontWeight.w600)),
                        ),
                        const SizedBox(width: 6),
                      ],
                      if (minO.isNotEmpty)
                        Text('Min: $minO', style: const TextStyle(color: _sub, fontSize: 10)),
                    ]),
                  ])),
                  const Icon(Icons.chevron_right, color: _sub, size: 18),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }

  Widget _buildFayuOrderForm() {
    final svc     = _fayuSelectedSvc!;
    final name    = (svc['name'] ?? svc['service_name'] ?? 'Layanan').toString();
    final meta    = _getMeta(name);
    final serviceId = int.tryParse(svc['id']?.toString() ?? '0') ?? 0;
    final rateRaw   = double.tryParse(svc['rate']?.toString() ?? '0') ?? 0;
    final minQty    = int.tryParse(svc['min']?.toString() ?? '10') ?? 10;
    final maxQty    = int.tryParse(svc['max']?.toString() ?? '1000') ?? 1000;

    final linkCtrl = TextEditingController();
    final qtyCtrl  = TextEditingController(text: minQty.toString());

    // Harga per 1K → hitung biaya
    int calcPrice(int qty) {
      if (rateRaw <= 0) return 0;
      // rateRaw = harga per 1000, tambah markup 2rb per 1000
      final basePerK  = rateRaw;
      final markupK   = 2000.0;
      final totalPerK = basePerK + markupK;
      return ((qty / 1000) * totalPerK).ceil();
    }

    return StatefulBuilder(builder: (ctx, setSt) {
      int qty   = int.tryParse(qtyCtrl.text) ?? minQty;
      int price = calcPrice(qty);

      return Column(children: [
        // Header
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: _bg,
          child: Row(children: [
            GestureDetector(
              onTap: () => setState(() => _fayuSelectedSvc = null),
              child: const Icon(Icons.arrow_back_ios, color: _sub, size: 16),
            ),
            const SizedBox(width: 10),
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(color: meta.color.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
              child: Icon(meta.icon, color: meta.color, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(name, style: const TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis)),
          ]),
        ),
        const Divider(height: 1, color: Color(0xFF1E1E2A)),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

              // Info layanan
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF1E1E2A))),
                child: Column(children: [
                  if (svc['description'] != null && svc['description'].toString().isNotEmpty) ...[
                    Align(alignment: Alignment.centerLeft, child: Text(svc['description'].toString(), style: const TextStyle(color: _sub, fontSize: 12, height: 1.5))),
                    const Divider(color: Color(0xFF1E1E2A), height: 16),
                  ],
                  Row(children: [
                    _detailRow('Min Order', minQty.toString()),
                    const SizedBox(width: 16),
                    _detailRow('Max Order', maxQty.toString()),
                  ]),
                  if (rateRaw > 0) ...[
                    const Divider(color: Color(0xFF1E1E2A), height: 16),
                    _detailRow('Harga Base', 'Rp${rateRaw.toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+$)'), (m) => '${m[1]}.')}/1K'),
                  ],
                ]),
              ),

              const SizedBox(height: 16),

              // Input Link
              const Text('Link / Target', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(height: 6),
              TextField(
                controller: linkCtrl,
                style: const TextStyle(color: _text, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'https://instagram.com/username atau URL post',
                  hintStyle: const TextStyle(color: _sub, fontSize: 12),
                  prefixIcon: const Icon(Icons.link, color: _sub, size: 18),
                  filled: true, fillColor: _card,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF118EEA))),
                ),
              ),

              const SizedBox(height: 16),

              // Input Quantity
              Row(children: [
                const Text('Jumlah', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 13)),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: Colors.orange.withOpacity(0.12), borderRadius: BorderRadius.circular(4)),
                  child: Text('Min: $minQty  Max: $maxQty', style: const TextStyle(color: Colors.orange, fontSize: 10)),
                ),
              ]),
              const SizedBox(height: 6),
              // TextField + tombol +/-
              Container(
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  IconButton(
                    onPressed: () {
                      final cur = int.tryParse(qtyCtrl.text) ?? minQty;
                      qtyCtrl.text = (cur - 100).clamp(minQty, maxQty).toString();
                      setSt(() {});
                    },
                    icon: const Icon(Icons.remove_circle_outline, color: Color(0xFF118EEA), size: 28),
                  ),
                  Expanded(child: TextField(
                    controller: qtyCtrl,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: _text, fontSize: 18, fontWeight: FontWeight.bold),
                    onChanged: (_) => setSt(() {}),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  )),
                  IconButton(
                    onPressed: () {
                      final cur = int.tryParse(qtyCtrl.text) ?? minQty;
                      qtyCtrl.text = (cur + 100).clamp(minQty, maxQty).toString();
                      setSt(() {});
                    },
                    icon: const Icon(Icons.add_circle_outline, color: Color(0xFF118EEA), size: 28),
                  ),
                ]),
              ),

              const SizedBox(height: 16),

              // Total biaya card — selalu tampil, update realtime
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFF118EEA).withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF118EEA).withOpacity(0.3)),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.receipt_outlined, color: Color(0xFF118EEA), size: 18),
                    const SizedBox(width: 8),
                    const Text('Rincian Biaya', style: TextStyle(color: _sub, fontSize: 11, fontWeight: FontWeight.w600)),
                  ]),
                  const SizedBox(height: 10),
                  // Breakdown
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('Harga base ($qty item)', style: const TextStyle(color: _sub, fontSize: 12)),
                    Text(rateRaw > 0 ? 'Rp${((qty / 1000) * rateRaw).ceil().fmt()}' : '-', style: const TextStyle(color: _text, fontSize: 12)),
                  ]),
                  const SizedBox(height: 4),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Biaya layanan', style: TextStyle(color: _sub, fontSize: 12)),
                    Text(rateRaw > 0 ? '+Rp${((qty / 1000) * 2000).ceil().fmt()}' : '-', style: const TextStyle(color: Colors.orange, fontSize: 12)),
                  ]),
                  const Divider(color: Color(0xFF1E1E2A), height: 14),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Total', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 13)),
                    Text(price > 0 ? 'Rp${price.fmt()}' : '-', style: const TextStyle(color: Color(0xFF118EEA), fontSize: 20, fontWeight: FontWeight.bold)),
                  ]),
                  const SizedBox(height: 8),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('Saldo kamu', style: TextStyle(color: _balance >= price ? Colors.green : Colors.red, fontSize: 11)),
                    Text('Rp${_balance.fmt()}', style: TextStyle(color: _balance >= price ? Colors.green : Colors.red, fontSize: 11, fontWeight: FontWeight.w600)),
                  ]),
                  if (price > 0) ...[
                    const SizedBox(height: 2),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Sisa saldo', style: TextStyle(color: _sub, fontSize: 11)),
                      Text('Rp${(_balance - price).fmt()}', style: TextStyle(color: _balance >= price ? _sub : Colors.red, fontSize: 11)),
                    ]),
                  ],
                ]),
              ),

              const SizedBox(height: 20),

              // Tombol order — selalu tampil
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _fayuOrdering ? null : () async {
                    final link = linkCtrl.text.trim();
                    final qty2 = int.tryParse(qtyCtrl.text) ?? 0;
                    if (link.isEmpty) { _snack('Isi link/target dulu!'); return; }
                    if (qty2 < minQty) { _snack('Jumlah minimal $minQty'); return; }
                    if (qty2 > maxQty) { _snack('Jumlah maksimal $maxQty'); return; }
                    if (_balance < price) { _snack('Saldo kurang!'); return; }
                    await _fayuPlaceOrder(serviceId: serviceId, link: link, quantity: qty2, price: price);
                  },
                  icon: _fayuOrdering
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.send_outlined, size: 18),
                  label: Text(_fayuOrdering ? 'Memproses...' : 'Order Sekarang', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF118EEA),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                ),
              ),
            ]),
          ),
        ),
      ]);
    });
  }

} // end _OtpStorePageState

// ─── Bottom Sheet: Picker CS ──────────────────────────────────────────────────

class _CsPickerSheet extends StatefulWidget {
  final List<CsContact> csList;
  final int amount;
  final String username;
  final XFile? buktiImage;
  final void Function(CsContact cs, String platform) onSelected;

  const _CsPickerSheet({required this.csList, required this.amount, required this.username, required this.buktiImage, required this.onSelected});

  @override
  State<_CsPickerSheet> createState() => _CsPickerSheetState();
}

class _CsPickerSheetState extends State<_CsPickerSheet> {
  static const _bg      = Color(0xFF0A0A0F);
  static const _card2   = Color(0xFF12121A);
  static const _accent  = Color(0xFF00E5FF);
  static const _text    = Color(0xFFE8E8F0);
  static const _sub     = Color(0xFF6B6B80);
  static const _waGreen = Color(0xFF25D366);
  static const _tgBlue  = Color(0xFF2AABEE);

  CsContact? _selectedCs;
  String? _selectedPlatform;

  @override
  void initState() {
    super.initState();
    if (widget.csList.length == 1) _selectedCs = widget.csList.first;
  }

  bool get _canSend => _selectedCs != null && _selectedPlatform != null;

  String _fmtAmount(int v) => v.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(color: Color(0xFF12121A), borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(margin: const EdgeInsets.only(top: 12, bottom: 4), width: 40, height: 4, decoration: BoxDecoration(color: _sub.withOpacity(0.4), borderRadius: BorderRadius.circular(2))),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
            child: Row(children: [
              const Icon(Icons.support_agent, color: _accent, size: 20), const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Pilih CS', style: TextStyle(color: _text, fontWeight: FontWeight.bold, fontSize: 16)),
                Text(widget.amount > 0 ? 'Top Up Rp${_fmtAmount(widget.amount)}' : 'Hubungi support', style: const TextStyle(color: _sub, fontSize: 12)),
              ]),
            ]),
          ),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8), child: Divider(color: Color(0xFF1E1E2A), height: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(children: widget.csList.map((cs) {
              final sel = _selectedCs == cs;
              return GestureDetector(
                onTap: () => setState(() { _selectedCs = cs; _selectedPlatform = null; }),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: sel ? _accent.withOpacity(0.08) : _bg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: sel ? _accent.withOpacity(0.6) : const Color(0xFF1E1E2A), width: sel ? 1.5 : 1)),
                  child: Row(children: [
                    Container(width: 38, height: 38, decoration: BoxDecoration(color: sel ? _accent.withOpacity(0.15) : const Color(0xFF1E1E2A), borderRadius: BorderRadius.circular(10)),
                      child: Center(child: Text(cs.name.isNotEmpty ? cs.name[0].toUpperCase() : 'C', style: TextStyle(color: sel ? _accent : _sub, fontWeight: FontWeight.bold, fontSize: 16)))),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(cs.name, style: TextStyle(color: sel ? _text : _sub, fontWeight: sel ? FontWeight.bold : FontWeight.normal, fontSize: 14)),
                      const SizedBox(height: 3),
                      Row(children: [
                        if (cs.hasWa) ...[const Icon(Icons.chat, color: _waGreen, size: 12), const SizedBox(width: 3), const Text('WA', style: TextStyle(color: _waGreen, fontSize: 11))],
                        if (cs.hasWa && cs.hasTelegram) const SizedBox(width: 8),
                        if (cs.hasTelegram) ...[const Icon(Icons.send, color: _tgBlue, size: 12), const SizedBox(width: 3), const Text('Telegram', style: TextStyle(color: _tgBlue, fontSize: 11))],
                      ]),
                    ])),
                    if (sel) const Icon(Icons.check_circle, color: _accent, size: 18),
                  ]),
                ),
              );
            }).toList()),
          ),
          if (_selectedCs != null) ...[
            const Padding(padding: EdgeInsets.fromLTRB(20, 4, 20, 6), child: Align(alignment: Alignment.centerLeft, child: Text('Pilih Platform', style: TextStyle(color: _sub, fontSize: 12)))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: [
                if (_selectedCs!.hasWa) Expanded(child: _platformBtn('WhatsApp', Icons.chat, _waGreen, 'wa')),
                if (_selectedCs!.hasWa && _selectedCs!.hasTelegram) const SizedBox(width: 10),
                if (_selectedCs!.hasTelegram) Expanded(child: _platformBtn('Telegram', Icons.send, _tgBlue, 'telegram')),
              ]),
            ),
            const SizedBox(height: 12),
          ],
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _canSend ? () => widget.onSelected(_selectedCs!, _selectedPlatform!) : null,
                icon: Icon(widget.buktiImage != null ? Icons.image_outlined : Icons.send, size: 16),
                label: Text(widget.buktiImage != null ? 'Kirim Bukti ke ${_selectedCs?.name ?? 'CS'}' : 'Kirim ke ${_selectedCs?.name ?? 'CS'}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _canSend ? _accent : _sub.withOpacity(0.2),
                  foregroundColor: _canSend ? Colors.black : _sub,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 0),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _platformBtn(String label, IconData icon, Color color, String platform) {
    final sel = _selectedPlatform == platform;
    return GestureDetector(
      onTap: () => setState(() => _selectedPlatform = platform),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: sel ? color.withOpacity(0.15) : _bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: sel ? color.withOpacity(0.7) : const Color(0xFF1E1E2A), width: sel ? 1.5 : 1)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: sel ? color : _sub, size: 16), const SizedBox(width: 8),
          Text(label, style: TextStyle(color: sel ? color : _sub, fontWeight: sel ? FontWeight.bold : FontWeight.normal, fontSize: 13)),
        ]),
      ),
    );
  }
}
