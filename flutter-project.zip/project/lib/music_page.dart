import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String _kYoutubeApiKey = 'AIzaSyAG4uwpnRt8AacbT6CTEAEPD6UOmz3P6rw';

// ─── PALETTE ────────────────────────────────────────────────
const _kBg        = Color(0xFF0A0A0F);
const _kCard      = Color(0xFF12121A);
const _kCard2     = Color(0xFF1A1A26);
const _kGreen     = Color(0xFF1DB954);   // Spotify green
const _kPurple    = Color(0xFF8B5CF6);
const _kPink      = Color(0xFFEC4899);
const _kWhite70   = Color(0xFFB3B3B3);
const _kWhite38   = Color(0xFF616161);

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});
  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _results    = [];
  List<Map<String, dynamic>> _favorites  = [];
  bool _isLoading   = false;
  String? _errorMsg;
  int _tab = 0; // 0=search, 1=favorites

  late AnimationController _glowCtrl;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _loadFavorites();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  // ── FAVORITES ──────────────────────────────────────────────
  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getStringList('music_favorites') ?? [];
    setState(() {
      _favorites = raw.map((e) => Map<String, dynamic>.from(jsonDecode(e))).toList();
    });
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('music_favorites', _favorites.map((e) => jsonEncode(e)).toList());
  }

  bool _isFavorite(String videoId) => _favorites.any((f) => f['videoId'] == videoId);

  void _toggleFavorite(Map<String, dynamic> item) {
    setState(() {
      if (_isFavorite(item['videoId'])) {
        _favorites.removeWhere((f) => f['videoId'] == item['videoId']);
      } else {
        _favorites.add(item);
      }
    });
    _saveFavorites();
  }

  // ── SEARCH ─────────────────────────────────────────────────
  Future<void> _search(String query) async {
    if (query.trim().isEmpty) return;
    setState(() { _isLoading = true; _errorMsg = null; _results = []; });

    final url = Uri.parse(
      'https://www.googleapis.com/youtube/v3/search'
      '?part=snippet&type=video&videoCategoryId=10&maxResults=20'
      '&q=${Uri.encodeComponent(query)}'
      '&key=$_kYoutubeApiKey',
    );

    try {
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data  = jsonDecode(res.body);
        final items = (data['items'] as List).map<Map<String, dynamic>>((item) => {
          'videoId'  : item['id']['videoId'],
          'title'    : item['snippet']['title'],
          'channel'  : item['snippet']['channelTitle'],
          'thumbnail': item['snippet']['thumbnails']['medium']['url'],
        }).toList();
        setState(() { _results = items; _isLoading = false; });
      } else {
        final err = jsonDecode(res.body);
        setState(() { _errorMsg = err['error']?['message'] ?? 'Error ${res.statusCode}'; _isLoading = false; });
      }
    } catch (e) {
      setState(() { _errorMsg = 'Gagal konek: $e'; _isLoading = false; });
    }
  }

  void _openPlayer(Map<String, dynamic> item) {
    Navigator.push(context, _fadeRoute(
      _MusicPlayerPage(item: item, onFavorite: _toggleFavorite, isFav: _isFavorite(item['videoId'])),
    ));
  }

  // ── BUILD ──────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Column(children: [
          _buildHeader(),
          _buildTabBar(),
          Expanded(
            child: _tab == 0 ? _buildSearchView() : _buildFavoritesView(),
          ),
        ]),
      ),
    );
  }

  // ── HEADER ─────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white54, size: 16),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('MUSIC', style: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron', letterSpacing: 3,
            )),
            const Text('Stream & Discover', style: TextStyle(color: _kWhite38, fontSize: 11)),
          ]),
        ),
        // Animated music icon
        AnimatedBuilder(
          animation: _glowCtrl,
          builder: (_, __) => Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [_kGreen.withValues(alpha: 0.3 + _glowCtrl.value * 0.3), _kPurple.withValues(alpha: 0.2)],
              ),
              boxShadow: [BoxShadow(color: _kGreen.withValues(alpha: 0.2 + _glowCtrl.value * 0.2), blurRadius: 12)],
            ),
            child: const Icon(Icons.music_note_rounded, color: _kGreen, size: 20),
          ),
        ),
      ]),
    );
  }

  // ── TAB BAR ────────────────────────────────────────────────
  Widget _buildTabBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
        ),
        child: Row(children: [
          _buildTab(0, Icons.search_rounded, 'CARI'),
          _buildTab(1, Icons.favorite_rounded, 'FAVORIT', count: _favorites.length),
        ]),
      ),
    );
  }

  Widget _buildTab(int idx, IconData icon, String label, {int count = 0}) {
    final active = _tab == idx;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = idx),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: active ? const LinearGradient(
              colors: [_kGreen, Color(0xFF15803D)],
            ) : null,
            color: active ? null : Colors.transparent,
            boxShadow: active ? [BoxShadow(color: _kGreen.withValues(alpha: 0.3), blurRadius: 8)] : [],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 15, color: active ? Colors.black : _kWhite38),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(
              color: active ? Colors.black : _kWhite38,
              fontSize: 11,
              fontWeight: FontWeight.w800,
              fontFamily: 'Orbitron',
            )),
            if (count > 0) ...[
              const SizedBox(width: 5),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  color: active ? Colors.black.withValues(alpha: 0.25) : _kGreen.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text('$count', style: TextStyle(
                  color: active ? Colors.black87 : _kGreen, fontSize: 9, fontWeight: FontWeight.bold,
                )),
              ),
            ],
          ]),
        ),
      ),
    );
  }

  // ── SEARCH VIEW ────────────────────────────────────────────
  Widget _buildSearchView() {
    return Column(children: [
      // Search bar
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
        child: Container(
          height: 50,
          decoration: BoxDecoration(
            color: _kCard2,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: Row(children: [
            const SizedBox(width: 14),
            const Icon(Icons.search_rounded, color: _kWhite38, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                decoration: const InputDecoration(
                  hintText: 'Judul lagu, artis, album...',
                  hintStyle: TextStyle(color: _kWhite38, fontSize: 13),
                  border: InputBorder.none,
                  isDense: true,
                ),
                onSubmitted: _search,
              ),
            ),
            GestureDetector(
              onTap: () => _search(_searchCtrl.text),
              child: Container(
                margin: const EdgeInsets.all(6),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _kGreen,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text('GO', style: TextStyle(
                  color: Colors.black, fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1,
                )),
              ),
            ),
          ]),
        ),
      ),

      const SizedBox(height: 14),

      Expanded(child: _isLoading
        ? _buildLoadingShimmer()
        : _errorMsg != null
          ? _buildError()
          : _results.isEmpty
            ? _buildEmptySearch()
            : _buildResultsList(),
      ),
    ]);
  }

  Widget _buildLoadingShimmer() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: 6,
      itemBuilder: (_, i) => _ShimmerCard(delay: i * 80),
    );
  }

  Widget _buildError() {
    return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.wifi_off_rounded, color: _kWhite38, size: 48),
      const SizedBox(height: 12),
      Text(_errorMsg!, style: const TextStyle(color: _kWhite38, fontSize: 13), textAlign: TextAlign.center),
    ]));
  }

  Widget _buildEmptySearch() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(children: [
        const SizedBox(height: 20),
        // Genre quick picks
        const Align(alignment: Alignment.centerLeft, child: Text(
          'GENRE POPULER', style: TextStyle(color: _kWhite38, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 2),
        )),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          '🎵 Pop', '🎸 Rock', '🎤 Hip-Hop', '🎹 Jazz',
          '🔥 Viral', '💙 Lofi', '🇮🇩 Indonesia', '🌙 Sad',
        ].map((g) => GestureDetector(
          onTap: () {
            _searchCtrl.text = g.substring(3);
            _search(g.substring(3));
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _kCard2,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: Text(g, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ),
        )).toList()),

        const SizedBox(height: 32),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _kGreen.withValues(alpha: 0.15)),
          ),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _kGreen.withValues(alpha: 0.1),
                border: Border.all(color: _kGreen.withValues(alpha: 0.3)),
              ),
              child: const Icon(Icons.search_rounded, color: _kGreen, size: 32),
            ),
            const SizedBox(height: 16),
            const Text('Temukan Musikmu', style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15,
            )),
            const SizedBox(height: 6),
            const Text('Cari lagu, artis, atau album favoritmu', style: TextStyle(color: _kWhite38, fontSize: 12),
              textAlign: TextAlign.center),
          ]),
        ),
      ]),
    );
  }

  Widget _buildResultsList() {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(children: [
          Text('${_results.length} hasil', style: const TextStyle(color: _kWhite38, fontSize: 12)),
          const Spacer(),
          const Text('HASIL PENCARIAN', style: TextStyle(color: _kWhite38, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 1)),
        ]),
      ),
      const SizedBox(height: 10),
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: _results.length,
          itemBuilder: (_, i) => _buildTrackCard(_results[i], i),
        ),
      ),
    ]);
  }

  // ── FAVORITES VIEW ─────────────────────────────────────────
  Widget _buildFavoritesView() {
    if (_favorites.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _kPink.withValues(alpha: 0.08),
            border: Border.all(color: _kPink.withValues(alpha: 0.25)),
          ),
          child: const Icon(Icons.favorite_border_rounded, color: _kPink, size: 40),
        ),
        const SizedBox(height: 20),
        const Text('Belum Ada Favorit', style: TextStyle(
          color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold,
        )),
        const SizedBox(height: 8),
        const Text('Tambah lagu dari hasil pencarian', style: TextStyle(color: _kWhite38, fontSize: 13)),
      ]));
    }

    return Column(children: [
      // Playlist header card
      Container(
        margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [_kPink.withValues(alpha: 0.3), _kPurple.withValues(alpha: 0.2)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: _kPink.withValues(alpha: 0.25)),
        ),
        child: Row(children: [
          // Grid thumbnail preview
          SizedBox(
            width: 64,
            height: 64,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: _buildPlaylistCover(),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('❤️ FAVORIT SAYA', style: TextStyle(
              color: Colors.white, fontFamily: 'Orbitron', fontSize: 11,
              fontWeight: FontWeight.w900, letterSpacing: 1,
            )),
            const SizedBox(height: 4),
            Text('${_favorites.length} lagu', style: const TextStyle(color: _kWhite70, fontSize: 12)),
            const SizedBox(height: 4),
            const Text('Playlist Pribadi', style: TextStyle(color: _kWhite38, fontSize: 10)),
          ])),
          GestureDetector(
            onTap: () => _openPlayer(_favorites[0]),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _kGreen,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: _kGreen.withValues(alpha: 0.4), blurRadius: 12)],
              ),
              child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 22),
            ),
          ),
        ]),
      ),

      const SizedBox(height: 8),

      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(children: [
          const Text('DAFTAR LAGU', style: TextStyle(color: _kWhite38, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 2)),
          const Spacer(),
          const Icon(Icons.shuffle_rounded, color: _kWhite38, size: 16),
        ]),
      ),
      const SizedBox(height: 8),

      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: _favorites.length,
          itemBuilder: (_, i) => _buildTrackCard(_favorites[i], i, showIndex: true, fromFav: true),
        ),
      ),
    ]);
  }

  Widget _buildPlaylistCover() {
    if (_favorites.isEmpty) {
      return Container(color: _kCard2, child: const Icon(Icons.music_note_rounded, color: _kWhite38));
    }
    final max = math.min(4, _favorites.length);
    if (max == 1) {
      return Image.network(_favorites[0]['thumbnail'] ?? '', fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: _kCard2));
    }
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      itemCount: max,
      itemBuilder: (_, i) => Image.network(_favorites[i]['thumbnail'] ?? '', fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: _kCard2)),
    );
  }

  // ── TRACK CARD ─────────────────────────────────────────────
  Widget _buildTrackCard(Map<String, dynamic> item, int index, {bool showIndex = false, bool fromFav = false}) {
    final fav  = _isFavorite(item['videoId']);

    return GestureDetector(
      onTap: () => _openPlayer(item),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withValues(alpha: 0.05)),
        ),
        child: Row(children: [
          // Index or thumbnail
          if (showIndex)
            SizedBox(
              width: 28,
              child: Text('${index + 1}', style: const TextStyle(
                color: _kWhite38, fontSize: 13, fontWeight: FontWeight.bold,
              ), textAlign: TextAlign.center),
            )
          else
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(item['thumbnail'] ?? '', width: 52, height: 52, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(width: 52, height: 52, color: _kCard2,
                  child: const Icon(Icons.music_note_rounded, color: _kWhite38, size: 20))),
            ),

          if (showIndex) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(item['thumbnail'] ?? '', width: 48, height: 48, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(width: 48, height: 48, color: _kCard2,
                  child: const Icon(Icons.music_note_rounded, color: _kWhite38, size: 18))),
            ),
          ],

          const SizedBox(width: 12),

          // Info
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item['title'] ?? '', style: const TextStyle(
              color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600,
            ), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(item['channel'] ?? '', style: const TextStyle(color: _kWhite38, fontSize: 11),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),

          // Fav button
          GestureDetector(
            onTap: () { setState(() {}); _toggleFavorite(item); },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Icon(
                fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: fav ? _kPink : _kWhite38,
                size: 18,
              ),
            ),
          ),

          // Play button
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _kGreen.withValues(alpha: 0.15),
              border: Border.all(color: _kGreen.withValues(alpha: 0.3)),
            ),
            child: const Icon(Icons.play_arrow_rounded, color: _kGreen, size: 18),
          ),
        ]),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// SHIMMER CARD
// ──────────────────────────────────────────────────────────────
class _ShimmerCard extends StatefulWidget {
  final int delay;
  const _ShimmerCard({required this.delay});
  @override
  State<_ShimmerCard> createState() => _ShimmerCardState();
}

class _ShimmerCardState extends State<_ShimmerCard> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Color.lerp(_kCard, _kCard2, _anim.value),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          Container(width: 52, height: 52, decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.05 + _anim.value * 0.05),
            borderRadius: BorderRadius.circular(8),
          )),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(height: 12, width: double.infinity,
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.05 + _anim.value * 0.05),
                borderRadius: BorderRadius.circular(6))),
            const SizedBox(height: 8),
            Container(height: 10, width: 120,
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.03 + _anim.value * 0.03),
                borderRadius: BorderRadius.circular(6))),
          ])),
        ]),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// MUSIC PLAYER PAGE
// ──────────────────────────────────────────────────────────────
class _MusicPlayerPage extends StatefulWidget {
  final Map<String, dynamic> item;
  final Function(Map<String, dynamic>) onFavorite;
  final bool isFav;

  const _MusicPlayerPage({required this.item, required this.onFavorite, required this.isFav});
  @override
  State<_MusicPlayerPage> createState() => _MusicPlayerPageState();
}

class _MusicPlayerPageState extends State<_MusicPlayerPage> with TickerProviderStateMixin {
  late YoutubePlayerController _ytCtrl;
  late bool _isFav;
  late AnimationController _rotateCtrl;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _isFav = widget.isFav;
    _rotateCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
    _pulseCtrl  = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _ytCtrl = YoutubePlayerController(
      initialVideoId: widget.item['videoId'],
      flags: const YoutubePlayerFlags(autoPlay: true, mute: false),
    );
  }

  @override
  void dispose() {
    _rotateCtrl.dispose();
    _pulseCtrl.dispose();
    _ytCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayerBuilder(
      player: YoutubePlayer(controller: _ytCtrl, showVideoProgressIndicator: true,
        progressIndicatorColor: _kGreen,
        progressColors: const ProgressBarColors(
          playedColor: _kGreen,
          handleColor: _kGreen,
          bufferedColor: Color(0xFF2A2A2A),
          backgroundColor: Color(0xFF1A1A1A),
        )),
      builder: (ctx, player) => Scaffold(
        backgroundColor: _kBg,
        body: SafeArea(child: Column(children: [
          // Top bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
                  ),
                  child: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white54, size: 20),
                ),
              ),
              const Expanded(child: Center(child: Text('NOW PLAYING', style: TextStyle(
                color: _kWhite38, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 2,
              )))),
              GestureDetector(
                onTap: () {
                  setState(() => _isFav = !_isFav);
                  widget.onFavorite(widget.item);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _isFav ? _kPink.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _isFav ? _kPink.withValues(alpha: 0.4) : Colors.white.withValues(alpha: 0.08)),
                  ),
                  child: Icon(
                    _isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: _isFav ? _kPink : Colors.white54, size: 18,
                  ),
                ),
              ),
            ]),
          ),

          const SizedBox(height: 20),

          // Rotating album art
          AnimatedBuilder(
            animation: _rotateCtrl,
            builder: (_, __) => Transform.rotate(
              angle: _rotateCtrl.value * 2 * math.pi,
              child: AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: _kGreen.withValues(alpha: 0.15 + _pulseCtrl.value * 0.2), blurRadius: 40, spreadRadius: 4),
                      BoxShadow(color: _kPurple.withValues(alpha: 0.1 + _pulseCtrl.value * 0.1), blurRadius: 60),
                    ],
                    border: Border.all(color: Colors.white.withValues(alpha: 0.08), width: 3),
                  ),
                  child: ClipOval(
                    child: Image.network(
                      widget.item['thumbnail'] ?? '',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: _kCard2,
                        child: const Icon(Icons.music_note_rounded, color: _kWhite38, size: 60),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 6),

          // Center dot
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 10, height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _kGreen,
                boxShadow: [BoxShadow(color: _kGreen.withValues(alpha: 0.5 + _pulseCtrl.value * 0.4), blurRadius: 10)],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Title & channel
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(children: [
              Text(widget.item['title'] ?? '', style: const TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800,
              ), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 6),
              Text(widget.item['channel'] ?? '', style: const TextStyle(color: _kWhite38, fontSize: 13)),
            ]),
          ),

          const SizedBox(height: 20),

          // Youtube player
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: player,
            ),
          ),

          const Spacer(),

          // Bottom action bar
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _PlayerActionBtn(Icons.shuffle_rounded, 'Acak', Colors.white38, () {}),
              _PlayerActionBtn(Icons.skip_previous_rounded, '', _kGreen, () {}),
              _PlayerActionBtn(Icons.skip_next_rounded, '', _kGreen, () {}),
              _PlayerActionBtn(Icons.repeat_rounded, 'Ulang', Colors.white38, () {}),
            ]),
          ),
        ])),
      ),
    );
  }
}

class _PlayerActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _PlayerActionBtn(this.icon, this.label, this.color, this.onTap);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 26),
        if (label.isNotEmpty) ...[
          const SizedBox(height: 3),
          Text(label, style: TextStyle(color: color, fontSize: 9)),
        ],
      ]),
    );
  }
}

// ── ROUTE HELPER ────────────────────────────────────────────
Route _fadeRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, a, __) => FadeTransition(opacity: a, child: page),
  transitionDuration: const Duration(milliseconds: 300),
);
