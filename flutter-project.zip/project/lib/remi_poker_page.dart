import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config_service.dart';
// lib/remi_poker_page.dart
// ─────────────────────────────────────────────────────────────
//  REMI POKER — 5 Card Draw, vs Bot, Kasino Klasik
//  Koin pakai SharedPreferences key: 'poker_coins'
// ─────────────────────────────────────────────────────────────
import 'dart:async';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'asset_service.dart';

// ══════════════════════════════════════════════════════════════
// MODEL KARTU
// ══════════════════════════════════════════════════════════════
enum Suit { spade, heart, diamond, club }

extension SuitExt on Suit {
  String get symbol {
    switch (this) {
      case Suit.spade:   return '♠';
      case Suit.heart:   return '♥';
      case Suit.diamond: return '♦';
      case Suit.club:    return '♣';
    }
  }
  Color get color {
    switch (this) {
      case Suit.spade:   return const Color(0xFF1A1A2E);
      case Suit.heart:   return const Color(0xFFC0392B);
      case Suit.diamond: return const Color(0xFFC0392B);
      case Suit.club:    return const Color(0xFF1A1A2E);
    }
  }
  bool get isRed => this == Suit.heart || this == Suit.diamond;
}

class PlayingCard {
  final int value; // 2-14 (14=Ace)
  final Suit suit;
  bool selected; // untuk draw phase
  bool faceUp;

  PlayingCard({required this.value, required this.suit, this.selected = false, this.faceUp = true});

  String get rankLabel {
    switch (value) {
      case 11: return 'J';
      case 12: return 'Q';
      case 13: return 'K';
      case 14: return 'A';
      default: return '$value';
    }
  }

  PlayingCard copyWith({bool? selected, bool? faceUp}) =>
      PlayingCard(value: value, suit: suit, selected: selected ?? this.selected, faceUp: faceUp ?? this.faceUp);
}

// ══════════════════════════════════════════════════════════════
// HAND EVALUATOR
// ══════════════════════════════════════════════════════════════
enum HandRank {
  highCard, onePair, twoPair, threeOfAKind, straight,
  flush, fullHouse, fourOfAKind, straightFlush, royalFlush
}

extension HandRankExt on HandRank {
  String get label {
    switch (this) {
      case HandRank.highCard:      return 'High Card';
      case HandRank.onePair:       return 'One Pair';
      case HandRank.twoPair:       return 'Two Pair';
      case HandRank.threeOfAKind:  return 'Three of a Kind';
      case HandRank.straight:      return 'Straight';
      case HandRank.flush:         return 'Flush';
      case HandRank.fullHouse:     return 'Full House';
      case HandRank.fourOfAKind:   return 'Four of a Kind';
      case HandRank.straightFlush: return 'Straight Flush';
      case HandRank.royalFlush:    return 'Royal Flush';
    }
  }
  Color get color {
    switch (this) {
      case HandRank.highCard:      return const Color(0xFF95A5A6);
      case HandRank.onePair:       return const Color(0xFF3498DB);
      case HandRank.twoPair:       return const Color(0xFF2ECC71);
      case HandRank.threeOfAKind:  return const Color(0xFFF39C12);
      case HandRank.straight:      return const Color(0xFFE67E22);
      case HandRank.flush:         return const Color(0xFF9B59B6);
      case HandRank.fullHouse:     return const Color(0xFFE74C3C);
      case HandRank.fourOfAKind:   return const Color(0xFFFFD700);
      case HandRank.straightFlush: return const Color(0xFFFF6B6B);
      case HandRank.royalFlush:    return const Color(0xFFFF1744);
    }
  }
}

class HandResult {
  final HandRank rank;
  final int score; // untuk compare
  final String description;
  const HandResult(this.rank, this.score, this.description);
}

class HandEvaluator {
  static HandResult evaluate(List<PlayingCard> cards) {
    assert(cards.length == 5);
    final sorted = List<PlayingCard>.from(cards)..sort((a, b) => b.value.compareTo(a.value));
    final values = sorted.map((c) => c.value).toList();
    final suits  = sorted.map((c) => c.suit).toSet();

    final isFlush    = suits.length == 1;
    final diffs      = List.generate(4, (i) => values[i] - values[i + 1]);
    final isStraight = diffs.every((d) => d == 1) ||
        (values[0] == 14 && values[1] == 5 && diffs.sublist(1).every((d) => d == 1));

    final freq = <int, int>{};
    for (final v in values) freq[v] = (freq[v] ?? 0) + 1;
    final counts = freq.values.toList()..sort((a, b) => b.compareTo(a));

    int score = _buildScore(values);

    if (isFlush && isStraight) {
      if (values[0] == 14 && values[1] == 13) {
        return HandResult(HandRank.royalFlush, 9000000 + score, 'Royal Flush');
      }
      return HandResult(HandRank.straightFlush, 8000000 + score, 'Straight Flush');
    }
    if (counts[0] == 4) return HandResult(HandRank.fourOfAKind, 7000000 + score, 'Four of a Kind');
    if (counts[0] == 3 && counts[1] == 2) return HandResult(HandRank.fullHouse, 6000000 + score, 'Full House');
    if (isFlush)    return HandResult(HandRank.flush,         5000000 + score, 'Flush');
    if (isStraight) return HandResult(HandRank.straight,      4000000 + score, 'Straight');
    if (counts[0] == 3) return HandResult(HandRank.threeOfAKind, 3000000 + score, 'Three of a Kind');
    if (counts[0] == 2 && counts[1] == 2) return HandResult(HandRank.twoPair,   2000000 + score, 'Two Pair');
    if (counts[0] == 2) return HandResult(HandRank.onePair,   1000000 + score, 'One Pair');
    return HandResult(HandRank.highCard, score, 'High Card');
  }

  static int _buildScore(List<int> values) {
    int s = 0;
    for (int i = 0; i < values.length; i++) s += values[i] * pow(15, 4 - i).toInt();
    return s;
  }
}

// ══════════════════════════════════════════════════════════════
// BOT AI
// ══════════════════════════════════════════════════════════════
class BotPlayer {
  final String name;
  final int difficulty; // 1=easy 2=medium 3=hard
  List<PlayingCard> hand = [];
  int chips;
  bool folded = false;
  int currentBet = 0;
  String action = '';

  BotPlayer({required this.name, required this.difficulty, this.chips = 1000});

  /// Kartu mana yang dibuang saat draw phase
  List<int> decideDiscard() {
    final result = HandEvaluator.evaluate(hand);
    final discard = <int>[];

    switch (result.rank) {
      case HandRank.royalFlush:
      case HandRank.straightFlush:
      case HandRank.fourOfAKind:
      case HandRank.fullHouse:
      case HandRank.flush:
      case HandRank.straight:
        return []; // buang nothing
      case HandRank.threeOfAKind:
        // buang 2 kartu bukan trips
        final freq = <int, int>{};
        for (final c in hand) freq[c.value] = (freq[c.value] ?? 0) + 1;
        for (int i = 0; i < hand.length; i++) {
          if (freq[hand[i].value]! < 3) discard.add(i);
        }
        return discard;
      case HandRank.twoPair:
        // buang 1 kartu bukan pair
        final freq = <int, int>{};
        for (final c in hand) freq[c.value] = (freq[c.value] ?? 0) + 1;
        for (int i = 0; i < hand.length; i++) {
          if (freq[hand[i].value] == 1) discard.add(i);
        }
        return discard;
      case HandRank.onePair:
        // buang 3 kartu bukan pair
        final freq = <int, int>{};
        for (final c in hand) freq[c.value] = (freq[c.value] ?? 0) + 1;
        for (int i = 0; i < hand.length; i++) {
          if (freq[hand[i].value] == 1) discard.add(i);
        }
        return discard;
      default:
        // high card: buang 3 kartu terendah
        final sorted = List.generate(5, (i) => i)..sort((a, b) => hand[b].value.compareTo(hand[a].value));
        return sorted.sublist(2);
    }
  }

  /// Keputusan taruhan: fold/check/call/raise
  String decideBet(int currentBet, int myBet, int pot, HandResult result) {
    final gap = currentBet - myBet;
    final rng = Random();

    // Easy: random lebih sering
    if (difficulty == 1) {
      if (rng.nextDouble() < 0.2) { folded = true; return 'fold'; }
      if (gap == 0) return 'check';
      return rng.nextBool() ? 'call' : 'fold';
    }

    // Medium
    if (difficulty == 2) {
      switch (result.rank) {
        case HandRank.highCard:
        case HandRank.onePair:
          if (gap > 100) { folded = true; return 'fold'; }
          return gap == 0 ? 'check' : 'call';
        case HandRank.twoPair:
        case HandRank.threeOfAKind:
          return gap == 0 ? 'raise' : 'call';
        default:
          return 'raise';
      }
    }

    // Hard
    switch (result.rank) {
      case HandRank.highCard:
        if (gap > 50) { folded = true; return 'fold'; }
        return gap == 0 ? 'check' : (rng.nextDouble() < 0.3 ? 'call' : 'fold');
      case HandRank.onePair:
        return gap == 0 ? 'check' : 'call';
      case HandRank.twoPair:
      case HandRank.threeOfAKind:
        return 'raise';
      case HandRank.straight:
      case HandRank.flush:
      case HandRank.fullHouse:
      case HandRank.fourOfAKind:
      case HandRank.straightFlush:
      case HandRank.royalFlush:
        return 'raise';
    }
  }
}

// ══════════════════════════════════════════════════════════════
// GAME STATE
// ══════════════════════════════════════════════════════════════
enum GamePhase { lobby, deal, betRound1, draw, betRound2, showdown, result }

class PokerGame {
  int numPlayers; // 2, 4, 6
  int playerChips;
  List<BotPlayer> bots = [];
  List<PlayingCard> playerHand = [];
  List<PlayingCard> deck = [];
  int pot = 0;
  int ante;
  int currentBet = 0;
  int playerBet = 0;
  GamePhase phase = GamePhase.lobby;
  HandResult? playerResult;
  String? winnerName;
  bool playerFolded = false;
  int roundsPlayed = 0;
  int wins = 0;
  int losses = 0;

  PokerGame({required this.numPlayers, required this.playerChips, required this.ante});

  void buildDeck() {
    deck = [];
    for (final suit in Suit.values) {
      for (int v = 2; v <= 14; v++) {
        deck.add(PlayingCard(value: v, suit: suit));
      }
    }
    deck.shuffle(Random());
  }

  PlayingCard draw() => deck.removeLast();

  void deal() {
    buildDeck();
    playerHand = List.generate(5, (_) => draw());
    playerFolded = false;
    playerBet = 0;
    currentBet = ante;
    pot = 0;

    for (final bot in bots) {
      bot.hand = List.generate(5, (_) => draw());
      bot.folded = false;
      bot.currentBet = 0;
      bot.action = '';
    }

    // Ante dari semua
    pot += ante;
    playerBet = ante;
    playerChips -= ante;
    for (final bot in bots) {
      final a = min(ante, bot.chips);
      bot.currentBet = a;
      bot.chips -= a;
      pot += a;
    }

    phase = GamePhase.betRound1;
  }

  void playerCall() {
    final gap = currentBet - playerBet;
    final pay = min(gap, playerChips);
    playerChips -= pay;
    playerBet += pay;
    pot += pay;
  }

  void playerRaise(int amount) {
    final gap = currentBet - playerBet + amount;
    final pay = min(gap, playerChips);
    playerChips -= pay;
    playerBet += pay;
    pot += pay;
    currentBet = playerBet;
  }

  void playerCheck() {} // no cost

  void playerFold() { playerFolded = true; }

  void processBotBets() {
    for (final bot in bots) {
      if (bot.folded) continue;
      final result = HandEvaluator.evaluate(bot.hand);
      final action = bot.decideBet(currentBet, bot.currentBet, pot, result);
      bot.action = action;
      if (action == 'fold') continue;
      if (action == 'call') {
        final gap = currentBet - bot.currentBet;
        final pay = min(gap, bot.chips);
        bot.chips -= pay;
        bot.currentBet += pay;
        pot += pay;
      }
      if (action == 'raise') {
        final raiseAmt = min(ante * 2, bot.chips);
        final total = currentBet - bot.currentBet + raiseAmt;
        final pay = min(total, bot.chips);
        bot.chips -= pay;
        bot.currentBet += pay;
        pot += pay;
        if (bot.currentBet > currentBet) currentBet = bot.currentBet;
      }
      if (action == 'check') {}
    }
  }

  void processDrawPhase(List<int> discardIdx) {
    // Tukar kartu player
    for (final i in discardIdx) {
      playerHand[i] = draw()..faceUp = true;
    }
    // Bot tukar kartu
    for (final bot in bots) {
      if (bot.folded) continue;
      final discards = bot.decideDiscard();
      for (final i in discards) {
        if (deck.isNotEmpty) bot.hand[i] = draw();
      }
    }
  }

  HandResult showdown() {
    playerResult = HandEvaluator.evaluate(playerHand);

    if (playerFolded) {
      // bot aktif pertama menang
      final winner = bots.firstWhere((b) => !b.folded, orElse: () => bots.first);
      winner.chips += pot;
      winnerName = winner.name;
      losses++;
      roundsPlayed++;
      return playerResult!;
    }

    // Semua tunjuk kartu
    HandResult best = playerResult!;
    String bestName = 'Kamu';

    for (final bot in bots) {
      if (bot.folded) continue;
      final res = HandEvaluator.evaluate(bot.hand);
      if (res.score > best.score) {
        best = res;
        bestName = bot.name;
      }
    }

    winnerName = bestName;
    if (bestName == 'Kamu') {
      playerChips += pot;
      wins++;
    } else {
      final winner = bots.firstWhere((b) => b.name == bestName);
      winner.chips += pot;
      losses++;
    }
    roundsPlayed++;
    return playerResult!;
  }
}

// ══════════════════════════════════════════════════════════════
// AUDIO MANAGER
// ══════════════════════════════════════════════════════════════
class _PokerAudio {
  final AudioPlayer _bgPlayer = AudioPlayer();
  final AudioPlayer _sfxPlayer = AudioPlayer();
  bool _bgPlaying = false;

  Future<void> startBgMusic() async {
    if (_bgPlaying) return;
    try {
      final path = await AssetService.audioPath('casino_bg.mp3');
      await _bgPlayer.setReleaseMode(ReleaseMode.loop);
      await _bgPlayer.setVolume(0.35);
      await _bgPlayer.play(DeviceFileSource(path));
      _bgPlaying = true;
    } catch (_) {
      // fallback: tidak ada musik
    }
  }

  Future<void> stopBgMusic() async {
    await _bgPlayer.stop();
    _bgPlaying = false;
  }

  Future<void> playSfx(String name) async {
    try {
      // Map poker sfx → casino sfx
      final map = {
        'deal': 'spin.mp3',
        'chip': 'spin.mp3',
        'win': 'win.mp3',
        'lose': 'lose.mp3',
      };
      final file = map[name] ?? 'spin.mp3';
      final path = await AssetService.audioPath(file);
      await _sfxPlayer.stop();
      await _sfxPlayer.play(DeviceFileSource(path));
    } catch (_) {}
  }

  void dispose() {
    _bgPlayer.dispose();
    _sfxPlayer.dispose();
  }
}

// ══════════════════════════════════════════════════════════════
// LOBBY PAGE
// ══════════════════════════════════════════════════════════════
class RemiPokerPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const RemiPokerPage({
    super.key,
    this.username = '',
    this.sessionKey = '',
  });

  @override
  State<RemiPokerPage> createState() => _RemiPokerPageState();
}

class _RemiPokerPageState extends State<RemiPokerPage>
    with SingleTickerProviderStateMixin {
  int _coins = 1000;
  int _selectedPlayers = 4;
  int _selectedAnte = 50;
  late AnimationController _chipCtrl;
  late Animation<double> _chipAnim;
  final _audio = _PokerAudio();

  @override
  void initState() {
    super.initState();
    _chipCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _chipAnim = CurvedAnimation(parent: _chipCtrl, curve: Curves.elasticOut);
    _chipCtrl.forward();
    _loadCoins();
    _audio.startBgMusic();
  }

  Future<void> _loadCoins() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _coins = prefs.getInt('poker_coins') ?? 1000);
  }

  Future<void> _saveCoins(int v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('poker_coins', v);
  }

  @override
  void dispose() {
    _chipCtrl.dispose();
    _audio.dispose();
    super.dispose();
  }

  void _startGame() {
    if (_coins < _selectedAnte) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Koin tidak cukup!'), backgroundColor: Colors.red),
      );
      return;
    }
    final game = PokerGame(
      numPlayers: _selectedPlayers,
      playerChips: _coins,
      ante: _selectedAnte,
    );
    // Setup bots
    final botNames = ['Bruno', 'Sakura', 'Viktor', 'Lena', 'Marco'];
    final rng = Random();
    for (int i = 0; i < _selectedPlayers - 1; i++) {
      game.bots.add(BotPlayer(
        name: botNames[i],
        difficulty: rng.nextInt(3) + 1,
        chips: 800 + rng.nextInt(400),
      ));
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _PokerGamePage(
          game: game,
          audio: _audio,
          username: widget.username,
          onExit: (finalCoins) {
            setState(() => _coins = finalCoins);
            _saveCoins(finalCoins);
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B3D1F),
      body: Stack(
        children: [
          // Felt texture
          Positioned.fill(child: CustomPaint(painter: _FeltPainter())),
          SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFFFD700)),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Expanded(
                        child: Text(
                          'REMI POKER',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFFFFD700),
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 4,
                            shadows: [Shadow(color: Colors.black54, blurRadius: 8)],
                          ),
                        ),
                      ),
                      const SizedBox(width: 48),
                    ],
                  ),
                ),

                // Chip display
                ScaleTransition(
                  scale: _chipAnim,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 40, vertical: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(color: const Color(0xFFFFD700), width: 2),
                      boxShadow: [BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.3), blurRadius: 20)],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('🪙', style: TextStyle(fontSize: 22)),
                        const SizedBox(width: 10),
                        Text(
                          _formatChips(_coins),
                          style: const TextStyle(
                            color: Color(0xFFFFD700),
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Text('chips', style: TextStyle(color: Colors.white54, fontSize: 13)),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Card preview
                _buildCardPreview(),

                const SizedBox(height: 20),

                // Settings panel
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D2E14).withOpacity(0.92),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.4), width: 1.5),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionLabel('⚙️  PENGATURAN MEJA'),
                        const SizedBox(height: 16),
                        _sectionLabel('Jumlah Pemain'),
                        const SizedBox(height: 8),
                        Row(
                          children: [2, 4, 6].map((n) => _optionChip(
                            label: '$n Pemain',
                            selected: _selectedPlayers == n,
                            onTap: () => setState(() => _selectedPlayers = n),
                          )).toList(),
                        ),
                        const SizedBox(height: 16),
                        _sectionLabel('Ante (Taruhan Awal)'),
                        const SizedBox(height: 8),
                        Row(
                          children: [25, 50, 100, 200].map((a) => _optionChip(
                            label: '🪙$a',
                            selected: _selectedAnte == a,
                            onTap: () => setState(() => _selectedAnte = a),
                          )).toList(),
                        ),
                        const SizedBox(height: 16),
                        _sectionLabel('Mode Game'),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.black26,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Row(
                            children: [
                              Text('🃏', style: TextStyle(fontSize: 20)),
                              SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('5 Card Draw', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold)),
                                  Text('Tukar hingga 5 kartu • Kombinasi Poker penuh',
                                      style: TextStyle(color: Colors.white54, fontSize: 11)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const Spacer(),
                        // Start button
                        GestureDetector(
                          onTap: _startGame,
                          child: Container(
                            width: double.infinity,
                            height: 56,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.4), blurRadius: 20)],
                            ),
                            child: const Center(
                              child: Text(
                                'MULAI BERMAIN',
                                style: TextStyle(
                                  color: Color(0xFF1A1A1A),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCardPreview() {
    final preview = [
      PlayingCard(value: 14, suit: Suit.spade),
      PlayingCard(value: 13, suit: Suit.heart),
      PlayingCard(value: 12, suit: Suit.diamond),
      PlayingCard(value: 11, suit: Suit.club),
      PlayingCard(value: 10, suit: Suit.spade),
    ];
    return SizedBox(
      height: 90,
      child: Stack(
        alignment: Alignment.center,
        children: List.generate(preview.length, (i) {
          final angle = (i - 2) * 0.1;
          final offset = (i - 2) * 28.0;
          return Transform.translate(
            offset: Offset(offset, 0),
            child: Transform.rotate(
              angle: angle,
              child: _CardWidget(card: preview[i], width: 58, height: 82, mini: true),
            ),
          );
        }),
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(
    text,
    style: const TextStyle(
      color: Color(0xFFFFD700),
      fontSize: 13,
      fontWeight: FontWeight.bold,
      fontFamily: 'Orbitron',
      letterSpacing: 1,
    ),
  );

  Widget _optionChip({required String label, required bool selected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8, bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFD700) : Colors.black26,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? const Color(0xFFFFD700) : Colors.white24,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white70,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// GAME PAGE
// ══════════════════════════════════════════════════════════════
class _PokerGamePage extends StatefulWidget {
  final PokerGame game;
  final _PokerAudio audio;
  final Function(int finalCoins) onExit;
  final String username;

  const _PokerGamePage({required this.game, required this.audio, required this.onExit, this.username = ''});

  @override
  State<_PokerGamePage> createState() => _PokerGamePageState();
}

class _PokerGamePageState extends State<_PokerGamePage>
    with TickerProviderStateMixin {

  PokerGame get game => widget.game;
  late AnimationController _dealCtrl;
  late AnimationController _resultCtrl;
  late Animation<double> _dealAnim;
  late Animation<double> _resultAnim;

  bool _botThinking = false;
  int _raiseAmount = 50;
  HandResult? _showdownResult;
  List<bool> _revealBots = [];
  String _statusMsg = '';

  @override
  void initState() {
    super.initState();
    _dealCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _dealAnim = CurvedAnimation(parent: _dealCtrl, curve: Curves.easeOut);
    _resultAnim = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);

    _startNewRound();
  }

  @override
  void dispose() {
    _dealCtrl.dispose();
    _resultCtrl.dispose();
    super.dispose();
  }

  void _startNewRound() {
    setState(() {
      _showdownResult = null;
      _revealBots = List.filled(game.bots.length, false);
      _statusMsg = 'Kartu dibagikan...';
      _raiseAmount = game.ante;
    });
    game.deal();
    _dealCtrl.reset();
    _dealCtrl.forward();
    widget.audio.playSfx('deal');
    setState(() => _statusMsg = 'Giliran kamu — Ronde Taruhan 1');
  }

  // ── BET ROUND 1 ACTIONS ─────────────────────────────────
  Future<void> _playerBetAction(String action) async {
    if (game.phase != GamePhase.betRound1) return;
    setState(() => _botThinking = true);

    if (action == 'fold') {
      game.playerFold();
    } else if (action == 'call') {
      game.playerCall();
    } else if (action == 'check') {
      game.playerCheck();
    } else if (action == 'raise') {
      game.playerRaise(_raiseAmount);
    }

    widget.audio.playSfx('chip');
    await Future.delayed(const Duration(milliseconds: 600));

    if (game.playerFolded) {
      _goToShowdown();
      return;
    }

    // Bot bets
    game.processBotBets();
    setState(() {
      game.phase = GamePhase.draw;
      _statusMsg = 'Pilih kartu yang ingin ditukar (atau skip)';
      _botThinking = false;
    });
  }

  // ── DRAW PHASE ──────────────────────────────────────────
  void _toggleCardSelect(int i) {
    if (game.phase != GamePhase.draw) return;
    setState(() {
      game.playerHand[i] = game.playerHand[i].copyWith(selected: !game.playerHand[i].selected);
    });
  }

  Future<void> _confirmDraw() async {
    if (game.phase != GamePhase.draw) return;
    setState(() => _botThinking = true);

    final discardIdx = game.playerHand
        .asMap()
        .entries
        .where((e) => e.value.selected)
        .map((e) => e.key)
        .toList();

    game.processDrawPhase(discardIdx);
    widget.audio.playSfx('deal');

    await Future.delayed(const Duration(milliseconds: 500));
    setState(() {
      game.phase = GamePhase.betRound2;
      _statusMsg = 'Ronde Taruhan 2';
      _botThinking = false;
    });
  }

  // ── BET ROUND 2 ACTIONS ─────────────────────────────────
  Future<void> _playerBetAction2(String action) async {
    if (game.phase != GamePhase.betRound2) return;
    setState(() => _botThinking = true);

    if (action == 'fold') {
      game.playerFold();
    } else if (action == 'call') {
      game.playerCall();
    } else if (action == 'check') {
      game.playerCheck();
    } else if (action == 'raise') {
      game.playerRaise(_raiseAmount);
    }

    widget.audio.playSfx('chip');
    await Future.delayed(const Duration(milliseconds: 600));

    game.processBotBets();
    await Future.delayed(const Duration(milliseconds: 400));
    setState(() => _botThinking = false);
    _goToShowdown();
  }

  // ── SHOWDOWN ─────────────────────────────────────────────
  void _goToShowdown() {
    final result = game.showdown();
    widget.audio.playSfx(game.winnerName == 'Kamu' ? 'win' : 'lose');

    setState(() {
      game.phase = GamePhase.showdown;
      _showdownResult = result;
      _revealBots = List.filled(game.bots.length, true);
      _statusMsg = game.winnerName == 'Kamu'
          ? '🏆 Kamu Menang! +${game.pot} chips'
          : '😔 ${game.winnerName} Menang!';
    });
    _resultCtrl.reset();
    _resultCtrl.forward();
  }

  void _nextRound() {
    if (game.playerChips <= 0) {
      _showGameOver();
      return;
    }
    setState(() => game.phase = GamePhase.deal);
    _startNewRound();
  }


  Future<void> _submitToLeaderboard() async {
    if (widget.username.isEmpty) return;
    final isWin = game.wins > game.losses;
    final finalScore = game.playerChips + (game.wins * 100);
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/games/leaderboard/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'gameName': 'Remi Poker',
          'score': finalScore,
          'win': isWin,
          'icon': '🃏',
        }),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  void _showGameOver() {
    _submitToLeaderboard();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0D2E14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('💀 GAME OVER', style: TextStyle(color: Color(0xFFFFD700), fontFamily: 'Orbitron')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Chips habis!', style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text('Menang: ${game.wins}  •  Kalah: ${game.losses}',
              style: const TextStyle(color: Colors.white54, fontSize: 13)),
        ]),
        actions: [
          TextButton(
            onPressed: () {
              widget.onExit(0);
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Keluar', style: TextStyle(color: Color(0xFFFFD700))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFD700)),
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                game.playerChips = 1000;
                game.wins = 0;
                game.losses = 0;
              });
              _startNewRound();
            },
            child: const Text('Main Lagi', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B3D1F),
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: _FeltPainter())),
          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                const SizedBox(height: 4),
                _buildStatusBar(),
                const SizedBox(height: 8),
                // Bot hands
                Expanded(
                  flex: 3,
                  child: _buildBotArea(),
                ),
                // Pot
                _buildPotInfo(),
                // Player hand
                Expanded(
                  flex: 3,
                  child: _buildPlayerArea(),
                ),
                // Action buttons
                _buildActionArea(),
                const SizedBox(height: 8),
              ],
            ),
          ),
          if (_botThinking)
            Positioned.fill(
              child: Container(
                color: Colors.black26,
                child: const Center(
                  child: CircularProgressIndicator(color: Color(0xFFFFD700)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              widget.onExit(game.playerChips);
              Navigator.pop(context);
            },
            child: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFFFD700), size: 20),
          ),
          const SizedBox(width: 8),
          const Text('REMI POKER', style: TextStyle(
            color: Color(0xFFFFD700), fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2,
          )),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5)),
            ),
            child: Row(children: [
              const Text('🪙', style: TextStyle(fontSize: 14)),
              const SizedBox(width: 4),
              Text(_formatChips(game.playerChips),
                  style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
            ]),
          ),
          const SizedBox(width: 8),
          Text('W:${game.wins} L:${game.losses}',
              style: const TextStyle(color: Colors.white38, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildStatusBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black38,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        _statusMsg,
        style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: 'Orbitron'),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildBotArea() {
    if (game.bots.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: LayoutBuilder(builder: (ctx, constraints) {
        return Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          runSpacing: 4,
          children: game.bots.asMap().entries.map((entry) {
            final i = entry.key;
            final bot = entry.value;
            return _buildBotHand(bot, _revealBots.isNotEmpty && _revealBots[i]);
          }).toList(),
        );
      }),
    );
  }

  Widget _buildBotHand(BotPlayer bot, bool reveal) {
    final maxW = (MediaQuery.of(context).size.width - 32) / max(game.bots.length, 1);
    final cardW = min(maxW * 0.18, 42.0);
    final cardH = cardW * 1.4;

    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: bot.folded
            ? Colors.black26
            : const Color(0xFF0D2E14).withOpacity(0.8),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: bot.folded ? Colors.white12 : const Color(0xFFFFD700).withOpacity(0.3),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: bot.hand.map((c) => Padding(
              padding: const EdgeInsets.only(right: 2),
              child: _CardWidget(
                card: reveal ? c.copyWith(faceUp: true) : c.copyWith(faceUp: false),
                width: cardW, height: cardH, mini: true,
              ),
            )).toList(),
          ),
          const SizedBox(height: 4),
          Text(bot.name, style: TextStyle(
            color: bot.folded ? Colors.white24 : Colors.white70,
            fontSize: 10, fontWeight: FontWeight.bold,
          )),
          if (bot.action.isNotEmpty)
            Text(bot.action.toUpperCase(), style: TextStyle(
              color: bot.action == 'fold'
                  ? Colors.red.shade300
                  : bot.action == 'raise'
                  ? const Color(0xFFFFD700)
                  : Colors.greenAccent,
              fontSize: 9, fontWeight: FontWeight.bold,
            )),
          if (reveal && !bot.folded) ...[
            const SizedBox(height: 2),
            Text(
              HandEvaluator.evaluate(bot.hand).rank.label,
              style: TextStyle(
                color: HandEvaluator.evaluate(bot.hand).rank.color,
                fontSize: 9, fontWeight: FontWeight.bold,
              ),
            ),
          ],
          Text('🪙${_formatChips(bot.chips)}',
              style: const TextStyle(color: Colors.white38, fontSize: 9)),
        ],
      ),
    );
  }

  Widget _buildPotInfo() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A).withOpacity(0.85),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5), width: 1.5),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 10)],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('🎰', style: TextStyle(fontSize: 16)),
          const SizedBox(width: 8),
          Text('POT: ', style: const TextStyle(color: Colors.white54, fontSize: 12)),
          Text(_formatChips(game.pot),
              style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(width: 6),
          Text('| Ante: ${game.ante}', style: const TextStyle(color: Colors.white38, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildPlayerArea() {
    return Column(
      children: [
        // Hand label
        if (_showdownResult != null)
          FadeTransition(
            opacity: _resultAnim,
            child: Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: _showdownResult!.rank.color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _showdownResult!.rank.color),
              ),
              child: Text(
                _showdownResult!.rank.label,
                style: TextStyle(
                  color: _showdownResult!.rank.color,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                ),
              ),
            ),
          ),
        // Cards
        Expanded(
          child: Center(
            child: SlideTransition(
              position: Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero)
                  .animate(_dealAnim),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: game.playerHand.asMap().entries.map((e) {
                  final i = e.key;
                  final card = e.value;
                  return GestureDetector(
                    onTap: () => _toggleCardSelect(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      transform: Matrix4.translationValues(
                        0,
                        card.selected ? -16 : 0,
                        0,
                      ),
                      child: _CardWidget(
                        card: card,
                        width: 60,
                        height: 86,
                        selected: card.selected && game.phase == GamePhase.draw,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ),
        const Text('TANGAN KAMU', style: TextStyle(
          color: Colors.white38, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 1,
        )),
      ],
    );
  }

  Widget _buildActionArea() {
    if (game.phase == GamePhase.showdown) {
      final isWin = game.winnerName == 'Kamu';
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: isWin
                    ? const Color(0xFFFFD700).withOpacity(0.15)
                    : Colors.red.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isWin ? const Color(0xFFFFD700) : Colors.red,
                ),
              ),
              child: Text(
                _statusMsg,
                style: TextStyle(
                  color: isWin ? const Color(0xFFFFD700) : Colors.redAccent,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white54,
                      side: const BorderSide(color: Colors.white24),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      widget.onExit(game.playerChips);
                      Navigator.pop(context);
                    },
                    child: const Text('KELUAR'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD700),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _nextRound,
                    child: const Text('RONDE BERIKUTNYA', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }

    if (game.phase == GamePhase.draw) {
      final selected = game.playerHand.where((c) => c.selected).length;
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          children: [
            Text(
              selected == 0 ? 'Tap kartu untuk pilih yang mau ditukar' : '$selected kartu dipilih untuk ditukar',
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white70,
                      side: const BorderSide(color: Colors.white24),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _confirmDraw, // skip (no discard)
                    child: const Text('SKIP (HOLD ALL)'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD700),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: selected > 0 ? _confirmDraw : null,
                    child: Text('TUKAR $selected KARTU'),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }

    // Bet rounds
    final isBet2 = game.phase == GamePhase.betRound2;
    final action = isBet2 ? _playerBetAction2 : _playerBetAction;
    final gap = game.currentBet - game.playerBet;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Column(
        children: [
          // Raise slider
          Row(
            children: [
              const Text('🪙', style: TextStyle(fontSize: 14)),
              Expanded(
                child: Slider(
                  value: _raiseAmount.toDouble(),
                  min: game.ante.toDouble(),
                  max: min(game.playerChips.toDouble(), game.ante * 10.0),
                  divisions: 9,
                  activeColor: const Color(0xFFFFD700),
                  inactiveColor: Colors.white12,
                  label: '${_raiseAmount}',
                  onChanged: (v) => setState(() => _raiseAmount = v.toInt()),
                ),
              ),
              Text('+$_raiseAmount', style: const TextStyle(color: Color(0xFFFFD700), fontSize: 12)),
            ],
          ),
          Row(
            children: [
              _actionBtn(
                label: 'FOLD', color: Colors.red.shade700,
                onTap: () => action('fold'),
              ),
              const SizedBox(width: 6),
              if (gap == 0)
                _actionBtn(
                  label: 'CHECK', color: Colors.blueGrey,
                  onTap: () => action('check'),
                )
              else
                _actionBtn(
                  label: 'CALL\n🪙$gap', color: const Color(0xFF2ECC71),
                  onTap: () => action('call'),
                ),
              const SizedBox(width: 6),
              _actionBtn(
                label: 'RAISE\n+$_raiseAmount', color: const Color(0xFFFFD700),
                textColor: Colors.black,
                onTap: () => action('raise'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _actionBtn({
    required String label,
    required Color color,
    Color textColor = Colors.white,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8)],
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: textColor,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              height: 1.3,
            ),
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// CARD WIDGET — CustomPainter
// ══════════════════════════════════════════════════════════════
class _CardWidget extends StatelessWidget {
  final PlayingCard card;
  final double width;
  final double height;
  final bool mini;
  final bool selected;

  const _CardWidget({
    required this.card,
    required this.width,
    required this.height,
    this.mini = false,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(mini ? 6 : 8),
        boxShadow: [
          BoxShadow(
            color: selected
                ? const Color(0xFFFFD700).withOpacity(0.8)
                : Colors.black.withOpacity(0.5),
            blurRadius: selected ? 12 : 4,
            spreadRadius: selected ? 2 : 0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(mini ? 6 : 8),
        child: CustomPaint(
          painter: _CardPainter(card: card, mini: mini),
        ),
      ),
    );
  }
}

class _CardPainter extends CustomPainter {
  final PlayingCard card;
  final bool mini;
  const _CardPainter({required this.card, this.mini = false});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    if (!card.faceUp) {
      _drawBack(canvas, size);
      return;
    }

    // Card face
    final bgPaint = Paint()..color = const Color(0xFFFFFDF5);
    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, w, h),
      const Radius.circular(0),
    );
    canvas.drawRRect(rrect, bgPaint);

    // Border
    final borderPaint = Paint()
      ..color = const Color(0xFFDDD8CC)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawRRect(rrect, borderPaint);

    final color = card.suit.color;
    final rank = card.rankLabel;
    final suit = card.suit.symbol;

    final fontSize = mini ? w * 0.30 : w * 0.28;
    final padding = w * 0.10;

    // Top-left rank
    _drawText(canvas, rank, Offset(padding, h * 0.04),
        fontSize: fontSize, color: color, bold: true);
    // Top-left suit
    _drawText(canvas, suit, Offset(padding, h * 0.04 + fontSize * 1.1),
        fontSize: fontSize * 0.85, color: color);

    // Bottom-right (rotated 180)
    canvas.save();
    canvas.translate(w, h);
    canvas.rotate(pi);
    _drawText(canvas, rank, Offset(padding, h * 0.04),
        fontSize: fontSize, color: color, bold: true);
    _drawText(canvas, suit, Offset(padding, h * 0.04 + fontSize * 1.1),
        fontSize: fontSize * 0.85, color: color);
    canvas.restore();

    // Center suit — big
    final centerFontSize = mini ? w * 0.52 : w * 0.50;
    final tp = TextPainter(
      text: TextSpan(
        text: suit,
        style: TextStyle(fontSize: centerFontSize, color: color),
      ),
      textDirection: TextDirection.ltr,
    );
    tp.layout();
    tp.paint(canvas, Offset((w - tp.width) / 2, (h - tp.height) / 2));
  }

  void _drawText(Canvas canvas, String text, Offset offset,
      {required double fontSize, required Color color, bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: fontSize,
          color: color,
          fontWeight: bold ? FontWeight.w900 : FontWeight.normal,
          height: 1.0,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    tp.layout();
    tp.paint(canvas, offset);
  }

  void _drawBack(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Background
    final bgPaint = Paint()..color = const Color(0xFF8B1A1A);
    canvas.drawRect(Rect.fromLTWH(0, 0, w, h), bgPaint);

    // Grid pattern
    final linePaint = Paint()
      ..color = const Color(0xFFB22222).withOpacity(0.6)
      ..strokeWidth = 1;
    const step = 8.0;
    for (double x = 0; x < w; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, h), linePaint);
    }
    for (double y = 0; y < h; y += step) {
      canvas.drawLine(Offset(0, y), Offset(w, y), linePaint);
    }

    // Inner border
    final borderPaint = Paint()
      ..color = const Color(0xFFFFD700).withOpacity(0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawRect(
      Rect.fromLTWH(w * 0.08, h * 0.06, w * 0.84, h * 0.88),
      borderPaint,
    );

    // Center diamond
    final tp = TextPainter(
      text: const TextSpan(
        text: '♦',
        style: TextStyle(fontSize: 16, color: Color(0xFFFFD700)),
      ),
      textDirection: TextDirection.ltr,
    );
    tp.layout();
    tp.paint(canvas, Offset((w - tp.width) / 2, (h - tp.height) / 2));
  }

  @override
  bool shouldRepaint(_CardPainter old) =>
      old.card.faceUp != card.faceUp ||
      old.card.value != card.value ||
      old.card.suit != card.suit;
}

// ══════════════════════════════════════════════════════════════
// FELT TABLE PAINTER
// ══════════════════════════════════════════════════════════════
class _FeltPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();

    // Base gradient
    paint.shader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF0B3D1F), Color(0xFF0D4A25), Color(0xFF092E18)],
    ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paint);

    // Subtle felt texture (dots)
    final dotPaint = Paint()
      ..color = Colors.white.withOpacity(0.015)
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 1;
    const spacing = 12.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 0.8, dotPaint);
      }
    }

    // Oval table border (decorative)
    final ovalPaint = Paint()
      ..color = const Color(0xFFFFD700).withOpacity(0.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width / 2, size.height / 2),
        width: size.width * 0.9,
        height: size.height * 0.75,
      ),
      ovalPaint,
    );
  }

  @override
  bool shouldRepaint(_) => false;
}

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════
String _formatChips(int v) {
  if (v >= 1000000) return '${(v / 1000000).toStringAsFixed(1)}M';
  if (v >= 1000) return '${(v / 1000).toStringAsFixed(1)}K';
  return '$v';
}
