import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';
import 'dashboard_page.dart';
import 'loader_page.dart';
import 'config_service.dart';
import 'asset_service.dart';
import 'login_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  VideoPlayerController? _videoController;
  late AnimationController _fadeController;
  bool _fadeOutStarted = false;
  bool _navigated = false;
  bool _showSkip = false;
  bool _videoError = false;
  bool _videoReady = false;
  bool _isValidatingSession = true;
  bool _sessionValid = false;

  Timer? _fallbackTimer;

  // Typewriter
  final String _fullText = 'TRICKSTER';
  String _displayText = '';
  bool _cursorVisible = true;
  Timer? _typeTimer;
  Timer? _cursorTimer;
  int _typeIndex = 0;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) setState(() => _showSkip = true);
    });

    _startTypewriter();
    _validateSessionAndInitialize();
  }

  // ─────────────────────────────────────────────────────────────
  // ⌨️ TYPEWRITER
  // ─────────────────────────────────────────────────────────────
  void _startTypewriter() {
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (mounted) setState(() => _cursorVisible = !_cursorVisible);
    });

    Future.delayed(const Duration(milliseconds: 400), () {
      _typeTimer = Timer.periodic(const Duration(milliseconds: 110), (_) {
        if (!mounted) return;
        if (_typeIndex < _fullText.length) {
          setState(() {
            _displayText = _fullText.substring(0, _typeIndex + 1);
            _typeIndex++;
          });
        } else {
          _typeTimer?.cancel();
        }
      });
    });
  }

  // ─────────────────────────────────────────────────────────────
  // 🔐 VALIDASI SINGLE SESSION SEBELUM MASUK DASHBOARD
  // ─────────────────────────────────────────────────────────────
  Future<void> _validateSessionAndInitialize() async {
    setState(() => _isValidatingSession = true);

    // ✅ FIX: Re-fetch domain terbaru dari GitHub sebelum apapun
    // Ini memastikan /myInfo dan semua request pakai domain yang benar
    await ConfigService.init();

    final isValid = await _checkSingleSession();

    if (!mounted) return;

    setState(() {
      _isValidatingSession = false;
      _sessionValid = isValid;
    });

    if (isValid) {
      _initializeVideo();
    } else {
      await _clearSessionAndRedirect();
    }
  }

  Future<bool> _checkSingleSession() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('sessionKey') ?? widget.sessionKey;
      final username = prefs.getString('username') ?? widget.username;
      final password = prefs.getString('password') ?? widget.password;

      if (sessionKey.isEmpty || username.isEmpty) {
        print('⚠️ No session key found, skipping validation');
        return true;
      }

      String androidId = await _getAndroidId();

      final response = await http.get(
        Uri.parse("${ConfigService.baseUrl}/myInfo").replace(queryParameters: {
          "username": username,
          "password": password,
          "androidId": androidId,
          "key": sessionKey,
        }),
      ).timeout(const Duration(seconds: 8));

      final data = jsonDecode(response.body);

      if (data['singleSession'] == true || data['reason'] == 'device_mismatch') {
        print('❌ Single session detected! Device mismatch.');
        await _logoutFromServer(sessionKey, androidId);
        return false;
      }

      if (data['expired'] == true) {
        print('❌ Account expired!');
        return false;
      }

      if (data['valid'] != true) {
        print('❌ Session invalid!');
        return false;
      }

      print('✅ Session valid for: $username');
      return true;
    } catch (e) {
      print('⚠️ Session validation error: $e');
      return true;
    }
  }

  Future<String> _getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        return (await deviceInfo.androidInfo).id;
      } else if (Platform.isIOS) {
        return (await deviceInfo.iosInfo).identifierForVendor ?? 'ios_unknown';
      }
    } catch (_) {}
    return 'device_unknown';
  }

  Future<void> _logoutFromServer(String sessionKey, String androidId) async {
    try {
      await http.post(
        Uri.parse("${ConfigService.baseUrl}/logout"),
        body: {"key": sessionKey, "androidId": androidId},
      ).timeout(const Duration(seconds: 3));
      print('✅ Logout request sent to server');
    } catch (e) {
      print('⚠️ Logout request failed: $e');
    }
  }

  Future<void> _clearSessionAndRedirect() async {
    if (_navigated) return;
    _navigated = true;
    _fallbackTimer?.cancel();

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1C1C1F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: const [
            Icon(Icons.warning_amber_rounded, color: Color(0xFFE05252), size: 24),
            SizedBox(width: 12),
            Text(
              'Session Expired',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
        content: const Text(
          'Akun sedang digunakan di perangkat lain.\nSilakan login kembali.',
          style: TextStyle(color: Color(0xFFA0A0A8), fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const LoginPage()),
              );
            },
            style: TextButton.styleFrom(
              foregroundColor: const Color(0xFFE05252),
            ),
            child: const Text('Login Ulang'),
          ),
        ],
      ),
    );
  }

  Future<void> _initializeVideo() async {
    try {
      final videoFile = File(AssetService.videoPathSync('splash.mp4'));
      if (!videoFile.existsSync()) {
        debugPrint('Video splash belum didownload');
        return;
      }
      final controller = VideoPlayerController.file(videoFile);

      await controller.initialize().timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          print('⚠️ Video initialization timeout');
          throw Exception('Video initialization timeout');
        },
      );

      if (!mounted) {
        controller.dispose();
        return;
      }

      _videoController = controller;
      setState(() => _videoReady = true);

      _videoController!.setLooping(false);
      _videoController!.setVolume(1.0);
      _videoController!.play();
      _videoController!.addListener(_onVideoProgress);
    } catch (e) {
      print('❌ Video error: $e');
      if (mounted) setState(() => _videoError = true);

      Future.delayed(const Duration(seconds: 2), () {
        if (mounted && !_navigated) {
          print('⚠️ Video error, navigating...');
          _navigateToDashboard();
        }
      });
    }
  }

  void _onVideoProgress() {
    if (!mounted || _navigated || _videoController == null) return;

    final value = _videoController!.value;
    final position = value.position;
    final duration = value.duration;

    print('Video progress: ${position.inSeconds}/${duration.inSeconds}');

    if (duration.inMilliseconds > 0 &&
        position >= duration - const Duration(milliseconds: 500) &&
        !_fadeOutStarted) {
      print('✅ Video nearly ended, starting fade out');
      setState(() => _fadeOutStarted = true);
      _fadeController.forward();
    }

    if (duration.inMilliseconds > 0 &&
        !value.isPlaying &&
        position >= duration - const Duration(milliseconds: 300) &&
        !_navigated) {
      print('🏁 Video finished, navigating...');
      _fadeController.forward().then((_) => _navigateToDashboard());
    }
  }

  Future<void> _navigateToDashboard() async {
    if (_navigated) return;
    _navigated = true;

    print('🚀 Navigating to dashboard');

    _fallbackTimer?.cancel();

    try {
      _videoController?.removeListener(_onVideoProgress);
      _videoController?.pause();
    } catch (e) {
      print('Error cleaning up video: $e');
    }

    if (!mounted) return;

    final prefs = await SharedPreferences.getInstance();
    final dashStyle = prefs.getString('dashboardStyle') ?? 'default';

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => dashStyle == 'loader'
            ? LoaderDashboardPage(
                username: widget.username,
                password: widget.password,
                role: widget.role,
                expiredDate: widget.expiredDate,
                sessionKey: widget.sessionKey,
                listBug: widget.listBug,
                listDoos: widget.listDoos,
                news: widget.news,
              )
            : DashboardPage(
                username: widget.username,
                password: widget.password,
                role: widget.role,
                expiredDate: widget.expiredDate,
                sessionKey: widget.sessionKey,
                listBug: widget.listBug,
                listDoos: widget.listDoos,
                news: widget.news,
              ),
      ),
    );
  }

  void _skip() {
    if (_navigated) return;
    print('⏭️ Skip button pressed');

    setState(() {
      _fadeOutStarted = true;
      _showSkip = false;
    });

    _fadeController.forward().then((_) {
      _navigateToDashboard();
    });
  }

  @override
  void dispose() {
    _fallbackTimer?.cancel();
    _typeTimer?.cancel();
    _cursorTimer?.cancel();
    _fadeController.dispose();
    try {
      _videoController?.removeListener(_onVideoProgress);
      _videoController?.dispose();
    } catch (e) {
      print('Error disposing video: $e');
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // ── VALIDASI SESSION LOADING ──
          if (_isValidatingSession)
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFCCA0FF)),
                    strokeWidth: 2,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Memeriksa session...',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),

          // ── VIDEO ATAU LOADING (hanya tampil jika session valid) ──
          if (!_isValidatingSession && _sessionValid)
            Positioned.fill(
              child: _videoError
                  ? _buildErrorWidget()
                  : (_videoReady && _videoController != null && _videoController!.value.isInitialized
                      ? ColorFiltered(
                          colorFilter: const ColorFilter.matrix(<double>[
                            1.2, 0,   0,   0, -25,
                            0,   1.2, 0,   0, -25,
                            0,   0,   1.2, 0, -25,
                            0,   0,   0,   1,   0,
                          ]),
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: SizedBox(
                              width: _videoController!.value.size.width,
                              height: _videoController!.value.size.height,
                              child: VideoPlayer(_videoController!),
                            ),
                          ),
                        )
                      : _buildLoadingWidget()),
            ),

          // ── GRADIENT OVERLAY (hanya jika session valid) ──
          if (!_isValidatingSession && _sessionValid)
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.5),
                      Colors.black.withOpacity(0.1),
                      Colors.black.withOpacity(0.75),
                    ],
                    stops: const [0.0, 0.45, 1.0],
                  ),
                ),
              ),
            ),

          // ── TEKS TRICKSTER CRASHER ──
          Positioned(
            bottom: 90,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.45),
                    borderRadius: BorderRadius.circular(40),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.purpleAccent.withOpacity(0.35),
                        blurRadius: 28,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Colors.white, Color(0xFFCCA0FF)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: RichText(
                      text: TextSpan(
                        style: const TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 4,
                          shadows: [
                            Shadow(color: Colors.black, blurRadius: 10, offset: Offset(2, 2)),
                            Shadow(color: Colors.black, blurRadius: 20),
                          ],
                        ),
                        children: [
                          TextSpan(text: _displayText),
                          TextSpan(
                            text: _cursorVisible ? '|' : ' ',
                            style: TextStyle(
                              color: const Color(0xFFCCA0FF).withOpacity(0.9),
                              fontWeight: FontWeight.w100,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'P R E M I U M  ·  S E C U R E',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 11,
                    letterSpacing: 3,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 16),

                if (!_videoReady && !_videoError && !_isValidatingSession && _sessionValid)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 12,
                          height: 12,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white70,
                          ),
                        ),
                        SizedBox(width: 8),
                        Text(
                          'Loading...',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),

          // ── TOMBOL SKIP ──
          if (!_isValidatingSession && _sessionValid)
            Positioned(
              top: MediaQuery.of(context).padding.top + 16,
              right: 20,
              child: AnimatedOpacity(
                opacity: _showSkip && !_fadeOutStarted && !_videoError ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 400),
                child: GestureDetector(
                  onTap: _showSkip ? _skip : null,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.45),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.25),
                            width: 1,
                          ),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'SKIP',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.5,
                              ),
                            ),
                            SizedBox(width: 5),
                            Icon(Icons.skip_next_rounded, color: Colors.white70, size: 16),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

          // ── FADE OUT ──
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController,
              child: Container(color: Colors.black),
            ),
        ],
      ),
    );
  }

  Widget _buildLoadingWidget() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Colors.purpleAccent),
            strokeWidth: 2,
          ),
          SizedBox(height: 20),
          Text(
            'Loading video...',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.6),
              borderRadius: BorderRadius.circular(30),
            ),
            child: const Icon(
              Icons.video_library_outlined,
              color: Colors.white70,
              size: 30,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Unable to load video',
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
          const SizedBox(height: 8),
          Text(
            'Redirecting...',
            style: TextStyle(
              color: Colors.purpleAccent.withOpacity(0.7),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}
