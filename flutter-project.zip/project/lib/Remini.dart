import 'dart:io';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:gallery_saver_plus/gallery_saver.dart';

class ReminiPage extends StatefulWidget {
  const ReminiPage({super.key});

  @override
  State<ReminiPage> createState() => _ReminiPageState();
}

class _ReminiPageState extends State<ReminiPage> with TickerProviderStateMixin {
  File? _selectedImage;
  String? _resultUrl;
  bool _isLoading = false;
  bool _isSaving = false;
  String _statusText = '';
  double _sliderValue = 0.5;
  bool _showComparison = false;

  late AnimationController _orbitController;
  late AnimationController _pulseController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _shimmerController;
  late AnimationController _glowController;

  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _shimmerAnim;
  late Animation<double> _glowAnim;
  late Animation<double> _pulseAnim;

  final ImagePicker _picker = ImagePicker();
  final String _apiKey = 'Miwa';

  // ─── Design Tokens ───────────────────────────────────────────
  static const _bg       = Color(0xFF04040A);
  static const _card     = Color(0xFF0C0C18);
  static const _border   = Color(0xFF1A1A2E);
  static const _gold     = Color(0xFFFFD166);
  static const _amber    = Color(0xFFFF9F1C);
  static const _rose     = Color(0xFFFF6B9D);
  static const _violet   = Color(0xFF9B5DE5);
  static const _teal     = Color(0xFF00F5D4);
  static const _green    = Color(0xFF06D6A0);
  static const _red      = Color(0xFFEF476F);
  static const _muted    = Color(0xFF2E2E50);
  static const _dim      = Color(0xFF6060A0);

  static const _gradGold = LinearGradient(
    colors: [Color(0xFFFFD166), Color(0xFFFF9F1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const _gradCool = LinearGradient(
    colors: [Color(0xFF9B5DE5), Color(0xFF00F5D4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const _gradFire = LinearGradient(
    colors: [Color(0xFFFF6B9D), Color(0xFFFFD166)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const _gradGreen = LinearGradient(
    colors: [Color(0xFF06D6A0), Color(0xFF00B4D8)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const _gradDark = LinearGradient(
    colors: [Color(0xFF1A1A30), Color(0xFF0F0F20)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // ─────────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();

    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));
    _shimmerAnim = Tween<double>(begin: -2.0, end: 2.0).animate(_shimmerController);
    _glowAnim = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _pulseAnim = Tween<double>(begin: 0.92, end: 1.08)
        .animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _orbitController.dispose();
    _pulseController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _shimmerController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  void _triggerEntrance() {
    _fadeController.reset();
    _slideController.reset();
    _fadeController.forward();
    _slideController.forward();
  }

  // ─── Logic ───────────────────────────────────────────────────

  Future<void> _pickImage() async {
    final XFile? picked = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 100,
    );
    if (picked != null) {
      _triggerEntrance();
      setState(() {
        _selectedImage = File(picked.path);
        _resultUrl = null;
        _statusText = '';
        _showComparison = false;
        _sliderValue = 0.5;
      });
    }
  }

  Future<String?> _uploadImage(File imageFile) async {
    try {
      setState(() => _statusText = '📤 Mengupload foto...');
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('https://filn.pp.ua/api/upload'),
      );
      request.files.add(await http.MultipartFile.fromPath('files', imageFile.path));
      final response = await request.send();
      final body = await response.stream.bytesToString();
      final data = jsonDecode(body);
      if (data['success'] == true && data['uploaded'] != null && data['uploaded'].isNotEmpty) {
        return data['uploaded'][0]['url'];
      }
    } catch (e) {
      debugPrint('Upload error: $e');
    }
    return null;
  }

  Future<void> _enhanceImage() async {
    if (_selectedImage == null) return;
    HapticFeedback.mediumImpact();
    setState(() {
      _isLoading = true;
      _resultUrl = null;
      _showComparison = false;
      _statusText = '⏳ Memproses...';
    });
    try {
      final uploadedUrl = await _uploadImage(_selectedImage!);
      if (uploadedUrl == null) {
        _showError('Gagal upload foto. Coba lagi.');
        return;
      }

      setState(() => _statusText = '✨ AI sedang enhance foto...');
      final uri = Uri.parse(
        'https://api.botcahx.eu.org/api/tools/remini-v2?url=${Uri.encodeComponent(uploadedUrl)}&apikey=$_apiKey',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 90));
      final data = jsonDecode(res.body);

      if (data['status'] == true || data['result'] != null) {
        final imageData = data['image_data'] ?? data['result'] ?? data['url'];
        _triggerEntrance();
        HapticFeedback.heavyImpact();
        setState(() {
          _resultUrl = imageData;
          _statusText = '✅ Foto berhasil di-enhance!';
          _showComparison = true;
        });
      } else {
        _showError(data['message'] ?? 'Gagal enhance foto.');
      }
    } catch (e) {
      _showError('Terjadi error: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveToGallery() async {
    if (_resultUrl == null) return;
    HapticFeedback.mediumImpact();
    setState(() => _isSaving = true);
    try {
      final res = await http.get(Uri.parse(_resultUrl!));
      final tempDir = Directory.systemTemp;
      final tempFile = File('${tempDir.path}/remini_hd_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await tempFile.writeAsBytes(res.bodyBytes);
      final success = await GallerySaver.saveImage(tempFile.path, albumName: 'Remini HD');
      await tempFile.delete();
      if (success == true && mounted) {
        HapticFeedback.heavyImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 12),
              const Text(
                'Foto HD tersimpan ke galeri!',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ]),
            backgroundColor: _green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            margin: const EdgeInsets.all(16),
          ),
        );
      } else {
        _showError('Gagal menyimpan foto.');
      }
    } catch (e) {
      _showError('Error saat menyimpan: $e');
    } finally {
      setState(() => _isSaving = false);
    }
  }

  void _showError(String msg) {
    setState(() {
      _statusText = '❌ $msg';
      _isLoading = false;
    });
    HapticFeedback.vibrate();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: _red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _reset() {
    _triggerEntrance();
    setState(() {
      _selectedImage = null;
      _resultUrl = null;
      _statusText = '';
      _isLoading = false;
      _showComparison = false;
      _sliderValue = 0.5;
    });
  }

  // ─── Build ───────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // Animated background orbs
          _buildBackgroundOrbs(),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: Column(
                  children: [
                    _buildAppBar(),
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(18, 4, 18, 40),
                        child: Column(
                          children: [
                            _buildHeroHeader(),
                            const SizedBox(height: 24),
                            if (_resultUrl != null && _showComparison)
                              _buildComparisonView()
                            else ...[
                              _buildOriginalCard(),
                              const SizedBox(height: 16),
                              _buildEnhanceButton(),
                              const SizedBox(height: 16),
                              _buildResultCard(),
                            ],
                            const SizedBox(height: 24),
                            _buildActionButtons(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Background ──────────────────────────────────────────────

  Widget _buildBackgroundOrbs() {
    return AnimatedBuilder(
      animation: _orbitController,
      builder: (_, __) {
        final t = _orbitController.value * 2 * math.pi;
        return Stack(
          children: [
            Positioned(
              top: 80 + math.sin(t) * 30,
              right: -60 + math.cos(t) * 20,
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _violet.withOpacity(0.12),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            Positioned(
              bottom: 120 + math.cos(t) * 25,
              left: -80 + math.sin(t) * 15,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _teal.withOpacity(0.08),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            Positioned(
              top: 300 + math.sin(t * 0.7) * 20,
              left: 100 + math.cos(t * 0.5) * 30,
              child: Container(
                width: 180,
                height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _gold.withOpacity(0.07),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ─── AppBar ──────────────────────────────────────────────────

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 10, 16, 4),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _border, width: 1),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white54, size: 18),
            ),
          ),
          const Spacer(),
          // Animated logo text
          AnimatedBuilder(
            animation: _shimmerAnim,
            builder: (_, __) {
              return ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: const [_gold, _amber, _rose, _gold],
                  stops: [
                    (_shimmerAnim.value - 0.5).clamp(0.0, 1.0),
                    (_shimmerAnim.value).clamp(0.0, 1.0),
                    (_shimmerAnim.value + 0.2).clamp(0.0, 1.0),
                    (_shimmerAnim.value + 0.5).clamp(0.0, 1.0),
                  ],
                ).createShader(bounds),
                child: const Text(
                  'REMINI HD',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                  ),
                ),
              );
            },
          ),
          const Spacer(),
          // AI badge
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                gradient: _gradGold,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: _gold.withOpacity(_glowAnim.value * 0.5),
                    blurRadius: 12,
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: const Text(
                'AI v4',
                style: TextStyle(
                  color: Color(0xFF1A0A00),
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Hero Header ─────────────────────────────────────────────

  Widget _buildHeroHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border, width: 1),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Transform.scale(
              scale: _pulseAnim.value,
              child: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: _gradGold,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: _gold.withOpacity(0.4),
                      blurRadius: 16,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: const Icon(Icons.auto_fix_high_rounded, color: Color(0xFF1A0A00), size: 26),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Enhance ke Resolusi Ultra HD',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Resolusi 16× • AI Powered • Instant',
                  style: TextStyle(color: _dim, fontSize: 12),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _teal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _teal.withOpacity(0.3), width: 1),
            ),
            child: const Text(
              '16×',
              style: TextStyle(
                color: _teal,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Original Image Card ──────────────────────────────────────

  Widget _buildOriginalCard() {
    return _buildImageSection(
      label: 'FOTO ASLI',
      gradient: _gradCool,
      child: _selectedImage != null
          ? _buildPhotoFrame(
              child: Image.file(_selectedImage!, fit: BoxFit.cover, width: double.infinity),
              accentGradient: _gradCool,
            )
          : _buildEmptySlot(
              icon: Icons.add_photo_alternate_outlined,
              title: 'Belum ada foto dipilih',
              subtitle: 'Ketuk "Pilih Foto" untuk mulai',
              gradient: _gradCool,
            ),
    );
  }

  // ─── Result Image Card ────────────────────────────────────────

  Widget _buildResultCard() {
    return _buildImageSection(
      label: 'HASIL HD',
      gradient: _gradGold,
      child: _isLoading
          ? _buildLoadingSlot()
          : _resultUrl != null
              ? _buildPhotoFrame(
                  child: Image.network(
                    _resultUrl!,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    loadingBuilder: (_, child, progress) {
                      if (progress == null) return child;
                      return SizedBox(
                        height: 260,
                        child: Center(
                          child: CircularProgressIndicator(
                            color: _gold,
                            strokeWidth: 2,
                            value: progress.expectedTotalBytes != null
                                ? progress.cumulativeBytesLoaded / progress.expectedTotalBytes!
                                : null,
                          ),
                        ),
                      );
                    },
                  ),
                  accentGradient: _gradGold,
                )
              : _buildEmptySlot(
                  icon: Icons.image_search_rounded,
                  title: 'Hasil HD akan muncul di sini',
                  subtitle: 'Pilih foto lalu tap Enhance',
                  gradient: _gradGold,
                ),
    );
  }

  Widget _buildImageSection({
    required String label,
    required LinearGradient gradient,
    required Widget child,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 10),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 14,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2.5,
                ),
              ),
            ],
          ),
        ),
        Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 240),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _border, width: 1),
          ),
          clipBehavior: Clip.antiAlias,
          child: child,
        ),
      ],
    );
  }

  Widget _buildPhotoFrame({required Widget child, required LinearGradient accentGradient}) {
    return Stack(
      children: [
        child,
        Positioned(
          top: 0, left: 0, right: 0,
          child: Container(
            height: 3,
            decoration: BoxDecoration(gradient: accentGradient),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptySlot({
    required IconData icon,
    required String title,
    required String subtitle,
    required LinearGradient gradient,
  }) {
    return SizedBox(
      height: 240,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: _muted.withOpacity(0.3),
                shape: BoxShape.circle,
                border: Border.all(color: _border, width: 1.5),
              ),
              child: Icon(icon, size: 30, color: _dim),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white54,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              style: TextStyle(color: _dim, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingSlot() {
    return SizedBox(
      height: 240,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _orbitController,
              builder: (_, __) => Transform.rotate(
                angle: _orbitController.value * 2 * math.pi,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: SweepGradient(
                      colors: [_gold.withOpacity(0), _gold],
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: _card,
                      ),
                      child: const Icon(Icons.auto_awesome_rounded, color: _gold, size: 24),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              child: Text(
                _statusText,
                key: ValueKey(_statusText),
                style: const TextStyle(
                  color: _gold,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Enhance Button (middle) ──────────────────────────────────

  Widget _buildEnhanceButton() {
    return GestureDetector(
      onTap: (_isLoading || _selectedImage == null) ? null : _enhanceImage,
      child: AnimatedBuilder(
        animation: _pulseAnim,
        builder: (_, __) => Transform.scale(
          scale: _isLoading ? _pulseAnim.value : 1.0,
          child: AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _selectedImage != null ? _gradGold : _gradDark,
                boxShadow: _selectedImage != null
                    ? [
                        BoxShadow(
                          color: _gold.withOpacity(_glowAnim.value * 0.6),
                          blurRadius: 30,
                          spreadRadius: 2,
                        ),
                      ]
                    : [],
              ),
              child: Icon(
                _isLoading
                    ? Icons.hourglass_top_rounded
                    : Icons.auto_fix_high_rounded,
                color: _selectedImage != null ? const Color(0xFF1A0A00) : _dim,
                size: 28,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── Comparison Slider View ───────────────────────────────────

  Widget _buildComparisonView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 12),
          child: Row(
            children: [
              Container(
                width: 3, height: 14,
                decoration: BoxDecoration(
                  gradient: _gradFire,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'PERBANDINGAN',
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2.5,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _rose.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _rose.withOpacity(0.3), width: 1),
                ),
                child: const Text(
                  'Geser untuk bandingkan',
                  style: TextStyle(color: _rose, fontSize: 10, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),

        // Comparison container
        Container(
          height: 320,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _border, width: 1),
          ),
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              // HD result (full)
              Positioned.fill(
                child: Image.network(
                  _resultUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Center(
                    child: Icon(Icons.broken_image_rounded, color: Colors.white30),
                  ),
                ),
              ),
              // Original (clipped left)
              Positioned.fill(
                child: ClipRect(
                  clipper: _SliderClipper(_sliderValue),
                  child: Image.file(
                    _selectedImage!,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              // Divider line
              Positioned(
                left: MediaQuery.of(context).size.width * _sliderValue - 19 - 18,
                top: 0,
                bottom: 0,
                child: Center(
                  child: Container(
                    width: 2,
                    color: Colors.white,
                    height: double.infinity,
                  ),
                ),
              ),
              // Handle
              Positioned(
                left: MediaQuery.of(context).size.width * _sliderValue - 19 - 18 - 18,
                top: 0,
                bottom: 0,
                child: Center(
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _gradGold,
                      boxShadow: [
                        BoxShadow(
                          color: _gold.withOpacity(0.5),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.compare_arrows_rounded,
                      color: Color(0xFF1A0A00),
                      size: 20,
                    ),
                  ),
                ),
              ),
              // Labels
              Positioned(
                top: 12,
                left: 12,
                child: _compLabel('ASLI', _gradCool),
              ),
              Positioned(
                top: 12,
                right: 12,
                child: _compLabel('HD', _gradGold),
              ),
            ],
          ),
        ),

        // Slider
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: SliderTheme(
            data: SliderThemeData(
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 18),
              activeTrackColor: _gold,
              inactiveTrackColor: _muted,
              thumbColor: _gold,
              overlayColor: _gold.withOpacity(0.2),
            ),
            child: Slider(
              value: _sliderValue,
              onChanged: (v) => setState(() => _sliderValue = v),
            ),
          ),
        ),
      ],
    );
  }

  Widget _compLabel(String text, LinearGradient gradient) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8),
        ],
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF1A0A00),
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.5,
        ),
      ),
    );
  }

  // ─── Action Buttons ───────────────────────────────────────────

  Widget _buildActionButtons() {
    if (_resultUrl != null) {
      return Column(
        children: [
          _buildBtn(
            label: _isSaving ? 'Menyimpan...' : 'Simpan ke Galeri',
            icon: Icons.download_rounded,
            gradient: _gradGreen,
            glowColor: _green,
            onTap: _isSaving ? null : _saveToGallery,
          ),
          const SizedBox(height: 12),
          _buildBtn(
            label: 'Enhance Foto Lain',
            icon: Icons.refresh_rounded,
            gradient: _gradDark,
            glowColor: _violet,
            onTap: _reset,
          ),
        ],
      );
    }

    return Column(
      children: [
        _buildBtn(
          label: _selectedImage == null ? 'Pilih Foto' : 'Ganti Foto',
          icon: Icons.photo_library_rounded,
          gradient: _gradDark,
          glowColor: _teal,
          onTap: _isLoading ? null : _pickImage,
        ),
        if (_selectedImage != null && !_isLoading) ...[
          const SizedBox(height: 12),
          _buildBtn(
            label: 'Enhance ke Ultra HD ✨',
            icon: Icons.auto_fix_high_rounded,
            gradient: _gradGold,
            glowColor: _gold,
            onTap: _enhanceImage,
          ),
        ],
        if (_isLoading) ...[
          const SizedBox(height: 12),
          _buildBtn(
            label: 'Sedang Memproses...',
            icon: Icons.hourglass_top_rounded,
            gradient: _gradDark,
            glowColor: _muted,
            onTap: null,
          ),
        ],
      ],
    );
  }

  Widget _buildBtn({
    required String label,
    required IconData icon,
    required LinearGradient gradient,
    required Color glowColor,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: _glowAnim,
        builder: (_, __) => Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: onTap != null ? gradient : _gradDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: onTap != null ? glowColor.withOpacity(0.3) : _border,
              width: 1,
            ),
            boxShadow: onTap != null
                ? [
                    BoxShadow(
                      color: glowColor.withOpacity(_glowAnim.value * 0.3),
                      blurRadius: 20,
                      spreadRadius: 0,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: onTap != null ? const Color(0xFF1A0A00) : _dim,
                size: 20,
              ),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(
                  color: onTap != null ? const Color(0xFF1A0A00) : _dim,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Comparison Clipper ───────────────────────────────────────────

class _SliderClipper extends CustomClipper<Rect> {
  final double value;
  _SliderClipper(this.value);

  @override
  Rect getClip(Size size) => Rect.fromLTRB(0, 0, size.width * value, size.height);

  @override
  bool shouldReclip(_SliderClipper old) => old.value != value;
}
