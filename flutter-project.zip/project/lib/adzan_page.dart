import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'adzan_service.dart';

class AdzanPage extends StatefulWidget {
  const AdzanPage({super.key});

  @override
  State<AdzanPage> createState() => _AdzanPageState();
}

class _AdzanPageState extends State<AdzanPage> with TickerProviderStateMixin {
  final AdzanService _service = AdzanService();
  bool _isLoading = false;
  bool _isEnabled = true;
  PrayerTimes? _prayers;
  String _nextPrayer = '';
  String _nextPrayerTime = '';
  Duration _timeUntilNext = Duration.zero;
  late AnimationController _pulseCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnimation;
  bool _locationDenied = false;
  bool _checkingLocation = true;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnimation = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _checkLocationAndLoad();
  }

  Future<void> _checkLocationAndLoad() async {
    setState(() => _checkingLocation = true);

    // Jika belum granted, minta dulu
    var status = await Permission.location.status;
    if (status.isDenied) {
      status = await Permission.location.request();
    }

    if (status.isPermanentlyDenied) {
      setState(() {
        _locationDenied = true;
        _checkingLocation = false;
      });
      _fadeCtrl.forward();
      return;
    }

    if (!status.isGranted) {
      setState(() {
        _locationDenied = true;
        _checkingLocation = false;
      });
      _fadeCtrl.forward();
      return;
    }

    // Permission granted
    setState(() {
      _locationDenied = false;
      _checkingLocation = false;
    });
    await _loadData();
  }

  Future<void> _requestLocationPermission() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      setState(() => _locationDenied = false);
      await _loadData();
    } else if (status.isPermanentlyDenied) {
      // Buka pengaturan app
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A2E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Izin Lokasi Diperlukan', style: TextStyle(color: Colors.white)),
          content: const Text(
            'Aplikasi membutuhkan izin lokasi untuk menentukan jadwal shalat yang akurat. Silakan aktifkan izin lokasi di pengaturan.',
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                openAppSettings();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFDC143C),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Buka Pengaturan'),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _checkingLocation = false;
    });
    _isEnabled = _service.isEnabled;

    if (_service.todayPrayers != null) {
      _prayers = _service.todayPrayers;
    } else {
      _prayers = await _service.fetchAndSchedule();
    }

    if (_prayers != null) _calcNext();
    setState(() => _isLoading = false);
    _fadeCtrl.forward();
  }

  Future<void> _refresh() async {
    setState(() => _isLoading = true);
    _prayers = await _service.fetchAndSchedule();
    if (_prayers != null) _calcNext();
    setState(() => _isLoading = false);
  }

  void _calcNext() {
    if (_prayers == null) return;
    final now = DateTime.now();
    final entries = _prayers!.all.entries.toList();

    for (final entry in entries) {
      final parts = entry.value.split(':');
      if (parts.length < 2) continue;
      final prayerTime = DateTime(now.year, now.month, now.day,
          int.parse(parts[0]), int.parse(parts[1]));
      if (prayerTime.isAfter(now)) {
        _nextPrayer = entry.key;
        _nextPrayerTime = entry.value;
        _timeUntilNext = prayerTime.difference(now);
        return;
      }
    }
    // Semua shalat sudah lewat, next = Subuh besok
    _nextPrayer = 'Subuh';
    _nextPrayerTime = _prayers!.fajr;
    final parts = _prayers!.fajr.split(':');
    if (parts.length >= 2) {
      final tomorrow = DateTime(now.year, now.month, now.day + 1,
          int.parse(parts[0]), int.parse(parts[1]));
      _timeUntilNext = tomorrow.difference(now);
    }
  }

  String _formatCountdown(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    if (h > 0) return '${h}j ${m}m lagi';
    if (m > 0) return '${m}m ${s}s lagi';
    return '${s}s lagi';
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accentColor = const Color(0xFFDC143C);
    String now;
    try {
      now = DateFormat('EEEE, dd MMMM yyyy', 'id').format(DateTime.now());
    } catch (_) {
      now = DateFormat('EEEE, dd MMMM yyyy').format(DateTime.now());
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          children: [
            // Top Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Jadwal Shalat',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        Text(
                          now,
                          style: const TextStyle(color: Colors.white38, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  // Toggle notif
                  GestureDetector(
                    onTap: () async {
                      await _service.setEnabled(!_isEnabled);
                      setState(() => _isEnabled = _service.isEnabled);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            _isEnabled ? '🔔 Notif adzan aktif' : '🔕 Notif adzan dimatikan',
                          ),
                          backgroundColor: _isEnabled ? Colors.green.withValues(alpha: 0.8) : Colors.grey.withValues(alpha: 0.8),
                          behavior: SnackBarBehavior.floating,
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _isEnabled ? accentColor.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _isEnabled ? accentColor.withValues(alpha: 0.4) : Colors.white12),
                      ),
                      child: Icon(
                        _isEnabled ? Icons.notifications_active : Icons.notifications_off,
                        color: _isEnabled ? accentColor : Colors.white38,
                        size: 20,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Refresh
                  GestureDetector(
                    onTap: _refresh,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Icon(Icons.refresh, color: Colors.white54, size: 20),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Stop adzan
                  GestureDetector(
                    onTap: () async {
                      await _service.stopAdzan();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('⏹️ Adzan dihentikan'),
                          backgroundColor: Colors.black87,
                          behavior: SnackBarBehavior.floating,
                          duration: Duration(seconds: 1),
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Icon(Icons.stop_circle_outlined, color: Colors.white54, size: 20),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Test adzan button
                  GestureDetector(
                    onTap: () async {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('🔊 Test adzan diputar...'),
                          backgroundColor: Colors.blueGrey,
                          behavior: SnackBarBehavior.floating,
                          duration: Duration(seconds: 2),
                        ),
                      );
                      await _service.testAdzan();
                    },
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.blue.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.blue.withValues(alpha: 0.35)),
                      ),
                      child: const Icon(Icons.play_circle_outline, color: Colors.blueAccent, size: 20),
                    ),
                  ),
                ],
              ),
            ),

            // Main Content
            Expanded(
              child: _checkingLocation
                  ? _buildCheckingLocation(accentColor)
                  : _locationDenied
                      ? _buildLocationPermissionWarning(accentColor)
                      : _isLoading
                          ? _buildLoadingState(accentColor)
                          : _prayers == null
                              ? _buildError(accentColor)
                              : FadeTransition(
                                  opacity: _fadeAnimation,
                                  child: _buildContent(accentColor),
                                ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCheckingLocation(Color accentColor) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: accentColor.withValues(alpha: 0.1),
              border: Border.all(color: accentColor.withValues(alpha: 0.3), width: 2),
            ),
            child: const SizedBox(
              width: 40,
              height: 40,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Memeriksa izin lokasi...',
            style: TextStyle(color: Colors.white54, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationPermissionWarning(Color accentColor) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Warning Icon Animation
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [Colors.orange.withValues(alpha: 0.2), Colors.orange.withValues(alpha: 0.05)],
                ),
                border: Border.all(color: Colors.orange.withValues(alpha: 0.4), width: 2),
              ),
              child: const Icon(Icons.location_off, color: Colors.orange, size: 64),
            ),
            const SizedBox(height: 24),
            const Text(
              '⚠️ IZIN LOKASI DIPERLUKAN',
              style: TextStyle(
                color: Colors.orange,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.orange.withValues(alpha: 0.2)),
              ),
              child: const Column(
                children: [
                  Text(
                    'Aktifkan lokasi untuk mendapatkan jadwal shalat yang akurat berdasarkan posisi Anda saat ini.',
                    style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 12),
                  Text(
                    '📍 Jadwal shalat akan disesuaikan dengan kota Anda',
                    style: TextStyle(color: Colors.white38, fontSize: 11),
                    textAlign: TextAlign.center,
                  ),
                  Text(
                    '🕌 Waktu shalat menggunakan metode Kemenag RI',
                    style: TextStyle(color: Colors.white38, fontSize: 11),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _requestLocationPermission,
              icon: const Icon(Icons.location_on, size: 20),
              label: const Text('AKTIFKAN LOKASI'),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 4,
              ),
            ),
            const SizedBox(height: 16),
            TextButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back, size: 18),
              label: const Text('Kembali'),
              style: TextButton.styleFrom(
                foregroundColor: Colors.white54,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState(Color accentColor) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: accentColor.withValues(alpha: 0.1),
            ),
            child: SizedBox(
              width: 40,
              height: 40,
              child: CircularProgressIndicator(
                color: accentColor,
                strokeWidth: 2,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Mendapatkan jadwal shalat...',
            style: TextStyle(color: Colors.white38, fontSize: 13),
          ),
          const SizedBox(height: 8),
          Text(
            'Berdasarkan lokasi Anda',
            style: TextStyle(color: Colors.white24, fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildError(Color accentColor) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, color: Colors.white24, size: 56),
          const SizedBox(height: 16),
          const Text('Gagal mendapatkan jadwal shalat', style: TextStyle(color: Colors.white54, fontSize: 15)),
          const SizedBox(height: 8),
          const Text('Periksa koneksi internet Anda', style: TextStyle(color: Colors.white24, fontSize: 12)),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _refresh,
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('Coba Lagi'),
            style: ElevatedButton.styleFrom(
              backgroundColor: accentColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(Color accentColor) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Next prayer countdown card
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(
                  colors: [accentColor.withValues(alpha: 0.25), accentColor.withValues(alpha: 0.08)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: accentColor.withValues(alpha: 0.2 + _pulseCtrl.value * 0.2),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withValues(alpha: 0.1 + _pulseCtrl.value * 0.1),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.mosque_outlined, color: Colors.white54, size: 16),
                      const SizedBox(width: 6),
                      const Text('SHALAT BERIKUTNYA', style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: 1)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    _nextPrayer,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      shadows: [Shadow(color: accentColor.withValues(alpha: 0.8), blurRadius: 16)],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _nextPrayerTime,
                    style: TextStyle(
                      color: accentColor,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.timer, size: 14, color: Colors.white54),
                        const SizedBox(width: 6),
                        Text(
                          _formatCountdown(_timeUntilNext),
                          style: const TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'ShareTechMono'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Lokasi info
          if (_prayers!.city.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.04),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: accentColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.location_on_outlined, color: accentColor, size: 16),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _prayers!.city,
                          style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w500),
                        ),
                        const Text(
                          'Zona waktu lokal',
                          style: TextStyle(color: Colors.white38, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'Kemenag RI',
                      style: TextStyle(color: Colors.white38, fontSize: 10),
                    ),
                  ),
                ],
              ),
            ),

          const SizedBox(height: 20),

          // Daftar waktu shalat
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            child: const Text(
              'JADWAL SHALAT',
              style: TextStyle(
                color: Colors.white38,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
          ..._prayers!.all.entries.map((e) => _buildPrayerRow(e.key, e.value, accentColor)),

          const SizedBox(height: 20),

          // Status notif
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _isEnabled ? Colors.green.withValues(alpha: 0.07) : Colors.white.withValues(alpha: 0.03),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _isEnabled ? Colors.green.withValues(alpha: 0.25) : Colors.white12,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _isEnabled ? Colors.green.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    _isEnabled ? Icons.notifications_active : Icons.notifications_off,
                    color: _isEnabled ? Colors.greenAccent : Colors.white24,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _isEnabled
                        ? 'Notifikasi adzan aktif • Anda akan diingatkan setiap waktu shalat'
                        : 'Notifikasi adzan dimatikan • Tap ikon 🔔 untuk mengaktifkan',
                    style: TextStyle(
                      color: _isEnabled ? Colors.white60 : Colors.white24,
                      fontSize: 11,
                      height: 1.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayerRow(String name, String time, Color accentColor) {
    final now = DateTime.now();
    final parts = time.split(':');
    bool isPast = false;
    bool isNext = name == _nextPrayer;

    if (parts.length >= 2) {
      final prayerDt = DateTime(now.year, now.month, now.day,
          int.parse(parts[0]), int.parse(parts[1]));
      isPast = prayerDt.isBefore(now);
    }

    final emoji = _getEmoji(name);
    final color = isNext ? accentColor : (isPast ? Colors.white24 : Colors.white70);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: isNext
            ? accentColor.withValues(alpha: 0.1)
            : Colors.white.withValues(alpha: 0.03),
        border: Border.all(
          color: isNext ? accentColor.withValues(alpha: 0.4) : Colors.white.withValues(alpha: 0.06),
          width: isNext ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          // Emoji icon
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: isNext ? accentColor.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(emoji, style: const TextStyle(fontSize: 24)),
            ),
          ),
          const SizedBox(width: 14),
          // Name
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    color: color,
                    fontSize: 15,
                    fontWeight: isNext ? FontWeight.w800 : FontWeight.w500,
                    fontFamily: isNext ? 'Orbitron' : null,
                  ),
                ),
                if (isNext)
                  Text(
                    _formatCountdown(_timeUntilNext),
                    style: TextStyle(color: accentColor.withValues(alpha: 0.7), fontSize: 11),
                  ),
                if (isPast && !isNext)
                  const Text(
                    'Sudah lewat',
                    style: TextStyle(color: Colors.white24, fontSize: 11),
                  ),
              ],
            ),
          ),
          // Time
          Text(
            time,
            style: TextStyle(
              color: isNext ? accentColor : color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
              shadows: isNext ? [Shadow(color: accentColor.withValues(alpha: 0.6), blurRadius: 8)] : null,
            ),
          ),
          const SizedBox(width: 8),
          if (isNext)
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: accentColor,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: accentColor.withValues(alpha: 0.6), blurRadius: 6)],
              ),
            ),
          if (isPast && !isNext)
            const Icon(Icons.check_circle_outline, color: Colors.white12, size: 16),
        ],
      ),
    );
  }

  String _getEmoji(String name) {
    switch (name) {
      case 'Subuh':
        return '🌙';
      case 'Dzuhur':
        return '☀️';
      case 'Ashar':
        return '🌤️';
      case 'Maghrib':
        return '🌅';
      case 'Isya':
        return '🌃';
      default:
        return '🕌';
    }
  }
}